﻿using System.Text.RegularExpressions;

namespace HealthyFood.Utils
{
    public static class RegexUtils
    {
        public static Regex Regex = new Regex(@"\s\s+");
        public static string RemoveExtraSpaces(string text)
        {
            return Regex.Replace(text, " ");
        }
    }
}
