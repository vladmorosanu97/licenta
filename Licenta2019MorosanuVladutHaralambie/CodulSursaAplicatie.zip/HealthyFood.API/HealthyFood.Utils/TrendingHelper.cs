﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HealthyFood.Utils
{
    public class TrendingHelper
    {
        public static double CalculateTrendingValue(long value, List<long> previousValues)
        {
            double sum = 0;

            double count = previousValues.Count;
            double average = previousValues.Average();

            foreach (var previousValue in previousValues)
            {
                sum += Math.Pow(previousValue - average, 2);
            }

            var standardDeviation = Math.Sqrt(sum / count);
            return standardDeviation == 0 ? (value - average) / 1 : (value - average) / standardDeviation;
        }
    }
}