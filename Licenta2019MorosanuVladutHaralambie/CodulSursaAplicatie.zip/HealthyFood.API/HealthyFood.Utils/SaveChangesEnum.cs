﻿namespace HealthyFood.Utils
{
    public enum SaveChangesEnum
    {
        Success,
        NotUpdated
    }
}
