﻿namespace HealthyFood.Utils
{
    public class RelationshipStatusConstants
    {
        public static string Request = "request";
        public static string Friend = "friend";
        public static string Block = "block";
    }
}
