﻿namespace HealthyFood.Utils
{
    public class AppSettings
    {
        public string[] AllowedHosts { get; set; }
        public ConnectionStrings ConnectionStrings { get; set; }
        public string Host { get; set; }
        public string ServerHost { get; set; }
        public Tokens Tokens { get; set; }
        public EmailSettings EmailSettings { get; set; }
        public Images Images { get; set; }
    }

    public class ConnectionStrings
    {
        public string DefaultConnection { get; set; }
    }

    public class Tokens
    {
        public string Issuer { get; set; }
        public string Audience { get; set; }
        public string Key { get; set; }
    }

    public class EmailSettings
    {
        public string PrimaryDomain { get; set; }
        public int PrimaryPort { get; set; }
        public string SecondaryDomain { get; set; }
        public int SecondaryPort { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class Images
    {
        public string AdvertisementsPath { get; set; }
        public string AdvertisementsCardPath { get; set; }
        public string UserPresentationPath { get; set; }
        public string UserAvatarPath { get; set; }
    }
}