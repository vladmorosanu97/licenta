﻿using System;
using Hangfire;
using Hangfire.SqlServer;
using HealthyFood.BusinessLogic.Implementation;
using HealthyFood.BusinessLogic.Implementation.Hangfire;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Interfaces.Hangfire;
using HealthyFood.Data.Implementation;
using HealthyFood.Data.Implementation.Repositories;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;
using HealthyFood.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using IAdvertisementsTrendingJob = HealthyFood.Data.Interfaces.Hangfire.IAdvertisementsTrendingJob;

namespace HealthyFood.Ioc
{
    public static class ServiceExtensions
    {
        public static IServiceCollection RegisterServices(this IServiceCollection services,
            IConfiguration configuration)
        {
            services.Configure<AppSettings>(configuration);
            services.AddScoped(s =>
            {
                var service = s.GetService<IOptions<AppSettings>>();
                var appSettings = service.Value;
                return appSettings;
            });

            services.AddDbContext<DatabaseContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));

            services.AddHangfire(config =>
            {
                var options = new SqlServerStorageOptions
                {
                    PrepareSchemaIfNecessary = false,
                    QueuePollInterval = TimeSpan.FromMinutes(15)
                };
                config.UseSqlServerStorage(configuration.GetConnectionString("DefaultConnection"), options);
            });

            //Repositories
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<ICategoryRepository, CategoryRepository>();
            services.AddScoped<IAdvertisementRepository, AdvertisementRepository>();
            services.AddScoped<IUnitRepository, UnitRepository>();
            services.AddScoped<IDapperBaseRepository, DapperBaseRepository>();
            services.AddScoped<IMessageRepository, MessageRepository>();
            services.AddScoped<IReviewRepository, ReviewRepository>();
            services.AddScoped<IPresentationRepository, PresentationRepository>();
            services.AddScoped<IRelationshipRepository, RelationshipRepository>();
            services.AddScoped<IDeliveryRepository, DeliveryRepository>();
            services.AddScoped<ISearchRepository, SearchRepository>();

            //Services
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IEmailService, EmailService>();
            services.AddScoped<ICategoryService, CategoryService>();
            services.AddScoped<IAdvertisementService, AdvertisementService>();
            services.AddScoped<IUnitService, UnitService>();
            services.AddScoped<IMessageService, MessageService>();
            services.AddScoped<IReviewService, ReviewService>();
            services.AddScoped<IPresentationService, PresentationService>();
            services.AddScoped<IRelationshipService, RelationshipService>();
            services.AddScoped<IDeliveryService, DeliveryService>();

            // Jobs
            services.AddScoped<IAdvertisementsTrendingJob, AdvertisementsTrendingJob>();
            services.AddScoped<ISearchSuggestionsTrendingJob, SearchSuggestionsTrendingJob>();
            return services;
        }
    }
}