﻿using System;
using HealthyFood.BusinessLogic.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models
{
    public partial class SellerScoreBlModel
    {
        public long SellerScoreId { get; set; }
        public long UserId { get; set; }
        public decimal Score { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual UserBlModel User { get; set; }
    }
}
