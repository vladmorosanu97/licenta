﻿using System;
using HealthyFood.BusinessLogic.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models.PrimitiveModels.MessageModels
{
    public class ChatCardBlModel
    {
        public long ChatId { get; set; }
        public string Name { get; set; }
        public int MessagesCount { get; set; }
        public bool IsOnline { get; set; }
        public decimal Rating { get; set; }
        public DateTime? LastTimeOnline { get; set; }
        public UserBlModel User { get; set; }
    }
}
