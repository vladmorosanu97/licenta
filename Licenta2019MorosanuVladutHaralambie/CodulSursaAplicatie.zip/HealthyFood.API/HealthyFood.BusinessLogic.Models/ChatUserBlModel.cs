﻿using System;
using HealthyFood.BusinessLogic.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models
{
    public partial class ChatUserBlModel
    {
        public long ChatUserId { get; set; }
        public long ChatId { get; set; }
        public long UserId { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual ChatBlModel Chat { get; set; }
        public virtual UserBlModel User { get; set; }
    }
}
