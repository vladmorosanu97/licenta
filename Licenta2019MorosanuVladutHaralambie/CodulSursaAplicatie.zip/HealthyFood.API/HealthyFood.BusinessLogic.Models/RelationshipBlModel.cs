﻿using System;
using HealthyFood.BusinessLogic.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models
{
    public partial class RelationshipBlModel
    {
        public long RelationshipId { get; set; }
        public long RelatingUserId { get; set; }
        public long RelatedUserId { get; set; }
        public string Type { get; set; }
        public bool SendMails { get; set; }
        public bool SendNotifications { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual UserBlModel RelatedUser { get; set; }
        public virtual UserBlModel RelatingUser { get; set; }
    }
}
