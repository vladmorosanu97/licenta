﻿using System.Linq;
using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class LocationDeliveryMapper
    {
        public static LocationDeliveryBlModel GetLocationDeliveryBlModel(this Delivery item, long receiverId)
        {
            return new LocationDeliveryBlModel()
            {
                LocationDeliveryId = item.DeliveryId,
                AuthorId = item.AuthorId,
                Day = item.Day,
                DeliveryTypeId = item.DeliveryTypeId,
                LocationDeliveryPoints = item.LocationDeliveryPoints.Select(a => a.GetBlModel(receiverId)).ToList(),
                Author = item.Author.GetBlModel()
            };
        }

        public static LocationDeliveryBlModel GetLocationDeliveryBlModelWithFriends(this Delivery item, long receiverId)
        {
            return new LocationDeliveryBlModel()
            {
                LocationDeliveryId = item.DeliveryId,
                AuthorId = item.AuthorId,
                Day = item.Day,
                DeliveryTypeId = item.DeliveryTypeId,
                LocationDeliveryPoints = item.LocationDeliveryPoints.Select(a => a.GetBlModelWithFriends(receiverId)).ToList(),
                Author = item.Author.GetBlModel()
            };
        }
    }
}
