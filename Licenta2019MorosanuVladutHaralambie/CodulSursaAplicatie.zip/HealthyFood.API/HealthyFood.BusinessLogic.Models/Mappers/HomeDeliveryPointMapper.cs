﻿using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class HomeDeliveryPointMapper
    {
        public static HomeDeliveryPointBlModel GetBlModel(this HomeDeliveryPoint model)
        {
            return new HomeDeliveryPointBlModel()
            {
                HomeDeliveryPointId = model.HomeDeliveryPointId,
                ArrivalTime = model.ArrivalTime,
                UserId = model.UserId,
                User = model.User?.GetBlModelWithLocations(),
                Description = model.Description
            };
        }
    }
}
