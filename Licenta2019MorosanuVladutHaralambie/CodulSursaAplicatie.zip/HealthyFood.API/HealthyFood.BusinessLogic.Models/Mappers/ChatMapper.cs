﻿using System.Linq;
using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class ChatMapper
    {
        public static Chat GetDataModel(this ChatBlModel blItem)
        {
            var item = new Chat()
            {
                Name = blItem.Name
            };
            return item;
        }

        public static ChatBlModel GetBlModel(this Chat item)
        {
            var blItem = new ChatBlModel()
            {
               ChatId = item.ChatId,
               Name = item.Name,
               ChatUsers = item.ChatUsers?.Select(a => a.GetBlModel()).ToList(),
               Messages = item.Messages.Select(a => a.GetBlModel()).ToList()
            };
            return blItem;
        }
    }
}
