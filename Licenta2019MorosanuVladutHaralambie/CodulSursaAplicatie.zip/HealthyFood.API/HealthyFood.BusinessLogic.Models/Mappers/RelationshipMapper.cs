﻿using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class RelationshipMapper
    {
        public static RelationshipBlModel GetBlModel(this Relationship item)
        {
            return new RelationshipBlModel()
            {
                Modified = item.Modified,
                Created = item.Created,
                RelatedUserId = item.RelatedUserId,
                RelatingUserId = item.RelatingUserId,
                RelatedUser = item.RelatedUser?.GetBlModel(),
                RelatingUser = item.RelatingUser?.GetBlModel(),
                RelationshipId = item.RelationshipId,
                SendMails = item.SendMails,
                SendNotifications = item.SendNotifications,
                Type = item.Type
            };
        }
    }
}
