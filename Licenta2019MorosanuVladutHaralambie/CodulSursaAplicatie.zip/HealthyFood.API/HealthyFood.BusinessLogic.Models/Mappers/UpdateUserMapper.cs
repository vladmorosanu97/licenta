﻿using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class UpdateUserMapper
    {
        public static User GetDataModel(this UpdateUserBlModel itemViewModel)
        {
            return new User()
            {
                UserId = itemViewModel.UserId,
                PhoneNumber = itemViewModel.PhoneNumber,
                Email = itemViewModel.Email,
                FirstName = itemViewModel.FirstName,
                LastName = itemViewModel.LastName,
            };
        }
    }
}
