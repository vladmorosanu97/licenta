﻿using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class UnitMapper
    {
        public static UnitTypeBlModel GetBlModel(this UnitType item)
        {
            var blItem = new UnitTypeBlModel()
            {
                UnitTypeId = item.UnitTypeId,
                Name = item.Name,
                Code = item.Code
            };
            return blItem;
        }
    }
}
