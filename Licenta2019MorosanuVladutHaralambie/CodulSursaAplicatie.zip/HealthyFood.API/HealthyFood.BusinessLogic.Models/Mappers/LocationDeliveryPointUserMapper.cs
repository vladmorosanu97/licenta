﻿using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class LocationDeliveryPointUserMapper
    {
        public static LocationDeliveryPointsUser GetDataModel(long friendId, long locationDeliveryId)
        {
            return new LocationDeliveryPointsUser()
            {
                LocationDeliveryPointId = locationDeliveryId,
                UserId = friendId
            };
        }
    }
}
