﻿using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class SellerMapper
    {
        public static SellerPresentation GetDataModel(this SellerPresentationBlModel blModel)
        {
            var item = new SellerPresentation
            {
                BannerName = blModel.BannerPath?.Value,
                Description = blModel.Description?.Value,
                UserId = blModel.UserId,
            };
            return item;
        }
    }
}
