﻿using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class ReviewMapper
    {
        public static ReviewBlModel GetBlModel(this Review item)
        {
            return new ReviewBlModel()
            {
                RecipientId = item.RecipientId,
                Content = item.Content,
                Created = item.Created,
                Creator = item.Creator?.GetBlModel(),
                CreatorId = item.CreatorId,
                Mark = item.Mark,
                Modified = item.Modified,
                Recipient = item.Recipient?.GetBlModel(),
                ReviewId = item.ReviewId
            };
        }

        public static Review GetDataModel(this ReviewBlModel item)
        {
            return new Review()
            {
                RecipientId = item.RecipientId,
                Content = item.Content,
                CreatorId = item.CreatorId,
                Mark = item.Mark,
            };
        }
    }
}
