﻿using System.Linq;
using HealthyFood.Data.Models;
using HealthyFood.Data.Models.DapperModels;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class AdvertisementMapper
    {
        public static Advertisement GetDataModel(this AdvertisementBlModel blItem)
        {
            var item = new Advertisement()
            {
                Description = blItem.Description,
                CategoryId = blItem.CategoryId,
                DeactivationReason = blItem.DeactivationReason,
                DeletedById = blItem.DeletedById,
                HomeDelivery = blItem.HomeDelivery,
                IsDeleted = blItem.IsDeleted,
                IsDisabled = blItem.IsDisabled,
                Latitude = blItem.Latitude,
                Longitude = blItem.Longitude,
                LocationName = blItem.LocationName,
                Price = blItem.Price,
                Title = blItem.Title,
                UnitTypeId = blItem.UnitTypeId,
                CreatedById = blItem.CreatedById,
                PhoneNumber = blItem.PhoneNumber,
                AdvertisementId = blItem.AdvertisementId,
            };
            return item;
        }

        public static AdvertisementBlModel GetBlModel(this Advertisement item)
        {
            var blItem = new AdvertisementBlModel()
            {
                Description = item.Description,
                CategoryId = item.CategoryId,
                HomeDelivery = item.HomeDelivery,
                Latitude = item.Latitude,
                Longitude = item.Longitude,
                LocationName = item.LocationName,
                Price = item.Price,
                Title = item.Title,
                UnitTypeId = item.UnitTypeId,
                CreatedById = item.CreatedById,
                UnitType = item.UnitType?.GetBlModel(),
                AdvertisementId = item.AdvertisementId,
                AdvertisementImages = item.AdvertisementImages?.Select(a => a.GetBlModel()).ToList(),
                CreatedBy = item.CreatedBy?.GetUserCardModel(),
                Category = item.Category.GetBlModel(),
                PhoneNumber = item.PhoneNumber
            };
            return blItem;
        }

        public static AdvertisementCard GetBlCardModel(this Advertisement item)
        {
            var blItem = new AdvertisementCard()
            {
                CategoryId = item.CategoryId,
                Latitude = item.Latitude ?? 0,
                Longitude = item.Longitude ?? 0,
                LocationName = item.LocationName,
                Price = item.Price,
                Title = item.Title,
                AdvertisementId = item.AdvertisementId,
            };
            return blItem;
        }
    }
}