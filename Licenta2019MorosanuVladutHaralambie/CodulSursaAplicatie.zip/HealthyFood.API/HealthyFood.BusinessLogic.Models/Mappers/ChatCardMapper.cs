﻿using HealthyFood.BusinessLogic.Models.PrimitiveModels.MessageModels;
using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class ChatCardMapper
    {
        public static ChatCardBlModel GetBlModel(this ChatCard item)
        {
            var blItem = new ChatCardBlModel()
            {
                ChatId = item.ChatId,
                Name = item.Name,
                User = new UserBlModel()
                {
                    UserId = item.User.UserId,
                    FirstName = item.User.FirstName,
                    LastName = item.User.LastName,
                    Longitude = item.User.HomeLongitude,
                    Latitude = item.User.HomeLatitude,
                    Email = item.User.Email,
                    LocationName = item.User.HomeLocationName,
                    AvatarUrl = item.User.GuidAvatarName != null ? "https://localhost:44374/api/accounts/photos?guidFileName=" + item.User.GuidAvatarName : null
                },
                MessagesCount = item.MessagesCount,
                IsOnline = item.IsOnline,
                Rating = item.Rating,
                LastTimeOnline = item.LastTimeOnline
            };
            return blItem;
        }
    }
}