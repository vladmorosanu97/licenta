﻿using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class CreateHomeDeliveryPointMapper
    {
        public static HomeDeliveryPoint GetDataModel(this CreateHomeDeliveryPointBlModel model, long deliveryId)
        {
            return new HomeDeliveryPoint()
            {
                DeliveryId = deliveryId,
                ArrivalTime = model.ArrivalTime,
                UserId = model.UserId,
                Description = model.Description
            };
        }
    }
}
