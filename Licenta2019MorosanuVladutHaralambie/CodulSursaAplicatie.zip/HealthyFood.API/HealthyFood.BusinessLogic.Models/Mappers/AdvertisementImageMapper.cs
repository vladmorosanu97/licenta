﻿using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class AdvertisementImageMapper
    {
        public static AdvertisementImage GetDataModel(this AdvertisementImageBlModel blItem)
        {
            var item = new AdvertisementImage()
            {
                AdvertisementId = blItem.AdvertisementId,
                FileName = blItem.FileName,
                GuidFileName = blItem.GuidFileName,
            };
            return item;
        }

        public static AdvertisementImageBlModel GetBlModel(this AdvertisementImage item)
        {
            var blItem = new AdvertisementImageBlModel()
            {
                AdvertisementId = item.AdvertisementId,
                GuidFileName = item.GuidFileName,
                AdvertisementImageId = item.AdvertisementImageId,
            };
            return blItem;
        }
    }
}
