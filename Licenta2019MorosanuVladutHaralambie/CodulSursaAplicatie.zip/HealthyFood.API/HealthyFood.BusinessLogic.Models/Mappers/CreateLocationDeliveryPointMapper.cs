﻿using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class CreateLocationDeliveryPointMapper
    {
        public static LocationDeliveryPoint GetDataModel(this CreateLocationDeliveryPointBlModel model, long deliveryId)
        {
            return new LocationDeliveryPoint()
            {
                IsForAllFriends = model.IsForAllFriends,
                Latitude = model.Latitude,
                LocationName = model.LocationName,
                Longitude = model.Longitude,
                TimeEnd = model.TimeEnd,
                TimeStart = model.TimeStart,
                DeliveryId = deliveryId,
                Description = model.Description
            };
        }
    }
}
