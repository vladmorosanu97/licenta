﻿using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class CreateLocationDeliveryMapper
    {
        public static Delivery GetDeliveryDataModel(this CreateLocationDeliveryBlModel blModel)
        {
            return new Delivery()
            {
                AuthorId = blModel.AuthorId,
                Day = blModel.Day,
                DeliveryTypeId = blModel.DeliveryTypeId
            };
        }

       
    }
}
