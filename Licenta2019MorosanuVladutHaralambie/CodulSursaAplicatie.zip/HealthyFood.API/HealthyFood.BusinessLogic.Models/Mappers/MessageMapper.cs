﻿using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class MessageMapper
    {
        public static Message GetDataModel(this MessageBlModel blItem)
        {
            var item = new Message()
            {
                AuthorId = blItem.AuthorId,
                ChatId = blItem.ChatId,
                Content = blItem.Content,
            };
            return item;
        }

        public static MessageBlModel GetBlModel(this Message item)
        {
            var blItem = new MessageBlModel()
            {
                ChatId = item.ChatId,
                AuthorId = item.AuthorId,
                Content = item.Content,
                Created = item.Created,
                Author = item.Author?.GetBlModel(),
                MessageId = item.MessageId,
                Modified = item.Modified,
            };
            return blItem;
        }
    }
}