﻿using System.Security.Claims;
using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class UserClaimMapper
    {
        public static Claim GetClaims(this UserClaim userClaim)
        {
            return new Claim(userClaim.ClaimType, userClaim.ClaimValue);
        }
    }
}
