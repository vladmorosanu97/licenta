﻿using System.Collections.Generic;

namespace HealthyFood.BusinessLogic.Models
{
    public class UnitTypeBlModel
    {
        public UnitTypeBlModel()
        {
            Advertisements = new HashSet<AdvertisementBlModel>();
        }
        public byte UnitTypeId { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }

        public virtual ICollection<AdvertisementBlModel> Advertisements { get; set; }
    }
}
