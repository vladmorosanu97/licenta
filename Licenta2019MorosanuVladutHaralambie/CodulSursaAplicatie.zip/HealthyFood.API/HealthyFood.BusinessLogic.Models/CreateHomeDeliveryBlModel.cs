﻿using System;
using System.Collections.Generic;

namespace HealthyFood.BusinessLogic.Models
{
    public class CreateHomeDeliveryBlModel
    {
        public long AuthorId { get; set; }
        public byte DeliveryTypeId { get; set; }
        public DateTime Day { get; set; }
        public List<CreateHomeDeliveryPointBlModel> HomeDeliveryPoints { get; set; }
    }
}
