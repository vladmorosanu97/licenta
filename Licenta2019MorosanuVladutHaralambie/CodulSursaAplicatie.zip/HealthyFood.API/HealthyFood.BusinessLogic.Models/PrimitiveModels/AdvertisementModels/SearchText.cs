﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;
using HealthyFood.Utils;

namespace HealthyFood.BusinessLogic.Models.PrimitiveModels.AdvertisementModels
{
    public class SearchText : ValueObject
    {
        public string Value { get; }

        private SearchText(string value)
        {
            Value = value;
        }

        public static Result<SearchText> Create(Maybe<string> itemOrNothing)
        {
            return itemOrNothing.ToResult("Search text should not be empty")
                .Ensure(text => text.Length < 255, "Search text is too long")
                .Map(text => new SearchText(RegexUtils.RemoveExtraSpaces(text)));
        }

        public static explicit operator SearchText(string searchText)
        {
            return Create(searchText).Value;
        }

        public static implicit operator string(SearchText searchText)
        {
            return searchText.Value;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }
    }
}
