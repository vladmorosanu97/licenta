﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;

namespace HealthyFood.BusinessLogic.Models.PrimitiveModels.AdvertisementModels
{
    public class Price : ValueObject
    {
        public decimal Value { get; }

        private Price(decimal value)
        {
            Value = value;
        }

        public static Result<Price> Create(Maybe<decimal> priceOrNothing)
        {
            return priceOrNothing.ToResult("Price should not be empty")
                .Map(price => new Price(price));
        }

        public static explicit operator Price(decimal price)
        {
            return Create(price).Value;
        }

        public static implicit operator decimal(Price price)
        {
            return price.Value;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }
    }
}
