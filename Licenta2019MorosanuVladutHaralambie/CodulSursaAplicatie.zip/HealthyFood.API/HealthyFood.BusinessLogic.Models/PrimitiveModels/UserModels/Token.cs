﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;

namespace HealthyFood.Data.Models.UserModels
{
    public class Token : ValueObject
    {
        public string Value { get; }

        private Token(string value)
        {
            Value = value;
        }

        public static Result<Token> Create(Maybe<string> tokenOrNothing)
        {
            return tokenOrNothing.ToResult("Token should not be empty")
                .Map(token => new Token(token));
        }

        public static explicit operator Token(string token)
        {
            return Create(token).Value;
        }

        public static implicit operator string(Token token)
        {
            return token.Value;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }
    }
}
