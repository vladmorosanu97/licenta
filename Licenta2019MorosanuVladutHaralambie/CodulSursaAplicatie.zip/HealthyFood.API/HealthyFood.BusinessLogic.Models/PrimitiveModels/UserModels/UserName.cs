﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;

namespace HealthyFood.Data.Models.UserModels
{
    public class UserName : ValueObject
    {
        public string Value { get; }
        private UserName(string value)
        {
            Value = value;
        }

        public static Result<UserName> Create(Maybe<string> customerNameOrNothing)
        {
            return customerNameOrNothing
                .ToResult("Name should not be empty")
                .OnSuccess(name => name.Trim())
                .Ensure(name => name != string.Empty, "Name name should not be empty")
                .Ensure(name => name.Length <= 200, "Name is too long")
                .Map(name => new UserName(name));
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }

        public static explicit operator UserName(string customerName)
        {
            return Create(customerName).Value;
        }

        public static implicit operator string(UserName customerName)
        {
            return customerName.Value;
        }
    }
}
