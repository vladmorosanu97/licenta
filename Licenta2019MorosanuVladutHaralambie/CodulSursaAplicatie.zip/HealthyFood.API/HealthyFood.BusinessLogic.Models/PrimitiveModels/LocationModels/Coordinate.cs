﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;

namespace HealthyFood.Data.Models.UserModels
{
    public class Coordinate : ValueObject
    {
        public decimal Value { get; }

        private Coordinate(decimal value)
        {
            Value = value;
        }

        public static Result<Coordinate> Create(Maybe<decimal> tokenOrNothing)
        {
            return tokenOrNothing.ToResult("Coordinate should not be empty")
                .Map(coordinate => new Coordinate(Decimal.Parse(String.Format("{0:0.000000000000000000}", coordinate))));      // "123.46"));
        }

        public static explicit operator Coordinate(decimal coordinate)
        {
            return Create(coordinate).Value;
        }

        public static implicit operator decimal(Coordinate coordinate)
        {
            return coordinate.Value;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }
    }
}
