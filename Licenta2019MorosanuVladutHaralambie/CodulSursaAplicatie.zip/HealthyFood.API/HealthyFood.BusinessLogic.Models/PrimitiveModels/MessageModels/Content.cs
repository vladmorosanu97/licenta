﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;

namespace HealthyFood.BusinessLogic.Models.PrimitiveModels.MessageModels
{
    public class Content: ValueObject
    {
        public string Value { get; }

        private Content(string value)
        {
            Value = value;
        }

        public static Result<Content> Create(Maybe<string> contentOrNothing)
        {
            return contentOrNothing.ToResult("Content should not be empty")
                .OnSuccess(content => content.Trim())
                .Ensure(content => content != string.Empty, "Email should not be empty")
                .Ensure(content => content.Length <= 1024, "Email is too long")
                .Map(content => new Content(content));
        }

        public static explicit operator Content(string email)
        {
            return Create(email).Value;
        }

        public static implicit operator string(Content email)
        {
            return email.Value;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }
    }
}
