﻿namespace HealthyFood.BusinessLogic.Models.PrimitiveModels.Images
{
    public class ImageBlModel
    {
        public long ImageId { get; set; }
        public string Name { get; set; }
        public string Base64 { get; set; }
        public string ImagePath { get; set; }
        public string GuidPathName { get; set; }
    }
}
