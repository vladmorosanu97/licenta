﻿using System;
using System.Collections.Generic;
using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models.DapperModels;

namespace HealthyFood.BusinessLogic.Models
{
    public partial class AdvertisementBlModel
    {
        public long AdvertisementId { get; set; }
        public long CreatedById { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public long CategoryId { get; set; }
        public string LocationName { get; set; }
        public decimal? Longitude { get; set; }
        public decimal? Latitude { get; set; }
        public bool HomeDelivery { get; set; }
        public bool IsDisabled { get; set; }
        public bool IsDeleted { get; set; }
        public long? DeletedById { get; set; }
        public string DeactivationReason { get; set; }
        public byte UnitTypeId { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }
        public string PhoneNumber { get; set; }

        public virtual CategoryBlModel Category { get; set; }
        public virtual UserCard CreatedBy { get; set; }
        public virtual UserBlModel DeletedBy { get; set; }
        public virtual UnitTypeBlModel UnitType { get; set; }
        public virtual ICollection<AdvertisementImageBlModel> AdvertisementImages { get; set; }
    }
}
