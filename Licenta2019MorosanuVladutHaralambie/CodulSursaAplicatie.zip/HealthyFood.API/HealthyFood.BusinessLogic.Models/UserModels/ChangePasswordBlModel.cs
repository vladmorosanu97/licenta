﻿using HealthyFood.Data.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models.UserModels
{
    public class ChangePasswordBlModel
    {
        public Password CurrentPassword { get; set; }
        public Password NewPassword { get; set; }
    }
}
