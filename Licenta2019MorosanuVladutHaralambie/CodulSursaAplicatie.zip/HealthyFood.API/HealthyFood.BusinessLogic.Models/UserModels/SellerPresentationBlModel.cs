﻿using HealthyFood.Data.Models.AdvertisementModels;
using HealthyFood.Data.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models.UserModels
{
    public class SellerPresentationBlModel
    {
        public long UserId { get; set; }
        public Description Description { get; set; }
        public PhotoPath ProfilePath { get; set; }
        public PhotoPath BannerPath { get; set; }
    }
}
