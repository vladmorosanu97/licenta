﻿namespace HealthyFood.BusinessLogic.Models.UserModels
{
    public class SearchAdvertisementsBlModel
    {
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
        public int MaxDistance { get; set; }
        public int PageNumber { get; set; }
        public string SearchText { get; set; }
        public long UserId { get; set; }
        public bool IsSearchByDistance { get; set; }
    }
}
