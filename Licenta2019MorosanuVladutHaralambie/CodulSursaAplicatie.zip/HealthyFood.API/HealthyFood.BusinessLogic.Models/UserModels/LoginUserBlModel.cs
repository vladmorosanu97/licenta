﻿using HealthyFood.Data.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models.UserModels
{
    public class LoginUserBlModel
    {
        public Email Email { get; set; }
        public Password Password { get; set; }
    }
}
