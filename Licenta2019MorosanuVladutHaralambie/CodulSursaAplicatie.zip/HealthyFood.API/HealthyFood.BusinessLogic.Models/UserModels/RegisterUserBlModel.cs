﻿using System;
using HealthyFood.Data.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models.UserModels
{
    public class RegisterUserBlModel
    {
        public UserName FirstName { get; set; }
        public UserName LastName { get; set; }
        public Email Email { get; set; }
        public Password Password { get; set; }
        public Guid ActivationToken { get; set; } = Guid.NewGuid();
    }
}
