﻿namespace HealthyFood.BusinessLogic.Models
{
    public class CategoryBlModel
    {
        public long CategoryId { get; set; }
        public string Name { get; set; }
    }
}
