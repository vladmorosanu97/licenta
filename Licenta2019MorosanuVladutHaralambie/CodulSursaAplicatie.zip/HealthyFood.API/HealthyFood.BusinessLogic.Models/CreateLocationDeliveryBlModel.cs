﻿using System;
using System.Collections.Generic;

namespace HealthyFood.BusinessLogic.Models
{
    public class CreateLocationDeliveryBlModel
    {
        public long AuthorId { get; set; }
        public byte DeliveryTypeId { get; set; }
        public DateTime Day { get; set; }
        public List<CreateLocationDeliveryPointBlModel> LocationDeliveryPoints { get; set; }
    }
}