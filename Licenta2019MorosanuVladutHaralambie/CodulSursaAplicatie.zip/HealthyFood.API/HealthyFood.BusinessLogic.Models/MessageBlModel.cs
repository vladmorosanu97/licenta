﻿using System;
using HealthyFood.BusinessLogic.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models
{
    public partial class MessageBlModel
    {
        public long MessageId { get; set; }
        public long ChatId { get; set; }
        public long AuthorId { get; set; }
        public string Content { get; set; }
        public bool Seen { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual UserBlModel Author { get; set; }
        public virtual ChatBlModel Chat { get; set; }
    }
}
