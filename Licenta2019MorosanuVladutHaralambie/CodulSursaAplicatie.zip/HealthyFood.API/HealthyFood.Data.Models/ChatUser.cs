﻿using System;

namespace HealthyFood.Data.Models
{
    public partial class ChatUser
    {
        public long ChatUserId { get; set; }
        public long ChatId { get; set; }
        public long UserId { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual Chat Chat { get; set; }
        public virtual User User { get; set; }
    }
}
