﻿using System;

namespace HealthyFood.Data.Models
{
    public partial class UserClaim
    {
        public long UserClaimId { get; set; }
        public long UserId { get; set; }
        public string ClaimType { get; set; }
        public string ClaimValue { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual User User { get; set; }
    }
}
