﻿using System;
using System.Collections.Generic;

namespace HealthyFood.Data.Models
{
    public partial class AdvertisementTrending
    {
        public long AdvertisementTrendingId { get; set; }
        public long AdvertisementId { get; set; }
        public decimal TrendingValue { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual Advertisement Advertisement { get; set; }
    }
}
