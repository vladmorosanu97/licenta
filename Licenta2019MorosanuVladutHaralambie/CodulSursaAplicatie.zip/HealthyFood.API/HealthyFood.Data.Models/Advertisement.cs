﻿using System;
using System.Collections.Generic;

namespace HealthyFood.Data.Models
{
    public partial class Advertisement
    {
        public Advertisement()
        {
            AdvertisementImages = new HashSet<AdvertisementImage>();
        }

        public long AdvertisementId { get; set; }
        public long CreatedById { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public long CategoryId { get; set; }
        public string LocationName { get; set; }
        public decimal? Longitude { get; set; }
        public decimal? Latitude { get; set; }
        public bool HomeDelivery { get; set; }
        public bool IsDisabled { get; set; }
        public bool IsDeleted { get; set; }
        public long? DeletedById { get; set; }
        public string DeactivationReason { get; set; }
        public byte UnitTypeId { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual Category Category { get; set; }
        public virtual User CreatedBy { get; set; }
        public virtual User DeletedBy { get; set; }
        public virtual UnitType UnitType { get; set; }
        public virtual ICollection<AdvertisementImage> AdvertisementImages { get; set; }
        public virtual ICollection<AdvertisementHistory> AdvertisementsHistory { get; set; }
        public virtual ICollection<AdvertisementTrending> AdvertisementsTrending { get; set; }
    }
}
