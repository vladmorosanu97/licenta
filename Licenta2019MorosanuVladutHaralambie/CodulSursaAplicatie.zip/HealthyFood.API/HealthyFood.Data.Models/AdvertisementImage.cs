﻿using System;

namespace HealthyFood.Data.Models
{
    public partial class AdvertisementImage
    {
        public int AdvertisementImageId { get; set; }
        public long AdvertisementId { get; set; }
        public string FileName { get; set; }
        public string GuidFileName { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual Advertisement Advertisement { get; set; }
    }
}
