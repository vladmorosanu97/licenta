﻿using System;

namespace HealthyFood.Data.Models
{
    public partial class HomeDeliveryPoint
    {
        public long HomeDeliveryPointId { get; set; }
        public long DeliveryId { get; set; }
        public DateTime ArrivalTime { get; set; }
        public long UserId { get; set; }
        public string Description { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual Delivery Delivery { get; set; }
        public virtual User User { get; set; }
    }
}
