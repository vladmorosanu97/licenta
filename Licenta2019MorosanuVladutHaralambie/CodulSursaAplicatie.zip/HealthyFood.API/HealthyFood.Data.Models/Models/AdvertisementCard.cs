﻿namespace HealthyFood.Data.Models.DapperModels
{
    public class AdvertisementCard
    {
        public long AdvertisementId { get; set; }
        public string Title { get; set; }
        public decimal Price { get; set; }
        public string LocationName { get; set; }
        public decimal Longitude { get; set; }
        public decimal Latitude { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string GuidFileName { get; set; }
        public string ImagePath { get; set; } 
        public decimal Distance { get; set; }
        public int TotalPages { get; set; }
        public int PageNumber { get; set; }
        public long CategoryId { get; set; }
    }
}
