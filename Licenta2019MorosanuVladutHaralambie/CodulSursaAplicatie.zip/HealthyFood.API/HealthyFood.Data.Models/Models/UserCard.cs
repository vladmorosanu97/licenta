﻿namespace HealthyFood.Data.Models.DapperModels
{
    public class UserCard
    {
        public long UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Role { get; set; }
        public decimal Distance { get; set; }
        public int AdvertisementsCount { get; set; }
        public string RelationshipStatus { get; set; }
        public long RelationshipRelatingUserId { get; set; }
        public decimal Rating { get; set; }
        public decimal ReviewsCount { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public string AvatarUrl { get; set; }
    }
}