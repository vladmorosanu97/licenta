﻿using System;
using System.Collections.Generic;

namespace HealthyFood.Data.Models
{
    public partial class LocationDeliveryPoint
    {
        public LocationDeliveryPoint()
        {
            LocationDeliveryPointsUsers = new HashSet<LocationDeliveryPointsUser>();
        }

        public long LocationDeliveryPointId { get; set; }
        public long DeliveryId { get; set; }
        public string LocationName { get; set; }
        public decimal Longitude { get; set; }
        public decimal Latitude { get; set; }
        public DateTime TimeStart { get; set; }
        public DateTime TimeEnd { get; set; }
        public string Description { get; set; }
        public bool IsForAllFriends { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual Delivery Delivery { get; set; }
        public virtual ICollection<LocationDeliveryPointsUser> LocationDeliveryPointsUsers { get; set; }
    }
}
