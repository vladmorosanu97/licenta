﻿using System;

namespace HealthyFood.Data.Models
{
    public partial class Review
    {
        public long ReviewId { get; set; }
        public long CreatorId { get; set; }
        public long RecipientId { get; set; }
        public string Content { get; set; }
        public decimal Mark { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual User Creator { get; set; }
        public virtual User Recipient { get; set; }
    }
}
