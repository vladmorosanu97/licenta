﻿using System;
using System.Collections.Generic;

namespace HealthyFood.Data.Models
{
    public partial class AdvertisementHistory
    {
        public long AdvertisementHistoryId { get; set; }
        public long UserId { get; set; }
        public long AdvertisementId { get; set; }
        public DateTime? Created { get; set; }

        public virtual Advertisement Advertisement { get; set; }
        public virtual User User { get; set; }
    }
}
