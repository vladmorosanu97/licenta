﻿using System;

namespace HealthyFood.Data.Models
{
    public partial class SearchHistory
    {
        public long SearchHistoryId { get; set; }
        public long UserId { get; set; }
        public long SearchSuggestionId { get; set; }
        public DateTime? Created { get; set; }

        public virtual SearchSuggestion SearchSuggestion { get; set; }
        public virtual User User { get; set; }
    }
}
