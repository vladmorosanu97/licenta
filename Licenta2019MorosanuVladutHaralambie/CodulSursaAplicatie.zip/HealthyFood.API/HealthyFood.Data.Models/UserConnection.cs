﻿using System;

namespace HealthyFood.Data.Models
{
    public partial class UserConnection
    {
        public int UserConnectionId { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }
        public long UserId { get; set; }
        public bool IsOnline { get; set; }
        public string ConnectionId { get; set; }

        public virtual User User { get; set; }
    }
}
