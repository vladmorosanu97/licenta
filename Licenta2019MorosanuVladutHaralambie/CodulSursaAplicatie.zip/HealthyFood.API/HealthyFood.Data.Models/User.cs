﻿using System;
using System.Collections.Generic;

namespace HealthyFood.Data.Models
{
    public sealed partial class User
    {
        public User()
        {
            AdminsInvitedByNavigation = new HashSet<Admin>();
            AdminsUser = new HashSet<Admin>();
            AdvertisementsCreatedBy = new HashSet<Advertisement>();
            AdvertisementsDeletedBy = new HashSet<Advertisement>();
            AdvertisementsHistory = new HashSet<AdvertisementHistory>();
            ChatUsers = new HashSet<ChatUser>();
            InverseLockoutByNavigation = new HashSet<User>();
            Messages = new HashSet<Message>();
            ReviewsCreator = new HashSet<Review>();
            ReviewsRecipient = new HashSet<Review>();
            SearchHistory = new HashSet<SearchHistory>();
            SearchSuggestions = new HashSet<SearchSuggestion>();
            SellerScore = new HashSet<SellerScore>();
            SellerPresentations = new HashSet<SellerPresentation>();
            RelationshipsRelatedUser = new HashSet<Relationship>();
            RelationshipsRelatingUser = new HashSet<Relationship>();
            UserClaims = new HashSet<UserClaim>();
            UserConnections = new HashSet<UserConnection>();
        }

        public long UserId { get; set; }
        public string Email { get; set; }
        public bool EmailConfirmed { get; set; }
        public string PasswordHash { get; set; }
        public string PhoneNumber { get; set; }
        public bool PhoneNumberConfirmed { get; set; }
        public string ActivationToken { get; set; }
        public bool TwoFactorEnabled { get; set; }
        public bool LockoutEnabled { get; set; }
        public bool IsLockedOut { get; set; }
        public long? LockoutBy { get; set; }
        public string LockoutReason { get; set; }
        public int AccessFailedCount { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }
        public string LocationName { get; set; }
        public decimal? Longitude { get; set; }
        public decimal? Latitude { get; set; }
        public bool AutomaticallyUpdateLocation { get; set; }
        public string HomeLocationName { get; set; }
        public decimal? HomeLongitude { get; set; }
        public decimal? HomeLatitude { get; set; }
        public byte? Rating { get; set; }
        public string AvatarName { get; set; }
        public string GuidAvatarName { get; set; }

        public User LockoutByNavigation { get; set; }
        public ICollection<Admin> AdminsInvitedByNavigation { get; set; }
        public ICollection<Admin> AdminsUser { get; set; }
        public ICollection<Advertisement> AdvertisementsCreatedBy { get; set; }
        public ICollection<Advertisement> AdvertisementsDeletedBy { get; set; }
        public ICollection<AdvertisementHistory> AdvertisementsHistory { get; set; }
        public ICollection<ChatUser> ChatUsers { get; set; }
        public ICollection<Delivery> Deliveries { get; set; }
        public ICollection<HomeDeliveryPoint> HomeDeliveryPoints { get; set; }
        public ICollection<User> InverseLockoutByNavigation { get; set; }
        public ICollection<LocationDeliveryPointsUser> LocationDeliveryPointsUsers { get; set; }
        public ICollection<Message> Messages { get; set; }
        public ICollection<Review> ReviewsCreator { get; set; }
        public ICollection<Review> ReviewsRecipient { get; set; }
        public ICollection<SearchHistory> SearchHistory { get; set; }
        public ICollection<SearchSuggestion> SearchSuggestions { get; set; }
        public ICollection<SellerScore> SellerScore { get; set; }
        public ICollection<SellerPresentation> SellerPresentations { get; set; }
        public ICollection<Relationship> RelationshipsRelatedUser { get; set; }
        public ICollection<Relationship> RelationshipsRelatingUser { get; set; }
        public ICollection<UserClaim> UserClaims { get; set; }
        public ICollection<UserConnection> UserConnections { get; set; }
    }
}