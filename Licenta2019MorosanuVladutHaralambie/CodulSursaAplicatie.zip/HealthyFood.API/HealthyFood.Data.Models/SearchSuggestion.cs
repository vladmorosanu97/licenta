﻿using System;
using System.Collections.Generic;

namespace HealthyFood.Data.Models
{
    public partial class SearchSuggestion
    {
        public SearchSuggestion()
        {
            SearchHistory = new HashSet<SearchHistory>();
            SearchSuggestionTrending = new HashSet<SearchSuggestionTrending>();
        }

        public long SearchSuggestionId { get; set; }
        public string Text { get; set; }
        public long AuthorId { get; set; }
        public long Count { get; set; }
        public DateTime? Created { get; set; }

        public virtual User Author { get; set; }
        public virtual ICollection<SearchHistory> SearchHistory { get; set; }
        public virtual ICollection<SearchSuggestionTrending> SearchSuggestionTrending { get; set; }
    }
}