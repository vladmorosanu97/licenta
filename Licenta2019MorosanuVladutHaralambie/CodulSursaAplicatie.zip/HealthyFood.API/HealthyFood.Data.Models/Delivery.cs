﻿using System;
using System.Collections.Generic;

namespace HealthyFood.Data.Models
{
    public partial class Delivery
    {
        public Delivery()
        {
            HomeDeliveryPoints = new HashSet<HomeDeliveryPoint>();
            LocationDeliveryPoints = new HashSet<LocationDeliveryPoint>();
        }

        public long DeliveryId { get; set; }
        public byte DeliveryTypeId { get; set; }
        public long AuthorId { get; set; }
        public DateTime Day { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual User Author { get; set; }
        public virtual DeliveryType DeliveryType { get; set; }
        public virtual ICollection<HomeDeliveryPoint> HomeDeliveryPoints { get; set; }
        public virtual ICollection<LocationDeliveryPoint> LocationDeliveryPoints { get; set; }
    }
}
