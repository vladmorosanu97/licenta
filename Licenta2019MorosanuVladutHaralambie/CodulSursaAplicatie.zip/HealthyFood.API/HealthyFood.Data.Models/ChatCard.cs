﻿using System;

namespace HealthyFood.Data.Models
{
    public class ChatCard
    {
        public long ChatId { get; set; }
        public string Name { get; set; }
        public User User { get; set; }
        public int MessagesCount { get; set; }
        public bool IsOnline { get; set; }
        public long TotalMessages { get; set; }

        public decimal Rating { get; set; }
        public DateTime? LastTimeOnline { get; set; }
    }
}