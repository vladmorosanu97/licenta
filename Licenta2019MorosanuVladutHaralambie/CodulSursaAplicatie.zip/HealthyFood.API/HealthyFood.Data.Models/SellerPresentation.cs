﻿using System;

namespace HealthyFood.Data.Models
{
    public partial class SellerPresentation
    {
        public long SellerPresentationId { get; set; }
        public long UserId { get; set; }
        public string Description { get; set; }
        public string BannerName { get; set; }
        public string GuidBannerName { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual User User { get; set; }
    }
}
