﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Models;
using HealthyFood.BusinessLogic.Models.Mappers;
using HealthyFood.BusinessLogic.Models.PrimitiveModels.AdvertisementModels;
using HealthyFood.BusinessLogic.Models.PrimitiveModels.Images;
using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;
using HealthyFood.Data.Models.DapperModels;
using HealthyFood.Utils;
using HealthyFood.Utils.FileUtils;
using ImageMagick;

namespace HealthyFood.BusinessLogic.Implementation
{
    public class AdvertisementService : IAdvertisementService
    {
        private readonly IAdvertisementRepository _advertisementRepository;
        private readonly AppSettings _appSettings;

        public AdvertisementService(IAdvertisementRepository advertisementRepository, AppSettings appSettings)
        {
            _advertisementRepository = advertisementRepository;
            _appSettings = appSettings;
        }

        public Result<long> CreateAdvertisement(AdvertisementBlModel model)
        {
            return _advertisementRepository.CreateAdvertisement(model.GetDataModel());
        }

        public Result UpdateAdvertisement(AdvertisementBlModel model)
        {
            return _advertisementRepository.UpdateAdvertisement(model.GetDataModel());
        }

        public Result AddPhotoToAdvertisement(List<ImageBlModel> model, long advertisementId)
        {
            var folderName = _appSettings.Images.AdvertisementsPath;
            FileUtils.CreateDirectoryIfNotExists(folderName);
            var currentFile = 0;
            var advertisementImages = new List<AdvertisementImageBlModel>();
            foreach (var image in model)
            {
                if (image.ImagePath != null)
                {
                    var advertisementImage = new AdvertisementImageBlModel()
                    {
                        FileName = image.Name,
                        AdvertisementId = advertisementId,
                        GuidFileName = image.GuidPathName,
                    };
                    advertisementImages.Add(advertisementImage);
                }
                else
                {
                    var advertisementImage = new AdvertisementImageBlModel()
                    {
                        FileName = image.Name,
                        AdvertisementId = advertisementId,
                        GuidFileName = Guid.NewGuid() + Path.GetExtension(image.Name),
                    };

                    advertisementImages.Add(advertisementImage);
                    var fullPath = Path.Combine(folderName, advertisementImage.GuidFileName);

                    byte[] bytes = Convert.FromBase64String(image.Base64.Split(',')[1]);
                    System.IO.File.WriteAllBytes(fullPath, bytes);

                    var cardFullPath = _appSettings.Images.AdvertisementsCardPath;
                    FileUtils.CreateDirectoryIfNotExists(cardFullPath);

                    //                var optimizer = new ImageOptimizer();
                    //                optimizer.Compress(file);
                    //                file.Refresh();
                    if (currentFile != 0)
                    {
                        continue;
                    }

                    var firstPhoto = advertisementImages.FirstOrDefault();
                    if (firstPhoto != null)
                    {
                        fullPath = Path.Combine(folderName, firstPhoto.GuidFileName);
                        var cardFilePath = Path.Combine(cardFullPath, firstPhoto.GuidFileName);
                        System.IO.File.Copy(fullPath, cardFilePath);

                        var file = new FileInfo(cardFilePath);
                        MagickImage sprite = new MagickImage(file);
                        sprite.Format = MagickFormat.Jpeg;
                        sprite.Quality = 30;
                        sprite.Resize(400, 0);
                        sprite.Write(file);
                    }
                }

                currentFile++;
            }


            return _advertisementRepository.AddAdvertisementImages(advertisementImages.Select(a => a.GetDataModel())
                .ToList());
        }

        private void UpdateSearchSuggestions(SearchAdvertisementsBlModel model)
        {
            Result<long> searchSuggestionResult =
                _advertisementRepository.GetSearchSuggestionIdByText(model.SearchText);
            if (searchSuggestionResult.IsSuccess)
            {
                _advertisementRepository.CountSearchSuggestion(searchSuggestionResult.Value);
                var searchHistory = new SearchHistory()
                {
                    UserId = model.UserId,
                    SearchSuggestionId = searchSuggestionResult.Value,
                };
                _advertisementRepository.CreateSearchHistory(searchHistory);
            }
            else if (!string.IsNullOrEmpty(model.SearchText))
            {
                var suggestion = new SearchSuggestion()
                {
                    AuthorId = model.UserId,
                    Count = 1,
                    Text = model.SearchText
                };
                var suggestionId = _advertisementRepository.CreateSearchSuggestion(suggestion).Value;
                var searchHistory = new SearchHistory()
                {
                    UserId = model.UserId,
                    SearchSuggestionId = suggestionId,
                };
                _advertisementRepository.CreateSearchHistory(searchHistory);
            }
        }

        public IEnumerable<AdvertisementCard> GetAdvertisementsCards(SearchAdvertisementsBlModel model)
        {
            var advertisements = _advertisementRepository.GetAdvertisementsCards(model.Latitude, model.Longitude,
                model.MaxDistance,
                model.PageNumber, model.UserId, model.SearchText);

            if (model.IsSearchByDistance == false)
            {
                UpdateSearchSuggestions(model);
            }


            return advertisements;
        }

        public IEnumerable<AdvertisementCard> GetUserAdvertisementsCards(decimal? latitude, decimal? longitude,
            long userId)
        {
            var advertisements = _advertisementRepository.GetUserAdvertisementsCards(latitude, longitude,
                userId);
            return advertisements;
        }

        public byte[] GetFileAdvertisementCard(string guidFileName)
        {
            if (guidFileName == null)
            {
                return null;
            }

            var folderName = _appSettings.Images.AdvertisementsCardPath;
            var fullPath = Path.Combine(folderName, guidFileName);
            return System.IO.File.ReadAllBytes(fullPath);
        }

        public byte[] GetFileAdvertisement(string guidFileName)
        {
            if (guidFileName == null)
            {
                return null;
            }

            var folderName = _appSettings.Images.AdvertisementsPath;
            var fullPath = Path.Combine(folderName, guidFileName);
            return System.IO.File.ReadAllBytes(fullPath);
        }

        public IEnumerable<SearchSuggestionDapper> GetSearchSuggestions(SearchText text, long userId)
        {
            return _advertisementRepository.GetSearchSuggestions(text, userId);
        }

        public Result<AdvertisementBlModel> GetAdvertisementById(long advertisementId)
        {
            Result<Advertisement> advertisementResult = _advertisementRepository.GetAdvertisementById(advertisementId);
            if (advertisementResult.IsFailure)
            {
                return Result.Fail<AdvertisementBlModel>(advertisementResult.Error);
            }

            var advertisement = advertisementResult.Value.GetBlModel();
            var advertisementImageBlModels = advertisement.AdvertisementImages.Select(a =>
            {
                //TODO: Host: 
                a.ImagePath = _appSettings.ServerHost +
                              $"/api/advertisements/photos-advertisement?guidFileName={a.GuidFileName}";
                return a;
            }).ToList();
            advertisement.AdvertisementImages = advertisementImageBlModels;

            return Result.Ok(advertisement);
        }

        public Result DeleteAdvertisementById(long advertisementId)
        {
            return _advertisementRepository.DeleteAdvertisementById(advertisementId);
        }

        public Result AddAdvertisementHistory(long userId, long advertisementId)
        {
            var advertisementHistory = new AdvertisementHistory()
            {
                AdvertisementId = advertisementId,
                UserId = userId
            };
            return _advertisementRepository.AddAdvertisementHistory(advertisementHistory);
        }

        public IEnumerable<AdvertisementCard> GetTrendingAdvertisements(SearchAdvertisementsBlModel model)
        {
            return _advertisementRepository.GetTrendingAdvertisements(model.Latitude, model.Longitude,
                model.MaxDistance, model.UserId);
        }

        public IEnumerable<AdvertisementCard> GetSuggestionsAdvertisements(SearchAdvertisementsBlModel model)
        {
            var advertisementsHistory = _advertisementRepository.GetUserAdvertisementsHistory(model.UserId).ToList();
            if (advertisementsHistory.Count == 0)
            {
                var queryAdvertisements = _advertisementRepository.GetAllAdvertisements();
                var resultCard = queryAdvertisements.Take(30).Select(a => a.GetBlCardModel()).Select(a =>
                {
                    //TODO: Host: 
                    a.ImagePath = _appSettings.ServerHost + "/api/advertisements/photos?guidFileName=" +
                                  queryAdvertisements
                                      .FirstOrDefault(x => x.AdvertisementId == a.AdvertisementId).AdvertisementImages
                                      .FirstOrDefault().GuidFileName;
                    return a;
                }).ToList();

                var resultAdvertisementCards = resultCard.Select(a =>
                {
                    //TODO: Host: 
                    a.Distance = _advertisementRepository.CalculateDistance(model.Latitude, model.Longitude, a.Latitude,
                        a.Longitude, model.UserId);
                    return a;
                }).ToList();

                return resultAdvertisementCards.Where(a => a.Distance <= model.MaxDistance);
            }

            var categories = advertisementsHistory.Select(a => a.CategoryId).ToList();
            var res = categories.GroupBy(a => a).Select(a => new
            {
                Number = a.Key,
                Times = a.Count()
            }).ToList().OrderByDescending(a => a.Times).ToList();
            var advertisements = new List<AdvertisementCard>();
            if (res.Any())
            {
                var queryAdvertisements = _advertisementRepository.GetAllAdvertisements()
                    .Where(a => a.CategoryId == res[0].Number && !advertisementsHistory.Contains(a)).ToList();
                var cards = queryAdvertisements.Select(a => a.GetBlCardModel()).ToList();
                var resultCard = cards.Take(30).Select(a =>
                {
                    //TODO: Host: 
                    a.ImagePath = _appSettings.ServerHost + "/api/advertisements/photos?guidFileName=" +
                                  queryAdvertisements
                                      .FirstOrDefault(x => x.AdvertisementId == a.AdvertisementId).AdvertisementImages
                                      .FirstOrDefault().GuidFileName;
                    return a;
                }).ToList();
                advertisements.AddRange(resultCard);
            }

            if (res.Count() >= 2)
            {
                var queryAdvertisements = _advertisementRepository.GetAllAdvertisements()
                    .Where(a => a.CategoryId == res[1].Number && !advertisementsHistory.Contains(a)).ToList();
                var cards = queryAdvertisements.Select(a => a.GetBlCardModel()).ToList();
                var resultCard = cards.Take(30).Select(a =>
                {
                    //TODO: Host: 
                    a.ImagePath = _appSettings.ServerHost + "/api/advertisements/photos?guidFileName=" +
                                  queryAdvertisements
                                      .FirstOrDefault(x => x.AdvertisementId == a.AdvertisementId).AdvertisementImages
                                      .FirstOrDefault().GuidFileName;
                    return a;
                }).ToList();
                advertisements.AddRange(resultCard);
            }

            if (res.Count() >= 3)
            {
                var queryAdvertisements = _advertisementRepository.GetAllAdvertisements()
                    .Where(a => a.CategoryId == res[2].Number && !advertisementsHistory.Contains(a)).ToList();
                var cards = queryAdvertisements.Select(a => a.GetBlCardModel()).ToList();
                var resultCard = cards.Take(30).Select(a =>
                {
                    //TODO: Host: 
                    a.ImagePath = _appSettings.ServerHost + "/api/advertisements/photos?guidFileName=" +
                                  queryAdvertisements
                                      .FirstOrDefault(x => x.AdvertisementId == a.AdvertisementId).AdvertisementImages
                                      .FirstOrDefault().GuidFileName;
                    return a;
                }).ToList();
                advertisements.AddRange(resultCard);
            }

            var advs = advertisements.Select(a =>
            {
                //TODO: Host: 
                a.Distance = _advertisementRepository.CalculateDistance(model.Latitude, model.Longitude, a.Latitude,
                    a.Longitude, model.UserId);
                return a;
            }).ToList();


            return advs.Where(a => a.Distance <= model.MaxDistance);
        }
    }
}