﻿using System.Collections.Generic;
using System.Linq;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Models;
using HealthyFood.BusinessLogic.Models.Mappers;
using HealthyFood.Data.Interfaces;

namespace HealthyFood.BusinessLogic.Implementation
{
    public class ReviewService : IReviewService
    {
        private readonly IReviewRepository _reviewRepository;

        public ReviewService(IReviewRepository reviewRepository)
        {
            _reviewRepository = reviewRepository;
        }
        public List<ReviewBlModel> GetReviewsForUserId(long userId)
        {
            return _reviewRepository.GetReviewsForUserId(userId).Select(a => a.GetBlModel()).ToList();
        }

        public Result CreateReview(ReviewBlModel reviewBlModel)
        {
            return _reviewRepository.CreateReview(reviewBlModel.GetDataModel());
        }
    }
}