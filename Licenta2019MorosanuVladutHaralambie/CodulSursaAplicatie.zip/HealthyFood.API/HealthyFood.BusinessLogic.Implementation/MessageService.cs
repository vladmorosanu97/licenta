﻿using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.Data.Interfaces;

namespace HealthyFood.BusinessLogic.Implementation
{
    public class MessageService: IMessageService
    {
        private readonly IMessageRepository _messageRepository;

        public MessageService(IMessageRepository messageRepository)
        {
            _messageRepository = messageRepository;
        }
//        public Result<List<ChatBlModel>> GetChatsForUserId(long userId)
//        {
////            var chatBlModels = _messageRepository.GetChatsForUserId(userId).Value.Select(a => a.GetHomeDeliveryBlModel()).ToList();
////            return Result.Ok(chatBlModels);
//        }
    }
}
