﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using Hangfire;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Interfaces.Hangfire;
using HealthyFood.Data.Models;
using HealthyFood.Utils;

namespace HealthyFood.BusinessLogic.Implementation.Hangfire
{
    public class AdvertisementsTrendingJob : IAdvertisementsTrendingJob
    {
        private readonly IAdvertisementRepository _advertisementRepository;

        public AdvertisementsTrendingJob(IAdvertisementRepository advertisementRepository)
        {
            _advertisementRepository = advertisementRepository;
        }
        public async Task Run(IJobCancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            await RunAtTimeOf(DateTime.Now);
        }

        public async Task RunAtTimeOf(DateTime now)
        {
            var advertisements = _advertisementRepository.GetAllAdvertisements();
            foreach (var advertisement in advertisements)
            {
                Result<List<long>> lastSevenDaysViews =
                    _advertisementRepository.GetViewsCountLastSevenDays(advertisement.AdvertisementId);
                Result<long> todayViews = _advertisementRepository.GetViewsCountToday(advertisement.AdvertisementId);
                Result result = Result.Combine(lastSevenDaysViews, todayViews);
                if (result.IsFailure)
                {
                    throw new ArgumentException(result.Error);
                }

                var trendingValue = TrendingHelper.CalculateTrendingValue(todayViews.Value, lastSevenDaysViews.Value);

                var advertisementTrending = new AdvertisementTrending
                {
                    AdvertisementId = advertisement.AdvertisementId,
                    TrendingValue = (decimal) trendingValue
                };
                await _advertisementRepository.UpdateTrendingValue(advertisementTrending);
            }
        }
    }
}