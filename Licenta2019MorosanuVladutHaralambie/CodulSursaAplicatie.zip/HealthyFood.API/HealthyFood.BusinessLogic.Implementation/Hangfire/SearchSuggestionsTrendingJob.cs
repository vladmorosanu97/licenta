﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using Hangfire;
using HealthyFood.BusinessLogic.Interfaces.Hangfire;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;
using HealthyFood.Utils;

namespace HealthyFood.BusinessLogic.Implementation.Hangfire
{
    public class SearchSuggestionsTrendingJob: ISearchSuggestionsTrendingJob
    {
        private readonly ISearchRepository _searchRepository;

        public SearchSuggestionsTrendingJob(ISearchRepository searchRepository)
        {
            _searchRepository = searchRepository;
        }
        public async Task Run(IJobCancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            await RunAtTimeOf(DateTime.Now);
        }

        public async Task RunAtTimeOf(DateTime now)
        {
            var searchSuggestions = _searchRepository.GetAllSearchSuggestions();

            /*
             * foreach (var advertisement in advertisements)
            {
                Result<List<long>> lastSevenDaysViews =
                    _advertisementRepository.GetViewsCountLastSevenDays(advertisement.AdvertisementId);
                Result<long> todayViews = _advertisementRepository.GetViewsCountToday(advertisement.AdvertisementId);
                Result result = Result.Combine(lastSevenDaysViews, todayViews);
                if (result.IsFailure)
                {
                    throw new ArgumentException(result.Error);
                }

                var trendingValue = TrendingHelper.CalculateTrendingValue(todayViews.Value, lastSevenDaysViews.Value);

                var advertisementTrending = new AdvertisementTrending
                {
                    AdvertisementId = advertisement.AdvertisementId,
                    TrendingValue = (decimal) trendingValue
                };
                await _advertisementRepository.UpdateTrendingValue(advertisementTrending);
            }
             */

            foreach (var searchSuggestion in searchSuggestions)
            {
                Result<List<long>> lastSevenDaysViews =
                    _searchRepository.GetViewsCountLastSevenDays(searchSuggestion.SearchSuggestionId);
                Result<long> todayViews = _searchRepository.GetViewsCountToday(searchSuggestion.SearchSuggestionId);
                Result result = Result.Combine(lastSevenDaysViews, todayViews);
                if (result.IsFailure)
                {
                    throw new ArgumentException(result.Error);
                }

                var trendingValue = TrendingHelper.CalculateTrendingValue(todayViews.Value, lastSevenDaysViews.Value);

                var searchSuggestionTrending = new SearchSuggestionTrending
                {
                    SearchSuggestionId = searchSuggestion.SearchSuggestionId,
                    TrendingValue = (decimal)trendingValue
                };
                await _searchRepository.UpdateSearchSuggestionTrending(searchSuggestionTrending);
            }
        }
    }
}
