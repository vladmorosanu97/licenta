﻿using System;
using Hangfire;
using HealthyFood.BusinessLogic.Implementation.Hangfire;

namespace HealthyFood.BusinessLogic.Implementation.Hangfire
{
    public class HangfireJobScheduler
    {
        public static void ScheduleRecurringJobs()
        {
            RecurringJob.RemoveIfExists(recurringJobId: nameof(AdvertisementsTrendingJob));
            RecurringJob.AddOrUpdate<AdvertisementsTrendingJob>(nameof(AdvertisementsTrendingJob),
                job => job.Run(JobCancellationToken.Null),
                () => "*/15 * * * *",
                timeZone: TimeZoneInfo.Local
            );

            RecurringJob.RemoveIfExists(recurringJobId: nameof(SearchSuggestionsTrendingJob));
            RecurringJob.AddOrUpdate<SearchSuggestionsTrendingJob>(nameof(SearchSuggestionsTrendingJob),
                job => job.Run(JobCancellationToken.Null),
                () => "*/15 * * * *",
                timeZone: TimeZoneInfo.Local
            );
        }
    }
}