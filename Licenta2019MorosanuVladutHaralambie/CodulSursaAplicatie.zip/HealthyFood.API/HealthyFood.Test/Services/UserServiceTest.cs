﻿using System;
using System.Linq;
using FluentAssertions;
using HealthyFood.BusinessLogic.Implementation;
using HealthyFood.BusinessLogic.Models.Mappers;
using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Implementation.Repositories;
using HealthyFood.Data.Models;
using HealthyFood.Tests.Utils;
using HealthyFood.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace HealthyFood.Tests.Services
{
    [TestClass]
    public class UserServiceTest : IDisposable
    {
        private DatabaseContext _databaseContext;
        private UserService _userService;
        private UserRepository _userRepository;
        private RegisterUserBlModel _registerUserBlModel;
        private AppSettings _appSettings;

        [TestInitialize]
        public void InitializeTest()
        {
            InitializeAppSettings();
            InitializeDatabaseContext();
            InitializeVariables();
        }

        public void InitializeAppSettings()
        {
            _appSettings = ConfigurationHelper.GetApplicationConfiguration();
        }

        public void InitializeDatabaseContext()
        {
            var options = new DbContextOptionsBuilder<DatabaseContext>()
                .UseInMemoryDatabase(databaseName: "HealthyFoodTest")
                .Options;
            _databaseContext = new DatabaseContext(options, _appSettings);
            _databaseContext.Database.EnsureDeleted();
            _databaseContext.Database.EnsureCreated();
        }

        public void InitializeVariables()
        {
            _userRepository = new Mock<UserRepository>(_databaseContext).Object;
            _userService = new Mock<UserService>(_userRepository, _appSettings).Object;

//            _registerUserBlModel = new RegisterUserBlModel
//            {
//                Email = (Email) "vladmorosanu@gmail.com",
//                Password = (Password) "Steaua123",
//                Role = (Role) "seller",
//                LastName = (UserName) "Morosanu",
//                FirstName = (UserName) "Vlad",
//                PhoneNumber = "0757599282",
//            };
//
//            _user = _registerUserBlModel.GetHomeDeliveryBlModel();
//            _user.PasswordHash = SecurePasswordHasher.Hash(_registerUserBlModel.Password);
        }

        [TestMethod]
        public void GeneratePasswordHash_ValidPassword_ReturnsValidPasswordHash()
        {
            //Arrange
            var passwordHash = SecurePasswordHasher.Hash(_registerUserBlModel.Password);

            //Act
            var result = _userService.GeneratePasswordHash(_registerUserBlModel.Password);

            //Assert
            result.Should().NotBeNullOrEmpty();
        }

        [TestMethod]
        public void CreateUser_WithValidRegisterUserObject_ReturnsSuccessfulResult()
        {
            //Arrange

            //Act
            var result = _userService.CreateUser(_registerUserBlModel);
            var user = _databaseContext.Users
                .Include(a => a.UserClaims)
                .FirstOrDefault(a => a.Email == _registerUserBlModel.Email);

            //Assert
            result.IsSuccess.Should().BeTrue();
            user.Should().NotBeNull();
            user.UserClaims.Should().NotBeNull();
        }

        [TestMethod]
        public void CreateUser_WhenUserAlreadyExists_ReturnsFailedResult()
        {
            //Arrange
            var user = _registerUserBlModel.GetDataModel();
            _databaseContext.Users.Add(user);
            _databaseContext.SaveChanges();

            //Act
            var result = _userService.CreateUser(_registerUserBlModel);

            //Assert
            result.IsFailure.Should().BeTrue();
        }

        [TestMethod]
        public void GenerateToken_WithValidUserAndClaims_ReturnsValidToken()
        {
//            //Arrange
//            _databaseContext.User.Add(_registerUserBlModel.GetHomeDeliveryBlModel());
//            _databaseContext.SaveChanges();
//            var userViewModel = _databaseContext.User.FirstOrDefault(a => a.Email == _registerUserBlModel.Email)
//                .GetHomeDeliveryBlModel();
//            var claims = new List<Claim>
//            {
//                new Claim(ClaimTypes.Role, _registerUserBlModel.Role)
//            };
//
//            //Act
//            var result = _userService.GenerateToken(userViewModel, claims);
//
//            //Assert
//            result.IsSuccess.Should().BeTrue();
//            result.Value.Should().NotBeNull();
        }

        [TestMethod]
        public void GenerateToken_WithNonexistentUser_ReturnsFailedResult()
        {
//            //Arrange
//            var userViewModel = _registerUserBlModel.GetHomeDeliveryBlModel().GetHomeDeliveryBlModel();
//            var claims = new List<Claim>
//            {
//                new Claim(ClaimTypes.Role, _registerUserBlModel.Role)
//            };
//
//            //Act;
//            var result = _userService.GenerateToken(userViewModel, claims);
//
//            //Assert
//            result.IsFailure.Should().BeTrue();
        }

        [TestCleanup]
        public void CleanupTest()
        {
            Dispose();
        }

        public void Dispose()
        {
            _databaseContext?.Dispose();
            _userRepository?.Dispose();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }
}