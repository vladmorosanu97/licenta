using System;
using System.Linq;
using CSharpFunctionalExtensions;
using FluentAssertions;
using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Implementation.Repositories;
using HealthyFood.Data.Models;
using HealthyFood.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HealthyFood.Tests.Repositories
{
    [TestClass]
    public class UserRepositoryTest : IDisposable
    {
        private DatabaseContext _databaseContext;
        private UserRepository _userRepository;
        private User _user;
        private RegisterUserBlModel _registerUserBlModel;

        [TestInitialize]
        public void InitializeTest()
        {
            InitializeDatabaseContext();
//            InitializeVariables();
        }

        public void InitializeDatabaseContext()
        {
            AppSettings configuration = new AppSettings();
            var options = new DbContextOptionsBuilder<DatabaseContext>()
                .UseInMemoryDatabase(databaseName: "HealthyFoodTest")
                .Options;
            _databaseContext = new DatabaseContext(options, configuration);
            _databaseContext.Database.EnsureDeleted();
            _databaseContext.Database.EnsureCreated();
        }

//        public void InitializeVariables()
//        {
//            _userRepository = new Mock<UserRepository>(_databaseContext).Object;
//
//            _registerUserBlModel = new RegisterUserBlModel
//            {
//                Email = (Email) "vladmorosanu@gmail.com",
//                Password = (Password) "Steaua123",
//                Role = (Role) "seller",
//                LastName = (UserName) "Morosanu",
//                FirstName = (UserName) "Vlad",
//                PhoneNumber = "0757599282",
//            };
//
//            _user = _registerUserBlModel.GetHomeDeliveryBlModel();
//            _user.PasswordHash = SecurePasswordHasher.Hash(_registerUserBlModel.Password);
//        }

        [TestMethod]
        public void CreateUser_WithValidParameters_ReturnsSuccessfulResult()
        {
            //Arrange
            var user = _user;

            //Act
            Result result = _userRepository.CreateUser(user);
            var userAfterInsert = _databaseContext.Users.FirstOrDefault(a => a.Email == user.Email);

            //Assert
            result.IsSuccess.Should().BeTrue();
            userAfterInsert.Should().NotBeNull();
        }

        [TestMethod]
        public void CreateUser_WhenUserAlreadyExists_ReturnsFailedResult()
        {
            //Arrange
            var user = _user;
            _databaseContext.Users.Add(user);
            _databaseContext.SaveChanges();

            //Act
            Result result = _userRepository.CreateUser(user);

            //Assert
            result.IsFailure.Should().BeTrue();
        }


        //CheckPassword
        [TestMethod]
        public void CheckPassword_WithValidCredentials_ReturnsSuccessfulResult()
        {
            //Arrange
            var user = _user;
            _databaseContext.Users.Add(user);
            _databaseContext.SaveChanges();

            //Act
            Result result = _userRepository.CheckPassword(user.Email, _registerUserBlModel.Password);

            //Assert
            result.IsSuccess.Should().BeTrue();
        }

        [TestMethod]
        public void CheckPassword_WithInvalidPassword_ReturnsFailedResult()
        {
            //Arrange
            var user = _user;
            _databaseContext.Users.Add(user);
            _databaseContext.SaveChanges();

            //Act
            Result result = _userRepository.CheckPassword(user.Email, "InvalidPassword");

            //Assert
            result.IsFailure.Should().BeTrue();
            result.Error.Should().Be("Invalid password");
        }

        [TestMethod]
        public void CheckPassword_WithInvalidEmail_ReturnsFailedResult()
        {
            //Arrange
            var user = _user;
            _databaseContext.Users.Add(user);
            _databaseContext.SaveChanges();

            //Act
            Result result = _userRepository.CheckPassword("fakeEmail", _registerUserBlModel.Password);

            //Assert
            result.IsFailure.Should().BeTrue();
            result.Error.Should().Be("Invalid user email");
        }

        [TestMethod]
        public void FindByEmail_WithValidEmail_ReturnsUserFromDatabase()
        {
            //Arrange
            var user = _user;
            _databaseContext.Users.Add(user);
            _databaseContext.SaveChanges();

            //Act
            var result = _userRepository.FindByEmail(user.Email);

            //Assert
            result.IsSuccess.Should().BeTrue();
            result.Value.HasValue.Should().BeTrue();
            result.Value.Value.Should().BeOfType(typeof(User));
        }


        [TestMethod]
        public void FindByEmail_WithNonexistentEmail_ReturnsFailedResult()
        {
            //Arrange
            var user = _user;
            _databaseContext.Users.Add(user);
            _databaseContext.SaveChanges();

            //Act
            var result = _userRepository.FindByEmail("nonexistentEmail");

            //Assert
            result.IsSuccess.Should().BeTrue();
            result.Value.HasNoValue.Should().BeTrue();
        }


//        [TestMethod]
//        public void AddClaim_WithValidUserAndClaims_ReturnsSuccessfulResult()
//        {
//            //Arrange
//            var registerUserModel = _registerUserBlModel;
//            var user = _user;
//            _databaseContext.User.Add(user);
//            _databaseContext.SaveChanges();
//            var claim = new Claim(ClaimTypes.Role, registerUserModel.Role.Value);
//
//            //Act
//            var result = _userRepository.AddClaim(user, claim);
//
//            //Assert
//            result.IsSuccess.Should().BeTrue();
//            var userClaims = _databaseContext.User.Include(a => a.UserClaim)
//                .FirstOrDefault(a => a.Email == user.Email)
//                ?.UserClaim;
//            userClaims.Should().NotBeNull();
//            userClaims.Count().Should().BeGreaterThan(0);
//        }

//        [TestMethod]
//        public void AddClaim_WithInvalidUserAndValidClaim_ReturnsFailedResult()
//        {
//            //Arrange
//            var registerUserModel = _registerUserBlModel;
//            var user = _user;
//            user.Email = "faceEmail";
//            var claim = new Claim(ClaimTypes.Role, registerUserModel.Role.Value);
//
//            //Act
//            var result = _userRepository.AddClaim(user, claim);
//
//            //Assert
//            result.IsFailure.Should().BeTrue();
//        }

//        [TestMethod]
//        public void GetClaims_WithValidUser_ReturnsClaims()
//        {
//            //Arrange
//            var registerUser = _registerUserBlModel;
//            var user = _user;
//            var claim = new Claim(ClaimTypes.Role, registerUser.Role.Value);
//            var userClaim = new UserClaim { ClaimType = claim.Type, ClaimValue = claim.Value };
//            _databaseContext.User.Add(user);
//            _databaseContext.SaveChanges();
//
//            var userToUpdate = _databaseContext.User.FirstOrDefault(a => a.Email == _user.Email);
//            userToUpdate.UserClaim.Add(userClaim);
//            _databaseContext.SaveChanges();
//
//            //Act
//            var result = _userRepository.GetUserClaims(userToUpdate);
//
//            //Assert
//            result.Count().Should().BeGreaterThan(0);
//        }

        [TestMethod]
        public void GetClaims_WithNonExistentUserClaims_ReturnsClaims()
        {
            //Arrange
            var user = _user;
            user.Email = "otherEmail@gmail.com";
            _databaseContext.Users.Add(user);
            _databaseContext.SaveChanges();

            //Act
            var result = _userRepository.GetUserClaims(user);
            //Assert
            result.Count().Should().Be(0);
;        }

        [TestMethod]
        public void UserCount()
        {
            //Arrange

            var users = _databaseContext.Users;
            _databaseContext.SaveChanges();

            //Assert
            users.Count().Should().Be(0);
            ;
        }

        [TestCleanup]
        public void CleanupTest()
        {
            Dispose();
        }

        public void Dispose()
        {
            _databaseContext?.Dispose();
            _userRepository?.Dispose();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }
}