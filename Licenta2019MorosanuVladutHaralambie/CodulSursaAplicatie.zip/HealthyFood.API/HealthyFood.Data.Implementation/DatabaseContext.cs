﻿using HealthyFood.Utils;
using Microsoft.EntityFrameworkCore;

namespace HealthyFood.Data.Models
{
    public partial class DatabaseContext : DbContext
    {
        private readonly AppSettings _configuration;

        public DatabaseContext()
        {
        }

        public DatabaseContext(DbContextOptions<DatabaseContext> options, AppSettings configuration)
            : base(options)
        {
            _configuration = configuration;
        }

        public virtual DbSet<Admin> Admins { get; set; }
        public virtual DbSet<Advertisement> Advertisements { get; set; }
        public virtual DbSet<Category> Categories { get; set; }
        public virtual DbSet<ChatUser> ChatUsers { get; set; }
        public virtual DbSet<Chat> Chats { get; set; }
        public virtual DbSet<Message> Messages { get; set; }
        public virtual DbSet<Review> Reviews { get; set; }
        public virtual DbSet<SellerScore> SellerScore { get; set; }
        public virtual DbSet<SellerPresentation> SellerPresentations { get; set; }
        public virtual DbSet<Relationship> Relationships { get; set; }
        public virtual DbSet<UserClaim> UserClaims { get; set; }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<UnitType> UnitTypes { get; set; }
        public virtual DbSet<AdvertisementImage> AdvertisementImages { get; set; }
        public virtual DbSet<SearchHistory> SearchHistory { get; set; }
        public virtual DbSet<SearchSuggestion> SearchSuggestions { get; set; }
        public virtual DbSet<SearchSuggestionTrending> SearchSuggestionTrending { get; set; }
        public virtual DbSet<UserConnection> UserConnections { get; set; }
        public virtual DbSet<Delivery> Deliveries { get; set; }
        public virtual DbSet<DeliveryType> DeliveryTypes { get; set; }
        public virtual DbSet<HomeDeliveryPoint> HomeDeliveryPoints { get; set; }
        public virtual DbSet<LocationDeliveryPoint> LocationDeliveryPoints { get; set; }
        public virtual DbSet<LocationDeliveryPointsUser> LocationDeliveryPointsUsers { get; set; }
        public virtual DbSet<AdvertisementHistory> AdvertisementsHistory { get; set; }
        public virtual DbSet<AdvertisementTrending> AdvertisementsTrending { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(_configuration.ConnectionStrings.DefaultConnection);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.3-servicing-35854");


            modelBuilder.Entity<SearchHistory>(entity =>
            {
                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.SearchSuggestion)
                    .WithMany(p => p.SearchHistory)
                    .HasForeignKey(d => d.SearchSuggestionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SearchHistory_ToSearchSuggestions");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.SearchHistory)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SearchHistory_ToUsers");
            });

            modelBuilder.Entity<SearchSuggestion>(entity =>
            {
                entity.HasKey(e => e.SearchSuggestionId)
                    .HasName("PK__SearchSu__8FDF4054F037A3AE");

                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Text)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.HasOne(d => d.Author)
                    .WithMany(p => p.SearchSuggestions)
                    .HasForeignKey(d => d.AuthorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SearchSuggestions_ToUsers");
            });


            modelBuilder.Entity<Admin>(entity =>
            {
                entity.HasKey(e => e.AdminId)
                    .HasName("PK__Admins__719FE488DEE3DF47");

                entity.ToTable("Admins", "Identity");

                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Modified)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.InvitedByNavigation)
                    .WithMany(p => p.AdminsInvitedByNavigation)
                    .HasForeignKey(d => d.InvitedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Admins_InvitedBy");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.AdminsUser)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Admins_UserId");
            });

            modelBuilder.Entity<AdvertisementImage>(entity =>
            {
                entity.HasKey(e => e.AdvertisementImageId)
                    .HasName("PK__Advertis__B7300D7472E34A2E");

                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FileName)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.GuidFileName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Modified)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Advertisement)
                    .WithMany(p => p.AdvertisementImages)
                    .HasForeignKey(d => d.AdvertisementId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AdvertisementImages_ToTableAdvertisements");
            });

            modelBuilder.Entity<Advertisement>(entity =>
            {
                entity.HasKey(e => e.AdvertisementId)
                    .HasName("PK__Advertis__C4C7F4CDF442C773");

                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DeactivationReason).HasMaxLength(256);

                entity.Property(e => e.Latitude).HasColumnType("decimal(21, 18)");

                entity.Property(e => e.LocationName)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Longitude).HasColumnType("decimal(21, 18)");

                entity.Property(e => e.Modified)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PhoneNumber)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Price).HasColumnType("money");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.Advertisements)
                    .HasForeignKey(d => d.CategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Advertisements_CategoryId");

                entity.HasOne(d => d.CreatedBy)
                    .WithMany(p => p.AdvertisementsCreatedBy)
                    .HasForeignKey(d => d.CreatedById)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Advertisements_CreatedBy");

                entity.HasOne(d => d.DeletedBy)
                    .WithMany(p => p.AdvertisementsDeletedBy)
                    .HasForeignKey(d => d.DeletedById)
                    .HasConstraintName("FK_Advertisements_DeletedBy");

                entity.HasOne(d => d.UnitType)
                    .WithMany(p => p.Advertisements)
                    .HasForeignKey(d => d.UnitTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Advertisements_UnitTypeId");
            });

            modelBuilder.Entity<AdvertisementHistory>(entity =>
            {
                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Advertisement)
                    .WithMany(p => p.AdvertisementsHistory)
                    .HasForeignKey(d => d.AdvertisementId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AdvertisementsHistory_ToAdvertisements");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.AdvertisementsHistory)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AdvertisementsHistory_ToUsers");
            });

            modelBuilder.Entity<AdvertisementTrending>(entity =>
            {
                entity.HasKey(e => e.AdvertisementTrendingId)
                    .HasName("PK__tmp_ms_x__644B3CDC7535ED22");

                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Modified).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.TrendingValue).HasColumnType("decimal(18, 6)");

                entity.HasOne(d => d.Advertisement)
                    .WithMany(p => p.AdvertisementsTrending)
                    .HasForeignKey(d => d.AdvertisementId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AdvertisementsTrending_ToAdvertisements");
            });

            modelBuilder.Entity<Category>(entity =>
            {
                entity.HasKey(e => e.CategoryId)
                    .HasName("PK__Categori__19093A0BD03A52FE");

                entity.ToTable("Categories", "Core");

                entity.Property(e => e.CategoryId).ValueGeneratedNever();

                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Modified)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(256);
            });

            modelBuilder.Entity<ChatUser>(entity =>
            {
                entity.HasKey(e => e.ChatUserId)
                    .HasName("PK__tmp_ms_x__BFA9F7908701B356");

                entity.ToTable("ChatUsers", "Chat");

                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Modified)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Chat)
                    .WithMany(p => p.ChatUsers)
                    .HasForeignKey(d => d.ChatId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ChatUsers_ChatId");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.ChatUsers)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ChatUsers_UserId");
            });

            modelBuilder.Entity<Chat>(entity =>
            {
                entity.HasKey(e => e.ChatId)
                    .HasName("PK__tmp_ms_x__A9FBE7C6E912A917");

                entity.ToTable("Chats", "Chat");

                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Modified)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(256);
            });

            modelBuilder.Entity<Delivery>(entity =>
            {
                entity.HasKey(e => e.DeliveryId)
                    .HasName("PK__Deliveri__626D8FCEF70A6A37");

                entity.ToTable("Deliveries", "Delivery");

                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Day).HasColumnType("date");

                entity.Property(e => e.Modified).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Author)
                    .WithMany(p => p.Deliveries)
                    .HasForeignKey(d => d.AuthorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Deliveries_ToUsers");

                entity.HasOne(d => d.DeliveryType)
                    .WithMany(p => p.Deliveries)
                    .HasForeignKey(d => d.DeliveryTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Deliveries_ToDeliveryTypes");
            });

            modelBuilder.Entity<DeliveryType>(entity =>
            {
                entity.HasKey(e => e.DeliveryTypeId)
                    .HasName("PK__Delivery__6B117964FD5B7384");

                entity.ToTable("DeliveryTypes", "Delivery");

                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Modified).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<HomeDeliveryPoint>(entity =>
            {
                entity.HasKey(e => e.HomeDeliveryPointId)
                    .HasName("PK__tmp_ms_x__2C896F6D9854389E");

                entity.ToTable("HomeDeliveryPoints", "Delivery");

                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(512);

                entity.Property(e => e.Modified).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Delivery)
                    .WithMany(p => p.HomeDeliveryPoints)
                    .HasForeignKey(d => d.DeliveryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_HomeDeliveryPoints_ToDeliveries");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.HomeDeliveryPoints)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_HomeDeliveryPoints_ToUsers");
            });

            modelBuilder.Entity<LocationDeliveryPoint>(entity =>
            {
                entity.HasKey(e => e.LocationDeliveryPointId)
                    .HasName("PK__tmp_ms_x__9D060F599FD41D7A");

                entity.ToTable("LocationDeliveryPoints", "Delivery");

                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(512);

                entity.Property(e => e.Latitude).HasColumnType("decimal(21, 18)");

                entity.Property(e => e.LocationName)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.Longitude).HasColumnType("decimal(21, 18)");

                entity.Property(e => e.Modified).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Delivery)
                    .WithMany(p => p.LocationDeliveryPoints)
                    .HasForeignKey(d => d.DeliveryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LocationDeliveryPoints_ToDeliveries");
            });

            modelBuilder.Entity<LocationDeliveryPointsUser>(entity =>
            {
                entity.HasKey(e => e.LocationDeliveryPointUserId)
                    .HasName("PK__tmp_ms_x__29478AAE57303210");

                entity.ToTable("LocationDeliveryPointsUsers", "Delivery");

                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Modified).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.LocationDeliveryPoint)
                    .WithMany(p => p.LocationDeliveryPointsUsers)
                    .HasForeignKey(d => d.LocationDeliveryPointId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LocationDeliveryPointsUsers_ToLocationDeliveryPoints");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.LocationDeliveryPointsUsers)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LocationDeliveryPointsUsers_ToUsers");
            });



            modelBuilder.Entity<Message>(entity =>
            {
                entity.HasKey(e => e.MessageId)
                    .HasName("PK__Messages__C87C0C9CE466EA21");

                entity.ToTable("Messages", "Chat");

                entity.Property(e => e.Content).IsRequired();

                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Modified).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Author)
                    .WithMany(p => p.Messages)
                    .HasForeignKey(d => d.AuthorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Messages_AuthorId");

                entity.HasOne(d => d.Chat)
                    .WithMany(p => p.Messages)
                    .HasForeignKey(d => d.ChatId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Messages_ChatId");
            });

            modelBuilder.Entity<Review>(entity =>
            {
                entity.HasKey(e => e.ReviewId)
                    .HasName("PK__tmp_ms_x__74BC79CEE62A821D");

                entity.Property(e => e.Content).HasMaxLength(2048);

                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Mark).HasColumnType("decimal(4, 2)");

                entity.Property(e => e.Modified)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Creator)
                    .WithMany(p => p.ReviewsCreator)
                    .HasForeignKey(d => d.CreatorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Reviews_CreatorId");

                entity.HasOne(d => d.Recipient)
                    .WithMany(p => p.ReviewsRecipient)
                    .HasForeignKey(d => d.RecipientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Reviews_RecipientId");
            });

            modelBuilder.Entity<SellerScore>(entity =>
            {
                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Modified)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Score).HasColumnType("decimal(18, 0)");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.SellerScore)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SellerScore_SellerId");
            });

            modelBuilder.Entity<SearchSuggestionTrending>(entity =>
            {
                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Modified).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.TrendingValue).HasColumnType("decimal(18, 6)");

                entity.HasOne(d => d.SearchSuggestion)
                    .WithMany(p => p.SearchSuggestionTrending)
                    .HasForeignKey(d => d.SearchSuggestionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SearchSuggestionTranding_ToSearchSuggestions");
            });

            modelBuilder.Entity<SellerPresentation>(entity =>
            {
                entity.HasKey(e => e.SellerPresentationId)
                    .HasName("PK__SellerPr__28CDA6A2F1E56B08");

                entity.Property(e => e.BannerName).HasMaxLength(256);

                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.GuidBannerName).HasMaxLength(256);

                entity.Property(e => e.Modified)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.SellerPresentations)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Sellers_UserId");
            });

            modelBuilder.Entity<Relationship>(entity =>
            {
                entity.HasKey(e => e.RelationshipId)
                    .HasName("PK__Relation__31FEB8818D5779EC");

                entity.ToTable("Relationships", "Identity");

                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Modified)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Type)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.RelatedUser)
                    .WithMany(p => p.RelationshipsRelatedUser)
                    .HasForeignKey(d => d.RelatedUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Subscribes_SubscribeTo");

                entity.HasOne(d => d.RelatingUser)
                    .WithMany(p => p.RelationshipsRelatingUser)
                    .HasForeignKey(d => d.RelatingUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Subscribes_UserId");
            });

            modelBuilder.Entity<UnitType>(entity =>
            {
                entity.HasKey(e => e.UnitTypeId)
                    .HasName("PK__UnitType__1B7AB934B61D6D83");

                entity.ToTable("UnitTypes", "Core");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<UserClaim>(entity =>
            {
                entity.HasKey(e => e.UserClaimId);

                entity.ToTable("UserClaims", "Identity");

                entity.Property(e => e.ClaimType).HasMaxLength(512);

                entity.Property(e => e.ClaimValue).HasMaxLength(512);

                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Modified)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserClaims)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserClaims");
            });

            modelBuilder.Entity<UserConnection>(entity =>
            {
                entity.HasKey(e => e.UserConnectionId)
                    .HasName("PK__tmp_ms_x__A90AF3DA6A7D1D0C");

                entity.Property(e => e.ConnectionId)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Modified).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserConnections)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserConnections_ToUsers");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.ToTable("Users", "Identity");

                entity.HasIndex(e => e.Email)
                    .HasName("AK_Email")
                    .IsUnique();

                entity.Property(e => e.ActivationToken)
                    .IsRequired()
                    .HasMaxLength(48);

                entity.Property(e => e.AvatarName).HasMaxLength(255);

                entity.Property(e => e.Created)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.FirstName).HasMaxLength(50);

                entity.Property(e => e.GuidAvatarName).HasMaxLength(255);

                entity.Property(e => e.HomeLatitude).HasColumnType("decimal(21, 18)");

                entity.Property(e => e.HomeLocationName).HasMaxLength(255);

                entity.Property(e => e.HomeLongitude).HasColumnType("decimal(21, 18)");

                entity.Property(e => e.LastName).HasMaxLength(50);

                entity.Property(e => e.Latitude).HasColumnType("decimal(21, 18)");

                entity.Property(e => e.LocationName).HasMaxLength(255);

                entity.Property(e => e.LockoutReason).HasMaxLength(512);

                entity.Property(e => e.Longitude).HasColumnType("decimal(21, 18)");

                entity.Property(e => e.Modified)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PhoneNumber).HasMaxLength(50);

                entity.HasOne(d => d.LockoutByNavigation)
                    .WithMany(p => p.InverseLockoutByNavigation)
                    .HasForeignKey(d => d.LockoutBy)
                    .HasConstraintName("FK_Users_LockoutBy");
            });
        }
    }
}