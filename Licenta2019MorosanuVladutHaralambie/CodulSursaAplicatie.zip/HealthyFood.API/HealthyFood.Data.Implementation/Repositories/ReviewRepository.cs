﻿using System.Collections.Generic;
using System.Linq;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace HealthyFood.Data.Implementation.Repositories
{
    public class ReviewRepository: IReviewRepository
    {
        private readonly DatabaseContext _databaseContext;

        public ReviewRepository(DatabaseContext databaseContext)
        {
            _databaseContext = databaseContext;
        }
        public List<Review> GetReviewsForUserId(long userId)
        {
            return _databaseContext.Reviews.Include(a => a.Creator).Where(a => a.RecipientId == userId).ToList();
        }

        public Result CreateReview(Review review)
        {
            _databaseContext.Reviews.Add(review);
            _databaseContext.SaveChanges();
            return Result.Ok();
        }
    }
}
