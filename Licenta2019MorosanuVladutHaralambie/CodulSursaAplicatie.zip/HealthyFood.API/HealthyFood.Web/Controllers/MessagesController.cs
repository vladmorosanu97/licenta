﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HealthyFood.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MessagesController : BaseController
    {
        /*
        private readonly IHubContext<MessageHub> _messageHub;

        public MessagesController(IHubContext<MessageHub> messageHub)
        {
            _messageHub = messageHub;
        }
        */
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Get()
        {
            return Ok(new { Message = "Request Completed" });
        }
    }
}