﻿using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Models.PrimitiveModels.Deliveries;
using HealthyFood.Web.Mappers;
using HealthyFood.Web.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HealthyFood.Web.Controllers
{
    public class DeliveriesController : BaseController
    {
        private readonly IDeliveryService _deliveryService;

        public DeliveriesController(IDeliveryService deliveryService)
        {
            _deliveryService = deliveryService;
        }

        [Authorize(Policy = "seller")]
        [HttpPost("location-deliveries")]
        public IActionResult CreateLocationDelivery(CreateLocationDeliveryViewModel model)
        {
            Result deliveryTypeResult = _deliveryService.ValidateDeliveryTypeId(model.DeliveryTypeId);
            Result dayResult = DeliveryDay.Create(model.Day);
            Result deliveryPointsResult = model.LocationDeliveryPoints.Count <= 0
                ? Result.Fail("At least one delivery point required")
                : Result.Ok();

            Result result = Result.Combine(deliveryTypeResult, dayResult, deliveryPointsResult);
            if (result.IsFailure)
                return BadRequest(result.Error);


            var authenticatedUserId = GetUserClaims().UserId;
            var blModel = model.GetBlModel(authenticatedUserId);

            var locationDeliveryResult = _deliveryService.CreateLocationDelivery(blModel);
            if (locationDeliveryResult.IsFailure)
            {
                return BadRequest(locationDeliveryResult.Error);
            }

            return Ok();
        }



        [Authorize(Policy = "seller")]
        [HttpPost("home-deliveries")]
        public IActionResult CreateHomeDelivery(CreateHomeDeliveryViewModel model)
        {
            Result deliveryTypeResult = _deliveryService.ValidateDeliveryTypeId(model.DeliveryTypeId);
            Result dayResult = DeliveryDay.Create(model.Day);
            Result deliveryPointsResult = model.HomeDeliveryPoints.Count <= 0
                ? Result.Fail("At least one delivery point required")
                : Result.Ok();

            Result result = Result.Combine(deliveryTypeResult, dayResult, deliveryPointsResult);
            if (result.IsFailure)
                return BadRequest(result.Error);


            var authenticatedUserId = GetUserClaims().UserId;
            var blModel = model.GetBlModel(authenticatedUserId);

            var homeDeliveryResult = _deliveryService.CreateHomeDelivery(blModel);
            if (homeDeliveryResult.IsFailure)
            {
                return BadRequest(homeDeliveryResult.Error);
            }

            return Ok();
        }

        [Authorize(Policy = "seller-client")]
        [HttpGet("location-deliveries")]
        public IActionResult GetLocationDeliveries()
        {
           
            var userId = GetUserClaims().UserId;

            var locationDeliveryResult = _deliveryService.GetLocationDeliveries(userId);
            if (locationDeliveryResult.IsFailure)
            {
                return BadRequest(locationDeliveryResult.Error);
            }

            return Ok(locationDeliveryResult.Value);
        }



        [Authorize(Policy = "seller-client")]
        [HttpGet("home-deliveries")]
        public IActionResult GetHomeDeliveries()
        {

            var userId = GetUserClaims().UserId;

            var homeDeliveries = _deliveryService.GetHomeDeliveries(userId);
            if (homeDeliveries.IsFailure)
            {
                return BadRequest(homeDeliveries.Error);
            }

            return Ok(homeDeliveries.Value);
        }



        [Authorize(Policy = "seller-client")]
        [HttpGet("user-location-deliveries")]
        public IActionResult GetUserLocationDeliveries()
        {

            var userId = GetUserClaims().UserId;

            var locationDeliveryResult = _deliveryService.GetUserLocationDeliveries(userId);
            if (locationDeliveryResult.IsFailure)
            {
                return BadRequest(locationDeliveryResult.Error);
            }

            return Ok(locationDeliveryResult.Value);
        }

        [Authorize(Policy = "seller-client")]
        [HttpGet("user-home-deliveries")]
        public IActionResult GetUserHomeDeliveries()
        {

            var userId = GetUserClaims().UserId;

            var homeDeliveries = _deliveryService.GetUserHomeDeliveries(userId);
            if (homeDeliveries.IsFailure)
            {
                return BadRequest(homeDeliveries.Error);
            }

            return Ok(homeDeliveries.Value);
        }
    }
}