﻿using System.Linq;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Models;
using HealthyFood.BusinessLogic.Models.PrimitiveModels.AdvertisementModels;
using HealthyFood.Data.Models.AdvertisementModels;
using HealthyFood.Data.Models.UserModels;
using HealthyFood.Utils;
using HealthyFood.Web.Mappers;
using HealthyFood.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HealthyFood.Web.Controllers
{
    public class AdvertisementsController : BaseController
    {
        private readonly ICategoryService _categoryService;
        private readonly IAdvertisementService _advertisementService;
        private readonly IUnitService _unitService;

        public AdvertisementsController(ICategoryService categoryService,
            IAdvertisementService advertisementService, IUnitService unitService)
        {
            _categoryService = categoryService;
            _advertisementService = advertisementService;
            _unitService = unitService;
        }

        [Authorize(Policy = "seller")]
        [HttpPost]
        public IActionResult AddAdvertisement(NewAdvertisementViewModel model)
        {
            var userClaims = GetUserClaims();
            if (model == null)
            {
                return BadRequest("Invalid user model");
            }

            Result<Title> titleResult = Title.Create(model.Title);
            Result categoryResult = _categoryService.ValidateCategoryId(model.CategoryId);
            Result<PhoneNumber> phoneNumberResult = PhoneNumber.Create(model.PhoneNumber);
            Result<Description> descriptionResult = Description.Create(model.Description);
            Result<Location> locationNameResult = Location.Create(model.LocationName);
            Result<Coordinate> latitudeResult = Coordinate.Create(model.Latitude);
            Result<Coordinate> longitudeResult = Coordinate.Create(model.Longitude);
            Result unitTypeResult = _unitService.ValidateUnitTypeId(model.UnitTypeId);
            Result<Price> priceResult = Price.Create(model.Price);

            Result result = Result.Combine(titleResult, categoryResult, phoneNumberResult, descriptionResult,
                latitudeResult, locationNameResult, longitudeResult, unitTypeResult, priceResult);
            if (result.IsFailure)
                return BadRequest(result.Error);

            var advertisement = new AdvertisementBlModel()
            {
                Description = descriptionResult.Value,
                CategoryId = model.CategoryId,
                CreatedById = userClaims.UserId,
                Latitude = latitudeResult.Value,
                Longitude = longitudeResult.Value,
                LocationName = locationNameResult.Value,
                Price = priceResult.Value,
                Title = titleResult.Value,
                UnitTypeId = model.UnitTypeId,
                PhoneNumber = phoneNumberResult.Value
            };

            Result<long> createAdvertisementResult = _advertisementService.CreateAdvertisement(advertisement);
            if (createAdvertisementResult.IsFailure)
            {
                return BadRequest(result.Error);
            }

            Result addPhotosToAdvertisement =
                _advertisementService.AddPhotoToAdvertisement(model.Images.Select(a => a.GetBlModel()).ToList(),
                    createAdvertisementResult.Value);

            if (addPhotosToAdvertisement.IsFailure)
            {
                return BadRequest(addPhotosToAdvertisement.Error);
            }

            return Ok();
        }

        [Authorize(Policy = "seller")]
        [HttpPut]
        public IActionResult UpdateAdvertisement(NewAdvertisementViewModel model)
        {
            var userClaims = GetUserClaims();
            if (model == null)
            {
                return BadRequest("Invalid user model");
            }

            Result<Title> titleResult = Title.Create(model.Title);
            Result categoryResult = _categoryService.ValidateCategoryId(model.CategoryId);
            Result<PhoneNumber> phoneNumberResult = PhoneNumber.Create(model.PhoneNumber);
            Result<Description> descriptionResult = Description.Create(model.Description);
            Result<Location> locationNameResult = Location.Create(model.LocationName);
            Result<Coordinate> latitudeResult = Coordinate.Create(model.Latitude);
            Result<Coordinate> longitudeResult = Coordinate.Create(model.Longitude);
            Result unitTypeResult = _unitService.ValidateUnitTypeId(model.UnitTypeId);
            Result<Price> priceResult = Price.Create(model.Price);

            Result result = Result.Combine(titleResult, categoryResult, phoneNumberResult, descriptionResult,
                latitudeResult, locationNameResult, longitudeResult, unitTypeResult, priceResult);
            if (result.IsFailure)
                return BadRequest(result.Error);

            var advertisement = new AdvertisementBlModel()
            {
                Description = descriptionResult.Value,
                CategoryId = model.CategoryId,
                CreatedById = userClaims.UserId,
                Latitude = latitudeResult.Value,
                Longitude = longitudeResult.Value,
                LocationName = locationNameResult.Value,
                Price = priceResult.Value,
                Title = titleResult.Value,
                UnitTypeId = model.UnitTypeId,
                PhoneNumber = phoneNumberResult.Value,
                AdvertisementId = model.AdvertisementId ?? 0
            };

            Result createAdvertisementResult = _advertisementService.UpdateAdvertisement(advertisement);
            if (createAdvertisementResult.IsFailure)
            {
                return BadRequest(result.Error);
            }

            Result addPhotosToAdvertisement =
                _advertisementService.AddPhotoToAdvertisement(model.Images.Select(a => a.GetBlModel()).ToList(),
                    advertisement.AdvertisementId
                );

            if (addPhotosToAdvertisement.IsFailure)
            {
                return BadRequest(addPhotosToAdvertisement.Error);
            }

            return Ok();
        }


        [Authorize(Policy = "seller-client")]
        [HttpPost("cards")]
        public IActionResult GetAdvertisementsCard([FromBody] SearchAdvertisementsViewModel model)
        {
            UserClaims userClaims = GetUserClaims();
            model.UserId = userClaims.UserId;
            if (model.SearchText == null ||  string.IsNullOrEmpty(model.SearchText))
            {
                return Ok(_advertisementService.GetSuggestionsAdvertisements(model.GetBlModel()));
            }
            return Ok(_advertisementService.GetAdvertisementsCards(model.GetBlModel()));
        }

        [Authorize(Policy = "seller-client")]
        [HttpGet("{advertisementId}")]
        public IActionResult GetAdvertisementById(long advertisementId)
        {
            Result<AdvertisementBlModel> advertisementResult =
                _advertisementService.GetAdvertisementById(advertisementId);
            if (advertisementResult.IsFailure)
            {
                return BadRequest(advertisementResult.Error);
            }

            var userId = GetUserClaims().UserId;
            _advertisementService.AddAdvertisementHistory(userId, advertisementId);

            return Ok(advertisementResult.Value);
        }

        [Authorize(Policy = "seller")]
        [HttpGet("edit/{advertisementId}")]
        public IActionResult GetAdvertisementByIdForEditing(long advertisementId)
        {
            Result<AdvertisementBlModel> advertisementResult =
                _advertisementService.GetAdvertisementById(advertisementId);
            if (advertisementResult.IsFailure)
            {
                return BadRequest(advertisementResult.Error);
            }

            UserClaims userClaims = GetUserClaims();
            if (userClaims.UserId != advertisementResult.Value.CreatedById)
            {
                return BadRequest("You are not able to edit this advertisement");
            }

            return Ok(advertisementResult.Value);
        }


        [AllowAnonymous]
        [HttpGet("photos")]
        public IActionResult GetAdvertisementsCard(string guidFileName)
        {
            if (guidFileName == null)
            {
                return BadRequest("Value cannot be null");
            }

            return File(_advertisementService.GetFileAdvertisementCard(guidFileName), "image/jpeg");
        }


        [AllowAnonymous]
        [HttpGet("photos-advertisement")]
        public IActionResult GetImage(string guidFileName)
        {
            if (guidFileName == null)
            {
                return BadRequest("Value cannot be null");
            }

            return File(_advertisementService.GetFileAdvertisement(guidFileName), "image/jpeg");
        }


        [Authorize(Policy = "seller-client")]
        [HttpGet("search-suggestions")]
        public IActionResult GetSuggestions(string text)
        {
            UserClaims userClaims = GetUserClaims();
            Result<SearchText> searchTextResult = SearchText.Create(text);
            if (searchTextResult.IsFailure)
            {
                return BadRequest(searchTextResult.Error);
            }

            var suggestions = _advertisementService.GetSearchSuggestions(searchTextResult.Value, userClaims.UserId);
            return Ok(suggestions);
        }

        [Authorize(Policy = "seller")]
        [HttpGet("user-advertisements")]
        public IActionResult GetUserAdvertisements(decimal? longitude, decimal? latitude)
        {
            UserClaims userClaims = GetUserClaims();
            var advertisements =
                _advertisementService.GetUserAdvertisementsCards(latitude, longitude, userClaims.UserId);
            return Ok(advertisements);
        }

        [Authorize(Policy = "seller")]
        [HttpDelete("{advertisementId}")]
        public IActionResult DeleteAdvertisement(long advertisementId)
        {
            var deleteAdvertisementResult = _advertisementService.DeleteAdvertisementById(advertisementId);
            if (deleteAdvertisementResult.IsFailure)
            {
                return BadRequest(deleteAdvertisementResult.Error);
            }

            return Ok();
        }

        [Authorize(Policy = "seller-client")]
        [HttpPost("trending")]
        public IActionResult GeTrendingAdvertisementsCard([FromBody] SearchAdvertisementsViewModel model)
        {
            UserClaims userClaims = GetUserClaims();
            model.UserId = userClaims.UserId;
            return Ok(_advertisementService.GetTrendingAdvertisements(model.GetBlModel()));
        }
    }
}