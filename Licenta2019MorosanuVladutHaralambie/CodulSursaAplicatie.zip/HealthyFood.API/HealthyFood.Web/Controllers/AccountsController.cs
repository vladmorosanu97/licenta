﻿using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models.AdvertisementModels;
using HealthyFood.Data.Models.UserModels;
using HealthyFood.Utils;
using HealthyFood.Web.Mappers;
using HealthyFood.Web.Models;
using HealthyFood.Web.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HealthyFood.Web.Controllers
{
    public class AccountsController : BaseController
    {
        private readonly IUserService _userService;
        private readonly IEmailService _emailService;
        private readonly IPresentationService _presentationService;

        public AccountsController(IUserService userService, IEmailService emailService,
            IPresentationService presentationService)
        {
            _userService = userService;
            _emailService = emailService;
            _presentationService = presentationService;
        }


        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> PostUser(RegisterUserViewModel model)
        {
            if (model == null)
            {
                return BadRequest("Invalid user model");
            }

            Result<UserName> firstName = UserName.Create(model.FirstName);
            Result<UserName> lastName = UserName.Create(model.LastName);
            Result<Email> email = Email.Create(model.Email);
            Result<Password> password = Password.Create(model.Password);

            Result result = Result.Combine(firstName, lastName, email, password);
            if (result.IsFailure)
                return BadRequest(result.Error);


            var user = model.GetBlModel();
            Result resultCreateUser = _userService.CreateUser(user);
            if (resultCreateUser.IsFailure)
            {
                return BadRequest(resultCreateUser.Error);
            }

            new Task(() => { _emailService.SendActivationToken(user.Email, user.ActivationToken); }).Start();

            return Ok(StatusCode(201));
        }

        [Authorize(Policy = "seller-client")]
        [HttpPut]
        public IActionResult UpdateUser(UpdateUserViewModel model)
        {
            if (model == null)
            {
                return BadRequest("Invalid user model");
            }

            Result<UserName> firstName = UserName.Create(model.FirstName);
            Result<UserName> lastName = UserName.Create(model.LastName);
            Result<Email> email = Email.Create(model.Email);
            Result phoneNumber;
            if (model.PhoneNumber != null)
            {
                phoneNumber = PhoneNumber.Create(model.PhoneNumber);
            }
            else
            {
                phoneNumber = Result.Ok();
            }


            Result result = Result.Combine(firstName, lastName, email, phoneNumber);
            if (result.IsFailure)
                return BadRequest(result.Error);

            var userId = GetUserClaims().UserId;
            var user = model.GetBlModel(userId);
            Result updateUserResult = _userService.UpdateUser(user);
            if (updateUserResult.IsFailure)
            {
                return BadRequest(updateUserResult.Error);
            }

            return Ok(StatusCode(200));
        }

        [Authorize(Policy = "seller-client")]
        [HttpPut("password")]
        public IActionResult ChangePassword(ChangePasswordViewModel model)
        {
            if (model == null)
            {
                return BadRequest("Invalid user model");
            }

            Result<Password> currentPasswordResult = Password.Create(model.CurrentPassword);
            Result<UserName> newPasswordResult = UserName.Create(model.NewPassword);
            Result result = Result.Combine(currentPasswordResult, newPasswordResult);
            if (result.IsFailure)
                return BadRequest(result.Error);

            var userId = GetUserClaims().UserId;

            Result changePasswordResult = _userService.UpdatePassword(userId, model.GetBlModel());
            if (changePasswordResult.IsFailure)
            {
                return BadRequest(changePasswordResult.Error);
            }

            return Ok(StatusCode(200));
        }


        [AllowAnonymous]
        [HttpPost("confirm-account")]
        public IActionResult ConfirmAccount(ConfirmAccountViewModel model)
        {
            if (model == null)
            {
                return BadRequest("Invalid user model");
            }

            Result<Location> location = Location.Create(model.LocationName);
            Result<Token> token = Token.Create(model.Token);
            Result<Role> userRole = Role.Create(model.UserRole);
            Result<Coordinate> longitudeCoordinate = Coordinate.Create(model.Longitude);
            Result<Coordinate> latitudeCoordinate = Coordinate.Create(model.Longitude);

            Result result = Result.Combine(location, token, userRole, longitudeCoordinate, latitudeCoordinate);
            if (result.IsFailure)
                return BadRequest(result.Error);

            Result validateToken = _userService.ValidateToken(token.Value);
            if (validateToken.IsFailure)
            {
                return BadRequest(validateToken.Error);
            }

            Result resultCreateUser = _userService.ConfirmAccount(model.GetBlModel());
            if (resultCreateUser.IsFailure)
            {
                return BadRequest(resultCreateUser.Error);
            }

            // TODO: Initialize seller presentation

            var user = _userService.GetUserByToken(token.Value);

            if (model.UserRole == RoleConstants.Seller)
            {
                var registerSeller = new SellerPresentationBlModel {UserId = user.Value.UserId};

                Result createSellerResult = _presentationService.CreateSellerPresentation(registerSeller);
                if (createSellerResult.IsFailure)
                {
                    return BadRequest(createSellerResult.Error);
                }
            }

            return Ok();
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public IActionResult LoginUser([FromForm] LoginUserViewModel model)
        {
            Result<Email> email = Email.Create(model.Username);
            Result<Password> password = Password.Create(model.Password);

            Result result = Result.Combine(email, password);
            if (result.IsFailure)
                return BadRequest(result.Error);

            var resultUser = _userService.CheckCredentials(model.GetBlModel());
            if (resultUser.IsFailure)
            {
                return BadRequest(resultUser.Error);
            }


            var resultClaims = _userService.GetUserClaims(resultUser.Value);


            var resultToken = _userService.GenerateToken(resultUser.Value, resultClaims.Value);
            if (resultToken.IsFailure)
            {
                return BadRequest(resultToken.Error);
            }

            return Ok(resultToken.Value);
        }

        [AllowAnonymous]
        [HttpGet("validate-email")]
        public IActionResult ValidateEmail(string email)
        {
            Result<Email> emailResult = Email.Create(email);
            if (emailResult.IsFailure)
            {
                return BadRequest(emailResult.Error);
            }

            Result validateEmail = _userService.ValidateEmail(emailResult.Value);
            if (validateEmail.IsFailure)
            {
                return BadRequest(validateEmail.Error);
            }

            return Ok();
        }


        [HttpGet("user")]
        public IActionResult UserInfo()
        {
            var userClaims = GetUserClaims();

//                var userInfo = _userService.GetUserClaims();
            return Ok();
        }

        [Authorize(Policy = "seller-client")]
        [HttpPost("friends")]
        public IActionResult GetFriends(SearchUsersViewModel model)
        {
            var userClaims = GetUserClaims();
            return Ok(_userService.GetFriendsCards(userClaims.UserId, model.Latitude, model.Longitude, model.SearchText));
        }

        [Authorize(Policy = "seller-client")]
        [HttpPost("users")]
        public IActionResult GetUsers(SearchUsersViewModel model)
        {
            var userClaims = GetUserClaims();
            return Ok(_userService.GetUsersCards(userClaims.UserId, model.Latitude, model.Longitude, model.SearchText));
        }


        [Authorize(Policy = "seller-client")]
        [HttpGet("requests")]
        public IActionResult GetFriendsRequests()
        {
            var userClaims = GetUserClaims();
            return Ok(_userService.GetFriendsRequestsCards(userClaims.UserId));
        }

        [Authorize(Policy = "seller-client")]
        [HttpGet("friends-search-suggestions")]
        public IActionResult GetFriendsSearchSuggestion(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                return BadRequest("SearchText should not be empty");
            }

            var userId = GetUserClaims().UserId;

            return Ok(_userService.GetFriendsSearchSuggestions(text, userId));
        }

        [Authorize(Policy = "seller-client")]
        [HttpPost("refresh-token")]
        public IActionResult RefreshToken()
        {
            var userId = GetUserClaims().UserId;

            var resultUser = _userService.GetUserById(userId);
            if (resultUser.IsFailure)
            {
                return BadRequest(resultUser.Error);
            }


            var resultClaims = _userService.GetUserClaims(resultUser.Value);


            var resultToken = _userService.GenerateToken(resultUser.Value, resultClaims.Value);
            if (resultToken.IsFailure)
            {
                return BadRequest(resultToken.Error);
            }

            return Ok(resultToken.Value);
        }

        [AllowAnonymous]
        [HttpGet("photos")]
        public IActionResult GetUserAvatarFile(string guidFileName)
        {
            if (guidFileName == null)
            {
                return BadRequest("Value cannot be null");
            }

            return File(_userService.GetAvatarImageFile(guidFileName), "image/jpeg");
        }


        [Authorize(Policy = "seller-client")]
        [HttpGet("locations")]
        public IActionResult GetSavedLocations()
        {
            var userId = GetUserClaims().UserId;

            var savedLocationsResult = _userService.GetSavedLocations(userId);
            if (savedLocationsResult.IsFailure)
            {
                return BadRequest(savedLocationsResult.Error);
            }

            return Ok(savedLocationsResult.Value);
        }

        [Authorize(Policy = "seller-client")]
        [HttpPut("locations")]
        public IActionResult UpdateSavedLocations(UserLocationsViewModel model)
        {
            Result<Location> locationNameResult = Location.Create(model.LocationName);
            Result<Coordinate> latitudeResult = Coordinate.Create(model.Latitude);
            Result<Coordinate> longitudeResult = Coordinate.Create(model.Longitude);

            Result<Location> homeLocationNameResult = Location.Create(model.HomeLocationName);
            Result<Coordinate> homeLatitude = Coordinate.Create(model.HomeLatitude);
            Result<Coordinate> homeLongitude = Coordinate.Create(model.HomeLongitude);

            Result result = Result.Combine(locationNameResult, latitudeResult, longitudeResult, homeLocationNameResult,
                latitudeResult, locationNameResult, longitudeResult, homeLatitude, homeLongitude);
            if (result.IsFailure)
                return BadRequest(result.Error);

            var userId = GetUserClaims().UserId;
            var updateLocationsResult = _userService.UpdateSavedLocations(userId, model.GetBlModel());
            if (updateLocationsResult.IsFailure)
            {
                return BadRequest(updateLocationsResult.Error);
            }

            return Ok();
        }
    }
}