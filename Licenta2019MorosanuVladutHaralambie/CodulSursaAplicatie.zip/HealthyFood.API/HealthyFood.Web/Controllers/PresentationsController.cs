﻿using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.Data.Models.AdvertisementModels;
using HealthyFood.Web.Mappers;
using HealthyFood.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HealthyFood.Web.Controllers
{
    public class PresentationsController : BaseController
    {
        private readonly IPresentationService _presentationService;

        public PresentationsController(IPresentationService presentationService)
        {
            _presentationService = presentationService;
        }

        [Authorize(Policy = "seller-client")]
        [HttpGet("{userId}")]
        public IActionResult GetPresentation(long userId)
        {
            var authenticatedUserId = GetUserClaims().UserId;
            var userPresentationResult = _presentationService.GetUserPresentation(userId, authenticatedUserId);
            if (userPresentationResult.IsFailure)
            {
                return BadRequest(userPresentationResult.Error);
            }

            return Ok(userPresentationResult.Value);
        }

        [Authorize(Policy = "seller")]
        [HttpPost("images")]
        public IActionResult UpdatePresentationBanner(ImageViewModel imageViewModel)

        {
            var userId = GetUserClaims().UserId;
            var updateUserPresentationResult =
                _presentationService.UpdatePresentationPhoto(imageViewModel.GetBlModel(), userId);
            if (updateUserPresentationResult.IsFailure)
            {
                return BadRequest(updateUserPresentationResult.Error);
            }

            return Ok();
        }

        [Authorize(Policy = "seller")]
        [HttpPost("descriptions")]
        public IActionResult UpdatePresentationDescription([FromForm] string description)

        {
            Result<Description> result = Description.Create(description);
            if (result.IsFailure)
            {
                return BadRequest(result.Error);
            }

            var userId = GetUserClaims().UserId;
            var updateUserPresentationResult =
                _presentationService.UpdatePresentationDescription(result.Value, userId);
            if (updateUserPresentationResult.IsFailure)
            {
                return BadRequest(updateUserPresentationResult.Error);
            }

            return Ok();
        }

        [AllowAnonymous]
        [HttpGet("photos")]
        public IActionResult GetUserDescriptionFile(string guidFileName)
        {
            if (guidFileName == null)
            {
                return BadRequest("Value cannot be null");
            }

            return File(_presentationService.GetPresentationImageFile(guidFileName), "image/jpeg");
        }
    }
}