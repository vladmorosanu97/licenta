﻿using HealthyFood.BusinessLogic.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HealthyFood.Web.Controllers
{
    public class RelationshipsController : BaseController
    {
        private readonly IRelationshipService _relationshipService;

        public RelationshipsController(IRelationshipService relationshipService)
        {
            _relationshipService = relationshipService;
        }

        [Authorize(Policy = "seller-client")]
        [HttpPost("send-friend-request/{receiverId}")]
        public IActionResult SendFriendRequest(long receiverId)
        {
            var userId = GetUserClaims().UserId;

            var sendFriendRequestResult = _relationshipService.SendFriendRequest(userId, receiverId);
            if (sendFriendRequestResult.IsFailure)
            {
                return BadRequest(sendFriendRequestResult.Error);
            }

            return Ok();
        }

        [Authorize(Policy = "seller-client")]
        [HttpPost("cancel-friend-request/{receiverId}")]
        public IActionResult CancelFriendRequest(long receiverId)
        {
            var userId = GetUserClaims().UserId;

            var cancelFriendRequest = _relationshipService.CancelFriendRequest(userId, receiverId);
            if (cancelFriendRequest.IsFailure)
            {
                return BadRequest(cancelFriendRequest.Error);
            }

            return Ok();
        }

        [Authorize(Policy = "seller-client")]
        [HttpPost("accept-friend-request/{senderId}")]
        public IActionResult AcceptFriendRequest(long senderId)
        {
            var userId = GetUserClaims().UserId;

            var acceptFriendRequest = _relationshipService.AcceptFriendRequest(userId, senderId);
            if (acceptFriendRequest.IsFailure)
            {
                return BadRequest(acceptFriendRequest.Error);
            }

            return Ok();
        }

        [Authorize(Policy = "seller-client")]
        [HttpPost("remove-friend/{receiverId}")]
        public IActionResult RemoveFriend(long receiverId)
        {
            var userId = GetUserClaims().UserId;

            var acceptFriendRequest = _relationshipService.RemoveFriend(userId, receiverId);
            if (acceptFriendRequest.IsFailure)
            {
                return BadRequest(acceptFriendRequest.Error);
            }

            return Ok();
        }

        [Authorize(Policy = "seller-client")]
        [HttpPost("remove-friend-request/{senderId}")]
        public IActionResult RemoveFriendRequest(long senderId)
        {
            var userId = GetUserClaims().UserId;

            var removeFriendRequest = _relationshipService.RemoveFriendRequest(userId, senderId);
            if (removeFriendRequest.IsFailure)
            {
                return BadRequest(removeFriendRequest.Error);
            }

            return Ok();
        }
    }
}