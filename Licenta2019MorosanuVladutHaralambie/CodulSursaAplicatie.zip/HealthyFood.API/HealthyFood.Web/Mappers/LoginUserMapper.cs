﻿using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models.UserModels;
using HealthyFood.Web.Models;

namespace HealthyFood.Web.Mappers
{
    public static class LoginUserMapper
    {
        public static LoginUserBlModel GetBlModel(this LoginUserViewModel item)
        {
            var userBlModel = new LoginUserBlModel
            {
                Email =(Email) item.Username,
                Password =(Password) item.Password
            };
            return userBlModel;
        }
    }
}
