﻿using HealthyFood.BusinessLogic.Models;
using HealthyFood.Web.ViewModels;

namespace HealthyFood.Web.Mappers
{
    public static class LocationDeliveryPointMapper
    {
        public static CreateLocationDeliveryPointBlModel GetBlModel(this CreateLocationDeliveryPointViewModel model)
        {
            return new CreateLocationDeliveryPointBlModel()
            {
                FriendsList = model.FriendsList,
                IsForAllFriends = model.IsForAllFriends,
                Latitude = model.Latitude,
                LocationName = model.LocationName,
                Longitude = model.Longitude,
                TimeEnd = model.TimeEnd,
                TimeStart = model.TimeStart,
                Description = model.Description
            };
        }

    }
}
