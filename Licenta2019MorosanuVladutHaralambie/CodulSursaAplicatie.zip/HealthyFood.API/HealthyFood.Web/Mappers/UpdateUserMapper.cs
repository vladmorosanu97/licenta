﻿using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Web.ViewModels;

namespace HealthyFood.Web.Mappers
{
    public static class UpdateUserMapper
    {
        public static UpdateUserBlModel GetBlModel(this UpdateUserViewModel itemViewModel, long userId)
        {
            return new UpdateUserBlModel()
            {
                UserId = userId,
                PhoneNumber = itemViewModel.PhoneNumber,
                Avatar = itemViewModel.Avatar?.GetBlModel(),
                Email = itemViewModel.Email,
                FirstName = itemViewModel.FirstName,
                LastName = itemViewModel.LastName,
            };
        }
    }
}
