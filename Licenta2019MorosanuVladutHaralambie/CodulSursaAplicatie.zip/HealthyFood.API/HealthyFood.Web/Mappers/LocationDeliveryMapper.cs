﻿using System.Linq;
using HealthyFood.BusinessLogic.Models;
using HealthyFood.Web.ViewModels;

namespace HealthyFood.Web.Mappers
{
    public static class LocationDeliveryMapper
    {
        public static CreateLocationDeliveryBlModel GetBlModel(this CreateLocationDeliveryViewModel model, long authorId)
        {
            return new CreateLocationDeliveryBlModel()
            {
                Day = model.Day,
                DeliveryTypeId = model.DeliveryTypeId,
                LocationDeliveryPoints = model.LocationDeliveryPoints.Select(a => a.GetBlModel()).ToList(),
                AuthorId = authorId
            };
        }
    }
}
