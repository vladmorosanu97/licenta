﻿using HealthyFood.BusinessLogic.Models;
using HealthyFood.Web.ViewModels;

namespace HealthyFood.Web.Mappers
{
    public static class HomeDeliveryPointMapper
    {
        public static CreateHomeDeliveryPointBlModel GetBlModel(this CreateHomeDeliveryPointViewModel model)
        {
            return new CreateHomeDeliveryPointBlModel()
            {
               UserId = model.UserId,
               ArrivalTime = model.ArrivalTime,
               Description = model.Description
            };
        }
    }
}
