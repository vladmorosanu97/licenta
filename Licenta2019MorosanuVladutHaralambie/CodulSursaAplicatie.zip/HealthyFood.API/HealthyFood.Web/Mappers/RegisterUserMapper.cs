﻿using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models.UserModels;

namespace HealthyFood.Web.Mappers
{
    public static class RegisterUserMapper
    {
        public static RegisterUserBlModel GetBlModel(this RegisterUserViewModel item)
        {
            var userBlModel = new RegisterUserBlModel
            {
                Email =(Email) item.Email,
                FirstName =(UserName) item.FirstName,
                LastName = (UserName) item.LastName,
                Password = (Password) item.Password
            };
            return userBlModel;
        }
    }
}
