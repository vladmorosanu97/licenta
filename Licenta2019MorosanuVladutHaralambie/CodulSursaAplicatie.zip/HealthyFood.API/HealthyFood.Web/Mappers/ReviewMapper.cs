﻿namespace HealthyFood.Web.Mappers
{
    public static class ReviewMapper
    {
    }
}
