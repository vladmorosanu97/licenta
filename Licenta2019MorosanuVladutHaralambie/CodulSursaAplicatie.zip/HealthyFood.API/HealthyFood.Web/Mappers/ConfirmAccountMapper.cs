﻿using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models.UserModels;
using HealthyFood.Web.Models;

namespace HealthyFood.Web.Mappers
{
    public static class ConfirmAccountMapper
    {
        public static ConfirmAccountBlModel GetBlModel(this ConfirmAccountViewModel item)
        {
            var blItem = new ConfirmAccountBlModel
            {
               Token = (Token) item.Token,
               Longitude = (Coordinate) item.Longitude,
               Latitude = (Coordinate) item.Latitude,
               LocationName = (Location)item.LocationName,
               UserRole = (Role) item.UserRole
            };
            return blItem;
        }
    }
}
