﻿using System.Collections.Generic;

namespace HealthyFood.Web.Models
{
    public class NewAdvertisementViewModel
    {
        public long? AdvertisementId { get; set; }
        public string Title { get; set; }
        public int CategoryId { get; set; }
        public string PhoneNumber { get; set; }
        public string Description { get; set; }
        public string LocationName { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public decimal Price { get; set; }
        public byte UnitTypeId { get; set; }
        public List<ImageViewModel> Images { get; set; }
    }
}
