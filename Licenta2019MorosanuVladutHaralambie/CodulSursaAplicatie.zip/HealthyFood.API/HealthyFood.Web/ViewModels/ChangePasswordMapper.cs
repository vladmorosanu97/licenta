﻿using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models.UserModels;

namespace HealthyFood.Web.ViewModels
{
    public static class ChangePasswordMapper
    {
        public static ChangePasswordBlModel GetBlModel(this ChangePasswordViewModel itemViewModel)
        {
            return new ChangePasswordBlModel()
            {
                NewPassword = (Password) itemViewModel.NewPassword,
                CurrentPassword = (Password) itemViewModel.CurrentPassword
            };
        }
    }
}
