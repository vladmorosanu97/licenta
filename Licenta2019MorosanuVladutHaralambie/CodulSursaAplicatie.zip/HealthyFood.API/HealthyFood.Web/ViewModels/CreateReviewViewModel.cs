﻿namespace HealthyFood.Web.ViewModels
{
    public class CreateReviewViewModel
    {
        public decimal Mark { get; set; }
        public string Content { get; set; }
        public long RecipientId { get; set; }
    }
}
