﻿namespace HealthyFood.Web.Models
{
    public class LoginUserViewModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
