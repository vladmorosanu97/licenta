﻿using System;
using System.Collections.Generic;

namespace HealthyFood.Web.ViewModels
{
    public class CreateHomeDeliveryViewModel
    {
        public byte DeliveryTypeId { get; set; }
        public DateTime Day { get; set; }
        public List<CreateHomeDeliveryPointViewModel> HomeDeliveryPoints { get; set; }
    }
}
