﻿using System.Collections.Generic;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Models;

namespace HealthyFood.BusinessLogic.Interfaces
{
    public interface IReviewService
    {
        List<ReviewBlModel> GetReviewsForUserId(long userId);
        Result CreateReview(ReviewBlModel reviewBlModel);
    }
}
