﻿using CSharpFunctionalExtensions;

namespace HealthyFood.BusinessLogic.Interfaces
{
    public interface IRelationshipService
    {
        Result SendFriendRequest(long userId, long receiverId);
        Result CancelFriendRequest(long userId, long receiverId);
        Result AcceptFriendRequest(long userId, long senderId);
        Result RemoveFriendRequest(long userId, long senderId);
        Result RemoveFriend(long userId, long receiverId);
    }
}
