﻿using System;

namespace HealthyFood.Data.Implementation
{
    public interface IBaseRepository: IDisposable
    {
    }
}
