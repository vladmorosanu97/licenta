﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Models;

namespace HealthyFood.Data.Interfaces
{
    public interface ISearchRepository
    {
        List<SearchSuggestion> GetAllSearchSuggestions();
        Result<List<long>> GetViewsCountLastSevenDays(long searchSuggestionId);
        Result<long> GetViewsCountToday(long searchSuggestionId);
        Task<Result> UpdateSearchSuggestionTrending(SearchSuggestionTrending searchSuggestionTrending);
    }
}
