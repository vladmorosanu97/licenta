﻿using System.Collections.Generic;
using System.Data;

namespace HealthyFood.Data.Implementation
{
    public interface IDapperBaseRepository
    {
        IEnumerable<T> QuerySync<T>(string sql, object param = null, CommandType commandType = CommandType.Text);
        T QueryFirstOrDefaultSync<T>(string sql, object param = null, CommandType commandType = CommandType.Text);
        int ExecuteSync(string sql, object param = null);
    }
}
