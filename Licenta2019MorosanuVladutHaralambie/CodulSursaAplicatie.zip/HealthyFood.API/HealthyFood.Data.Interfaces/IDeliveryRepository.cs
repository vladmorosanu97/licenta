﻿using System.Collections.Generic;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Models;

namespace HealthyFood.Data.Interfaces
{
    public interface IDeliveryRepository
    {
        Result ValidateDeliveryTypeId(int deliveryTypeId);
        Result<long> CreateDelivery(Delivery delivery);
        Result<long> CreateLocationDeliveryPoint(LocationDeliveryPoint locationDeliveryPoint);
        Result CreateHomeDeliveryPoint(HomeDeliveryPoint homeDeliveryPoint);
        Result CreateLocationDeliveryPointsUsers(List<LocationDeliveryPointsUser> deliveryPointsUsers);
        Result<List<Delivery>> GetLocationDeliveries(long userId);
        Result<List<Delivery>> GetHomeDeliveries(long userId);

        Result<List<Delivery>> GetUserLocationDeliveries(long userId);
        Result<List<Delivery>> GetUserHomeDeliveries(long userId);
    }
}
