﻿using System.Collections.Generic;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Models;

namespace HealthyFood.Data.Interfaces
{
    public interface IUnitRepository
    {
        Result<List<UnitType>> GetUnitTypes();
        Result ValidateUnitTypeId(byte unitTypeId);
    }
}
