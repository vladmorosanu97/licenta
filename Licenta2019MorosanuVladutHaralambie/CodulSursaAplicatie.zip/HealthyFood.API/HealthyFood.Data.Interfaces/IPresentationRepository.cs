﻿using CSharpFunctionalExtensions;
using HealthyFood.Data.Models;

namespace HealthyFood.Data.Interfaces
{
    public interface IPresentationRepository
    {
        Result<UserPresentation> GetSellerPresentation(long userId, long authenticatedUserId);
        Result<UserPresentation> GetClientPresentation(long userId, long authenticatedUserId);
        Result UpdateSellerPresentation(SellerPresentation sellerPresentation);
        Result<SellerPresentation> GetSellerPresentationByUserId(long userId);
        Result CreateSellerPresentation(SellerPresentation sellerPresentation);
    }
}
