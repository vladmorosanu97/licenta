﻿using System.Collections.Generic;
using System.Security.Claims;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Implementation;
using HealthyFood.Data.Models;
using HealthyFood.Data.Models.DapperModels;
using HealthyFood.Data.Models.Models;

namespace HealthyFood.Data.Interfaces
{
    public interface IUserRepository : IBaseRepository
    {
        Result CreateUser(User user);
        Result UpdateUser(User user);
        Result UpdatePassword(long userId, string password);
        Result UpdateAvatar(User user);
        User GetUserById(long userId);
        Result CheckPassword(string email, string password);
        Result CheckPassword(long userId, string password);
        ICollection<UserClaim> GetUserClaims(User user);
        Result<Maybe<User>> FindByEmail(string email);
        Result AddClaim(User user, Claim claim);
        Result ValidateToken(string token);
        Result<User> GetUserByToken(string token);
        Result ConfirmAccount(User user);
        Result ValidateEmail(string email);
        Result ValidateUserId(long userId);
        IEnumerable<UserCard> GetFriendsCards(long userId, decimal? latitude, decimal? longitude, string searchText);
        IEnumerable<UserCard> GetUsersCards(long userId, decimal? latitude, decimal? longitude, string searchText);
        IEnumerable<UserCard> GetFriendsRequestsCards(long userId);
        IEnumerable<UserSearchSuggestion> GetFriendsSearchSuggestions(string text, long userId);
        Result<UserClaim> GetUserClaimByUserId(long userId);
        Result<UserLocations> GetSavedLocations(long userId);
        Result UpdateSavedLocations(long userId, UserLocations userLocations);
    }
}