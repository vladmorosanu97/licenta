import { MessageModule } from './modules/message/message.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { WelcomeModule } from './modules/welcome/welcome.module';
import { AppRoutingModule } from './app-routing.module';

import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { registerLocaleData } from '@angular/common';
import en from '@angular/common/locales/en';
import { SharedModule } from './shared/shared.module';

import { OAuthModule } from 'angular-oauth2-oidc'; // Added
import { AuthService } from './services/auth.service';
import { AuthenticationModule } from './modules/authentication/authentication.module';
import { HomeModule } from './modules/home/home.module';
import { IsAuthenticatedGuard } from './core/guards/is-authenticated.guard';
import { AdvertisementModule } from './modules/advertisement/advertisement.module';
import { SearchModule } from './modules/search/search.module';
import { UserModule } from './modules/user/user.module';
import { SettingsModule } from './modules/settings/settings.module';
import { RelationshipService } from './services/relationship.service';
import { DeliveryModule } from './modules/delivery/delivery.module';

registerLocaleData(en);

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    CoreModule,
    WelcomeModule,
    HomeModule,
    AdvertisementModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    SharedModule,
    OAuthModule.forRoot(),
    AuthenticationModule,
    SearchModule,
    MessageModule,
    UserModule,
    SettingsModule,
    DeliveryModule
  ],
  providers: [AuthService, IsAuthenticatedGuard, RelationshipService],
  bootstrap: [AppComponent]
})
export class AppModule {}
