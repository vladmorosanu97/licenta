import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { CommonMethods } from 'src/app/shared/common.methods';
import { debounceTime } from 'rxjs/operators';
import ChangePasswordModel from 'src/app/shared/models/change-password-model';
import { UserService } from 'src/app/services/user.service';
import { NzNotificationService } from 'ng-zorro-antd';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {
  formValidation = {
    currentPassword: 'normal',
    newPassword: 'normal',
    confirmPassword: 'normal'
  };
  changePasswordForm: FormGroup;
  isFetchingChangePassword = false;
  formError = '';
  constructor(
    private userService: UserService,
    private notification: NzNotificationService
  ) {}

  ngOnInit() {
    this.changePasswordForm = new FormGroup({
      currentPassword: new FormControl(''),
      newPassword: new FormControl(''),
      confirmPassword: new FormControl('')
    });
    this.initFormControls();
  }

  submitForm() {
    if (!this.validateFormOnSubmit()) {
      return false;
    }
    const changePassword = new ChangePasswordModel();
    changePassword.currentPassword = this.changePasswordForm.get(
      'currentPassword'
    ).value;
    changePassword.newPassword = this.changePasswordForm.get(
      'newPassword'
    ).value;
    this.isFetchingChangePassword = true;
    this.formError = '';

    this.userService.changePassword(changePassword).subscribe(
      () => {
        this.isFetchingChangePassword = false;
        this.notification.blank(
          'Password updated successfully',
          'The image has been updated successfully'
        );
        this.clearForm();
      },
      error => {
        this.formError = error.error;
        this.isFetchingChangePassword = false;
      }
    );
  }

  clearForm() {
    this.changePasswordForm.reset();
  }

  validateFormOnSubmit() {
    CommonMethods.markFormGroupTouched(this.changePasswordForm);

    if (!this.changePasswordForm.get('currentPassword').valid) {
      this.formValidation.currentPassword = 'error';
    }

    if (!this.changePasswordForm.get('newPassword').valid) {
      this.formValidation.newPassword = 'error';
    }

    if (!this.changePasswordForm.get('confirmPassword').valid) {
      this.formValidation.confirmPassword = 'error';
    }
    if (!this.changePasswordForm.valid) {
      return false;
    }
    return true;
  }

  initFormControls() {
    const currentPasswordField = this.changePasswordForm.get('currentPassword');
    currentPasswordField.valueChanges
      .pipe(debounceTime(1000))
      .subscribe(value => {
        if (value && value.length < 8 && value.length > 0) {
          currentPasswordField.setErrors({ minLength: true });
          this.formValidation.currentPassword = 'error';
        } else if (value && value.length === 0) {
          currentPasswordField.setErrors({ required: true });
          this.formValidation.currentPassword = 'error';
        } else {
          currentPasswordField.setErrors(null);
          this.formValidation.currentPassword = 'normal';
        }
      });
    currentPasswordField.valueChanges.pipe().subscribe(value => {
      this.formValidation.currentPassword = 'normal';
    });

    const newPasswordField = this.changePasswordForm.get('newPassword');
    newPasswordField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value && value.length < 8 && value.length > 0) {
        newPasswordField.setErrors({ minLength: true });
        this.formValidation.newPassword = 'error';
      } else if (value && value.length === 0) {
        newPasswordField.setErrors({ required: true });
        this.formValidation.newPassword = 'error';
      } else {
        newPasswordField.setErrors(null);
        this.formValidation.newPassword = 'normal';
      }
    });
    newPasswordField.valueChanges.pipe().subscribe(value => {
      this.formValidation.newPassword = 'normal';
    });

    const confirmPasswordField = this.changePasswordForm.get('confirmPassword');
    confirmPasswordField.valueChanges
      .pipe(debounceTime(1000))
      .subscribe(value => {
        if (value && value.length < 8 && value.length > 0) {
          confirmPasswordField.setErrors({ minLength: true });
          this.formValidation.confirmPassword = 'error';
        } else if (value && value.length === 0) {
          confirmPasswordField.setErrors({ required: true });
          this.formValidation.confirmPassword = 'error';
        } else if (
          value &&
          newPasswordField.value.length > 0 &&
          newPasswordField.value !== value
        ) {
          confirmPasswordField.setErrors({ invalidPassword: true });
          this.formValidation.confirmPassword = 'error';
        } else {
          confirmPasswordField.setErrors(null);
          this.formValidation.confirmPassword = 'normal';
        }
      });
    confirmPasswordField.valueChanges.pipe().subscribe(value => {
      this.formValidation.confirmPassword = 'normal';
    });
  }
}
