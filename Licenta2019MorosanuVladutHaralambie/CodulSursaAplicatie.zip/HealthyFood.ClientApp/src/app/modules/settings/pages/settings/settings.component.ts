import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import SettingsItems from 'src/app/shared/constants/settings-items-constants';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {
  componentIndex: number;
  selectedItemMenu: string;
  settingsItems = SettingsItems;
  constructor(private router: Router, private route: ActivatedRoute) {
    router.events.subscribe(event => {
      // see also
      if (event instanceof NavigationEnd) {
        // if (event.url.split('/')[3] === 'reviews') {
        //   this.componentIndex = 1;
        // } else if (event.url.split('/')[3] === 'overview') {
        //   this.componentIndex = 0;
        // } else {
        //   this.router.navigate(['profile'], { relativeTo: this.route });
        // }
        this.selectedItemMenu = event.url;
      }
    });
  }

  ngOnInit() {}
}
