import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserRoutingModule } from './user-routing.module';
import { UserCardComponent } from './components/user-card/user-card.component';
import { UsersComponent } from './pages/users/users.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { UserComponent } from './pages/user/user.component';
import { SellerPresentationComponent } from './components/seller-presentation/seller-presentation.component';
import { ClientPresentationComponent } from './components/client-presentation/client-presentation.component';
import { EditPresentationComponent } from './pages/edit-presentation/edit-presentation.component';
import { StatisticsCardComponent } from './components/statistics-card/statistics-card.component';
import { RatingCardComponent } from './components/rating-card/rating-card.component';
import { ReviewCardComponent } from './components/review-card/review-card.component';
import { AddReviewComponent } from './components/add-review/add-review.component';
import { DiscoverPeopleComponent } from './pages/discover-people/discover-people.component';
import { PeopleRequestComponent } from './pages/people-request/people-request.component';

@NgModule({
  declarations: [
    UserCardComponent,
    UsersComponent,
    UserComponent,
    SellerPresentationComponent,
    ClientPresentationComponent,
    EditPresentationComponent,
    StatisticsCardComponent,
    RatingCardComponent,
    ReviewCardComponent,
    AddReviewComponent,
    DiscoverPeopleComponent,
    PeopleRequestComponent
  ],
  imports: [SharedModule, CommonModule, UserRoutingModule]
})
export class UserModule {}
