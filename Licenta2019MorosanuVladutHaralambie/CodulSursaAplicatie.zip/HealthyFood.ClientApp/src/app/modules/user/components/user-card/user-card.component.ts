import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import UserModel from 'src/app/shared/models/user-model';
import UserCardModel from 'src/app/shared/models/user-card-model';
import { UserRoles } from 'src/app/shared/constants/user-roles-constants';
import RelationshipStatusConstants from 'src/app/shared/constants/relationship-status-constants';
import { AuthService } from 'src/app/services/auth.service';
import RelationshipActionsConstants from 'src/app/shared/constants/relationship-actions-constants';

@Component({
  selector: 'app-user-card',
  templateUrl: './user-card.component.html',
  styleUrls: ['./user-card.component.scss']
})
export class UserCardComponent implements OnInit {
  @Input() user: UserCardModel = null;
  @Input() userId: number = null;
  userRoles = UserRoles;
  relationshipStatus = RelationshipStatusConstants;
  @Output() relationshipAction = new EventEmitter<string>();
  constructor(private authService: AuthService) {}

  ngOnInit() {}

  cancelFriendRequest() {
    this.relationshipAction.emit(
      RelationshipActionsConstants.cancelFriendRequest
    );
  }

  acceptFriendRequest() {
    this.relationshipAction.emit(
      RelationshipActionsConstants.acceptFriendRequest
    );
  }

  removeFriendRequest() {
    this.relationshipAction.emit(
      RelationshipActionsConstants.removeFriendRequest
    );
  }

  sendFriendRequest() {
    this.relationshipAction.emit(
      RelationshipActionsConstants.sendFriendRequest
    );
  }

  removeFriend() {
    this.relationshipAction.emit(RelationshipActionsConstants.removeFriend);
  }
}
