import { AuthService } from 'src/app/services/auth.service';
import { Component, OnInit, Input } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import UserModel from 'src/app/shared/models/user-model';
import { FormGroup, FormControl } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';
import { CommonMethods } from 'src/app/shared/common.methods';
import CreateReviewModel from 'src/app/shared/models/create-review';
import { ReviewService } from 'src/app/services/review.service';
import { NzNotificationService } from 'ng-zorro-antd';

@Component({
  selector: 'app-add-review',
  templateUrl: './add-review.component.html',
  styleUrls: ['./add-review.component.scss']
})
export class AddReviewComponent implements OnInit {
  @Input() currentUser: UserModel;
  @Input() recipientId: number = null;
  addReviewForm: FormGroup;
  formValidation = {
    mark: 'normal',
    content: 'normal'
  };
  constructor(
    private reviewService: ReviewService,
    private notification: NzNotificationService
  ) {}

  ngOnInit() {
    this.addReviewForm = new FormGroup({
      mark: new FormControl(null),
      content: new FormControl('')
    });
    this.initFormControls();
  }

  initFormControls() {
    const contentField = this.addReviewForm.get('content');
    contentField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0) {
        contentField.setErrors({ required: true });
        this.formValidation.content = 'error';
      } else {
        contentField.setErrors(null);
        this.formValidation.content = 'normal';
      }
    });
    contentField.valueChanges.pipe().subscribe(value => {
      this.formValidation.content = 'normal';
    });
  }

  validateFormOnSubmit() {
    CommonMethods.markFormGroupTouched(this.addReviewForm);
    if (!this.addReviewForm.get('mark').valid) {
      this.formValidation.mark = 'error';
    }
    if (!this.addReviewForm.get('content').valid) {
      this.formValidation.content = 'error';
    }

    if (!this.addReviewForm.valid) {
      return false;
    }
    return true;
  }

  onSubmit() {
    if (!this.validateFormOnSubmit()) {
      return false;
    }
    if (this.recipientId === null) {
      return false;
    }
    console.log('merge');
    const review = new CreateReviewModel();
    review.mark = this.addReviewForm.get('mark').value;
    review.content = this.addReviewForm.get('content').value;
    review.recipientId = this.recipientId;
    this.reviewService.addReview(review).subscribe(
      () => {
        this.notification.blank(
          'New review added successfully',
          'This is the content of the notification. This is the content of the notification. This is the content of the notification.'
        );
        this.clearForm();
      },
      error => {
        console.log(error);
        this.clearForm();
      }
    );
  }

  clearForm() {
    this.addReviewForm.get('mark').setValue(null);
    this.addReviewForm.get('content').setValue('');
  }
}
