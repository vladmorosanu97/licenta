import { Component, OnInit, Input } from '@angular/core';
import UserPresentationModel from 'src/app/shared/models/user-presentation-model';
import { UserRoles } from 'src/app/shared/constants/user-roles-constants';

@Component({
  selector: 'app-statistics-card',
  templateUrl: './statistics-card.component.html',
  styleUrls: ['./statistics-card.component.scss']
})
export class StatisticsCardComponent implements OnInit {
  @Input() userPresentation: UserPresentationModel;
  @Input() userRole: string;
  userRoles = UserRoles;
  constructor() {}

  ngOnInit() {}
}
