import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerPresentationComponent } from './seller-presentation.component';

describe('SellerPresentationComponent', () => {
  let component: SellerPresentationComponent;
  let fixture: ComponentFixture<SellerPresentationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellerPresentationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerPresentationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
