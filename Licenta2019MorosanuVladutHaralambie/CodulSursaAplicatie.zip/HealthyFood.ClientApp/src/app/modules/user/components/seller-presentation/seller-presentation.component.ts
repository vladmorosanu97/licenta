import { Component, OnInit, Input, Output } from '@angular/core';
import UserPresentationModel from 'src/app/shared/models/user-presentation-model';
import ReviewModel from 'src/app/shared/models/review-model';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { UserRoles } from 'src/app/shared/constants/user-roles-constants';
import UserModel from 'src/app/shared/models/user-model';
import RelationshipStatusConstants from 'src/app/shared/constants/relationship-status-constants';
import { EventEmitter } from '@angular/core';
import RelationshipActionsConstants from 'src/app/shared/constants/relationship-actions-constants';

@Component({
  selector: 'app-seller-presentation',
  templateUrl: './seller-presentation.component.html',
  styleUrls: ['./seller-presentation.component.scss']
})
export class SellerPresentationComponent implements OnInit {
  @Input() userPresentation: UserPresentationModel;
  @Input() bannerUrl: any;
  @Input() reviews: Array<ReviewModel>;
  @Input() currentUser: UserModel;
  componentIndex: number;
  userRoles = UserRoles;
  relationshipConstants = RelationshipStatusConstants;
  @Output() relationshipAction = new EventEmitter<string>();
  constructor(private router: Router, private route: ActivatedRoute) {
    router.events.subscribe(val => {
      // see also
      if (val instanceof NavigationEnd) {
        if (val.url.split('/')[3] === 'reviews') {
          this.componentIndex = 1;
        } else if (val.url.split('/')[3] === 'overview') {
          this.componentIndex = 0;
        } else {
          this.router.navigate(['overview'], { relativeTo: this.route });
        }
      }
    });
  }

  ngOnInit() {
    if (this.route.children.length === 0) {
      this.router.navigate(['overview'], { relativeTo: this.route });
    } else if (this.route.children.length > 0) {
      if (this.router.url.split('/')[3] === 'overview') {
        this.componentIndex = 0;
      } else if (this.router.url.split('/')[3] === 'reviews') {
        this.componentIndex = 1;
      }
    }
  }

  changeComponentIndex(value) {
    if (value === 0) {
      this.router.navigate(['overview'], { relativeTo: this.route });
    } else {
      this.router.navigate(['reviews'], { relativeTo: this.route });
    }
  }

  cancelFriendRequest() {
    this.relationshipAction.emit(
      RelationshipActionsConstants.cancelFriendRequest
    );
  }

  acceptFriendRequest() {
    this.relationshipAction.emit(
      RelationshipActionsConstants.acceptFriendRequest
    );
  }

  removeFriendRequest() {
    this.relationshipAction.emit(
      RelationshipActionsConstants.removeFriendRequest
    );
  }

  sendFriendRequest() {
    this.relationshipAction.emit(
      RelationshipActionsConstants.sendFriendRequest
    );
  }

  removeFriend() {
    this.relationshipAction.emit(RelationshipActionsConstants.removeFriend);
  }
}
