import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { UsersComponent } from './pages/users/users.component';
import { IsAuthenticatedGuard } from 'src/app/core/guards/is-authenticated.guard';
import { UserComponent } from './pages/user/user.component';
import { EditPresentationComponent } from './pages/edit-presentation/edit-presentation.component';
import { DiscoverPeopleComponent } from './pages/discover-people/discover-people.component';
import { PeopleRequestComponent } from './pages/people-request/people-request.component';

const routes: Routes = [
  {
    path: 'people',
    component: UsersComponent,
    canActivate: [IsAuthenticatedGuard]
  },
  {
    path: 'people/discover',
    component: DiscoverPeopleComponent,
    canActivate: [IsAuthenticatedGuard]
  },
  {
    path: 'people-requests',
    component: PeopleRequestComponent,
    canActivate: [IsAuthenticatedGuard]
  },
  {
    path: 'people/:userId',
    component: UserComponent,
    canActivate: [IsAuthenticatedGuard],
    children: [
      { path: 'overview', component: UserComponent },
      { path: 'reviews', component: UserComponent }
    ]
  },

  {
    path: 'my-presentation',
    component: EditPresentationComponent,
    canActivate: [IsAuthenticatedGuard]
  }
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(routes)]
})
export class UserRoutingModule {}
