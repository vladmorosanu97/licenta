import { PresentationService } from './../../../../services/presentation.service';
import { Component, OnInit } from '@angular/core';
import UserPresentationModel from 'src/app/shared/models/user-presentation-model';
import { UserService } from 'src/app/services/user.service';
import { AuthService } from 'src/app/services/auth.service';
import { Observable, Observer } from 'rxjs';
import ImageModel from 'src/app/shared/models/image-model';
import { NzMessageService, NzNotificationService } from 'ng-zorro-antd';
import { CommonMethods } from 'src/app/shared/common.methods';
import ImagesPathConstants from 'src/app/shared/constants/images-path-constants';
import { DomSanitizer } from '@angular/platform-browser';
import { UserRoles } from 'src/app/shared/constants/user-roles-constants';

@Component({
  selector: 'app-edit-presentation',
  templateUrl: './edit-presentation.component.html',
  styleUrls: ['./edit-presentation.component.scss']
})
export class EditPresentationComponent implements OnInit {
  userPresentation: UserPresentationModel;
  file: ImageModel;
  bannerUrl: any;
  isFetchingPresentation = false;
  isFetchingUpdateImage = false;
  isFetchingUpdateDescription = false;
  isEditing = false;

  description = '';
  userRoles = UserRoles;
  constructor(
    private userService: UserService,
    private authService: AuthService,
    private msg: NzMessageService,
    private sanitizer: DomSanitizer,
    private notification: NzNotificationService,
    private presentationService: PresentationService
  ) {}

  ngOnInit() {
    const userId = this.authService.getUserId();
    this.isFetchingPresentation = true;
    this.presentationService.getPresentationById(userId).subscribe(
      data => {
        this.userPresentation = data;
        this.bannerUrl = this.sanitizer.bypassSecurityTrustStyle(
          `url(${
            this.userPresentation.bannerPath
              ? this.userPresentation.bannerPath
              : ImagesPathConstants.userPresentation
          })`
        );
        this.description = this.userPresentation.description
          ? this.userPresentation.description
          : '';
        this.description = this.description.replace(/\n/g, '<br />');
        this.isFetchingPresentation = false;
      },
      error => {
        console.error(error);
        this.isFetchingPresentation = false;
      }
    );
  }

  beforeUpload = (event: any) => {
    new Observable((observer: Observer<boolean>) => {
      let files: Array<File>;
      if (event.target.files && event.target.files.length > 0) {
        files = event.target.files;
        Array.prototype.forEach.call(files, (file: File, index) => {
          const isJPGorPNG =
            file.type === 'image/jpeg' || file.type === 'image/png';
          if (!isJPGorPNG) {
            this.msg.error('You can only upload JPG or file!');
            observer.complete();
            return;
          }

          const isLt5M = file.size / 1024 / 1024 < 10;
          if (!isLt5M) {
            this.msg.error('Image must be smaller than  10MB!');
            observer.complete();
            return;
          }

          CommonMethods.getBase64(file, base64 => {
            this.file = {
              imageId: index,
              name: file.name,
              base64,
              imagePath: null,
              guidPathName: null
            };
            this.changeBannerUrl();
          });

          observer.next(isJPGorPNG && isLt5M);
          observer.complete();
        });
      }
    }).subscribe(() => {});
  };

  changeBannerUrl() {
    this.bannerUrl = this.sanitizer.bypassSecurityTrustStyle(
      `url(${this.file.base64})`
    );
  }

  savePhoto() {
    this.isFetchingUpdateImage = true;

    this.presentationService.updatePresentationPhoto(this.file).subscribe(
      data => {
        console.log('Success');
        this.notification.blank(
          'Presentation updated successfully',
          'The image has been updated successfully'
        );
        this.isFetchingUpdateImage = false;
        this.file = null;
      },
      error => {
        this.isFetchingUpdateImage = false;
        this.file = null;
      }
    );
  }

  editDescription() {
    this.isEditing = true;
  }

  saveDescription() {
    if (
      this.description.length === 0 ||
      this.userPresentation.description === this.description
    ) {
      this.isEditing = false;
      return false;
    }
    this.isFetchingUpdateDescription = false;
    this.presentationService
      .updatePresentationDescription(this.description)
      .subscribe(
        data => {
          console.log('Success');
          this.notification.blank(
            'Presentation description updated successfully',
            'The description has been updated successfully'
          );
          this.isFetchingUpdateDescription = false;
          this.userPresentation.description = this.description.replace(
            /\n/g,
            '<br />'
          );
          this.isEditing = false;
        },
        error => {
          this.isFetchingUpdateDescription = false;
          this.isEditing = false;
        }
      );
  }

  cancelEdit() {
    this.isEditing = false;
  }
}
