import UserModel from 'src/app/shared/models/user-model';
import { PresentationService } from './../../../../services/presentation.service';
import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import UserPresentationModel from 'src/app/shared/models/user-presentation-model';
import { ActivatedRoute } from '@angular/router';
import ImagesPathConstants from 'src/app/shared/constants/images-path-constants';
import { DomSanitizer } from '@angular/platform-browser';
import { UserRoles } from 'src/app/shared/constants/user-roles-constants';
import { ReviewService } from 'src/app/services/review.service';
import ReviewModel from 'src/app/shared/models/review-model';
import { AuthService } from 'src/app/services/auth.service';
import RelationshipActionsConstants from 'src/app/shared/constants/relationship-actions-constants';
import { RelationshipService } from 'src/app/services/relationship.service';
import RelationshipModel from 'src/app/shared/models/relationship-model';
import RelationshipStatusConstants from 'src/app/shared/constants/relationship-status-constants';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {
  userPresentation: UserPresentationModel;
  isFetchingUserPresentation = false;
  bannerUrl: any;
  userRoles = UserRoles;
  reviews: Array<ReviewModel>;
  currentUser: UserModel;
  userId: number;
  currentUserId: number;
  constructor(
    private userService: UserService,
    private route: ActivatedRoute,
    private sanitizer: DomSanitizer,
    private reviewService: ReviewService,
    private presentationService: PresentationService,
    private authService: AuthService,
    private relationshipService: RelationshipService
  ) {}

  ngOnInit() {
    this.route.params.subscribe(routeParams => {
      this.loadCurrentUserProfile();

      const userId = routeParams.userId;
      if (isNaN(parseInt(userId, 10))) {
        console.error('Invalid user id');
        return false;
      }
      this.userId = Number.parseInt(userId, 10);
      this.getUserPresentation(this.userId);
    });
  }

  getUserPresentation(userId) {
    this.isFetchingUserPresentation = true;
    this.presentationService.getPresentationById(userId).subscribe(
      data => {
        console.log(data);
        this.userPresentation = data;
        this.userPresentation.description = this.userPresentation.description
          ? this.userPresentation.description.replace(/\n/g, '<br />')
          : null;
        this.isFetchingUserPresentation = false;
        this.bannerUrl = this.sanitizer.bypassSecurityTrustStyle(
          `url(${
            this.userPresentation.bannerPath
              ? this.userPresentation.bannerPath
              : ImagesPathConstants.userPresentation
          })`
        );

        this.reviewService
          .getReviews(this.userPresentation.userId)
          .subscribe(reviews => {
            this.reviews = reviews;
          });
      },
      error => {
        console.log(error.error);
        this.isFetchingUserPresentation = false;
      }
    );
  }

  loadCurrentUserProfile() {
    this.currentUser = new UserModel();
    this.currentUser = this.authService.getUserProfile();
  }

  onRelationshipChange(value) {
    if (value === RelationshipActionsConstants.cancelFriendRequest) {
      this.cancelFriendRequest(this.userPresentation.userId);
    } else if (value === RelationshipActionsConstants.sendFriendRequest) {
      this.sendFriendRequest(this.userPresentation.userId);
    } else if (value === RelationshipActionsConstants.acceptFriendRequest) {
      this.acceptFriendRequest(this.userPresentation.userId);
    } else if (value === RelationshipActionsConstants.removeFriend) {
      this.removeFriend(this.userPresentation.userId);
    } else if (value === RelationshipActionsConstants.removeFriendRequest) {
      this.removeFriendRequest(this.userPresentation.userId);
    }
  }

  sendFriendRequest(receiverId) {
    this.relationshipService.sendFriendRequest(receiverId).subscribe(
      () => {
        console.log('success');
        this.userPresentation.relationship = new RelationshipModel();
        this.userPresentation.relationship.relatedUserId = this.userId;
        this.userPresentation.relationship.relatingUserId = this.currentUser.userId;
        this.userPresentation.relationship.type =
          RelationshipStatusConstants.request;
      },
      error => {
        console.log(error);
      }
    );
  }

  cancelFriendRequest(receiverId) {
    this.relationshipService.cancelFriendRequest(receiverId).subscribe(
      () => {
        console.log('success');
        this.userPresentation.relationship = null;
      },
      error => {
        console.log(error);
      }
    );
  }

  acceptFriendRequest(senderId) {
    this.relationshipService.acceptFriendRequest(senderId).subscribe(
      () => {
        console.log('success');
        this.userPresentation.relationship = new RelationshipModel();
        this.userPresentation.relationship.relatedUserId = this.userId;
        this.userPresentation.relationship.relatingUserId = this.currentUser.userId;
        this.userPresentation.relationship.type =
          RelationshipStatusConstants.friend;
      },
      error => {
        console.log(error);
      }
    );
  }

  removeFriend(receiverId) {
    this.relationshipService.removeFriend(receiverId).subscribe(
      () => {
        console.log('success');
        this.userPresentation.relationship = null;
      },
      error => {
        console.log(error);
      }
    );
  }

  removeFriendRequest(senderId) {
    this.relationshipService.removeFriendRequest(senderId).subscribe(
      () => {
        console.log('success');
        this.userPresentation.relationship = null;
      },
      error => {
        console.log(error);
      }
    );
  }
}
