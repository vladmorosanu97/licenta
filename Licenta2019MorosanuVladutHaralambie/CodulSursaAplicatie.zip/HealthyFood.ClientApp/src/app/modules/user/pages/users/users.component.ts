import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import UserCardModel from 'src/app/shared/models/user-card-model';
import { MapService } from 'src/app/services/map.service';
import { HeaderService } from 'src/app/services/header.service';
import SearchUsersModel from 'src/app/shared/models/search-users-model';
import { FormGroup, FormControl } from '@angular/forms';
import UserModel from 'src/app/shared/models/user-model';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  friendsCards: Array<UserCardModel>;
  latitude: number = null;
  longitude: number = null;
  latitudeUserMarker: number;
  longitudeUserMarker: number;
  geoLocationError = false;
  toggleMap = true;
  toggleMapForm: FormGroup;
  userProfile: UserModel;
  constructor(
    private userService: UserService,
    private mapService: MapService,
    private headerService: HeaderService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.userProfile = this.authService.getClaims();
    console.log(this.userProfile);
    this.toggleMapForm = new FormGroup({
      toggleMap: new FormControl()
    });
    this.getCurrentPosition();
    this.headerService.getSearchUsersObserver().subscribe(item => {
      console.log(item);
      this.getFriends(item);
    });

    const val = localStorage.getItem('friendsToggleMap');
    if (val === undefined) {
      this.toggleMapForm.get('toggleMap').setValue(false);
    } else {
      this.toggleMapForm.get('toggleMap').setValue(val === 'true');
    }

    this.toggleMapForm.get('toggleMap').valueChanges.subscribe(data => {
      localStorage.setItem('toggleMap', data);
    });
  }

  getCurrentPosition() {
    const coordinatesCallback = value => {
      if (value.success) {
        this.geoLocationError = false;

        this.latitude = value.latitude;
        this.longitude = value.longitude;
        this.latitudeUserMarker = value.latitude;
        this.longitudeUserMarker = value.longitude;
      } else {
        this.geoLocationError = true;
      }
      this.getFriends(null);
    };
    this.mapService.setCurrentPosition(coordinatesCallback);
  }

  getFriends(searchText: string) {
    const searchUser = new SearchUsersModel();
    searchUser.latitude = this.latitude;
    searchUser.longitude = this.longitude;
    searchUser.searchText = searchText;
    this.userService.getFriends(searchUser).subscribe(data => {
      this.friendsCards = data;
      console.log(data);
    });
  }
}
