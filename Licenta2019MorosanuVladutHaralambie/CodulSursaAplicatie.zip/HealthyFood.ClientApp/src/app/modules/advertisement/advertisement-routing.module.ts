import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AddAdvertisementComponent } from './pages/add-advertisement/add-advertisement.component';
import { IsAuthenticatedGuard } from 'src/app/core/guards/is-authenticated.guard';
import { AdvertisementComponent } from './pages/advertisement/advertisement.component';
import { MyAdvertisementsComponent } from './pages/my-advertisements/my-advertisements.component';
import { TrendingComponent } from './pages/trending/trending.component';

const routes: Routes = [
  {
    path: 'add-advertisement',
    component: AddAdvertisementComponent,
    canActivate: [IsAuthenticatedGuard]
  },
  {
    path: 'advertisement/:advertisementId',
    component: AdvertisementComponent,
    canActivate: [IsAuthenticatedGuard]
  },
  {
    path: 'my-advertisements',
    component: MyAdvertisementsComponent,
    canActivate: [IsAuthenticatedGuard]
  },
  {
    path: 'edit-advertisement/:advertisementId',
    component: AddAdvertisementComponent,
    canActivate: [IsAuthenticatedGuard]
  },
  {
    path: 'trending',
    component: TrendingComponent,
    canActivate: [IsAuthenticatedGuard]
  }
];
@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(routes)]
})
export class AdvertisementRoutingModule {}
