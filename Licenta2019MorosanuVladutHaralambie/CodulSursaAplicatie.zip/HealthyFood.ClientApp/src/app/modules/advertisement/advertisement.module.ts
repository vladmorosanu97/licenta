import { AdvertisementCardComponent } from './components/advertisement-card/advertisement-card.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddAdvertisementComponent } from './pages/add-advertisement/add-advertisement.component';
import { AdvertisementRoutingModule } from './advertisement-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { AdvertisementMarkerComponent } from './components/advertisement-marker/advertisement-marker.component';
import { AdvertisementComponent } from './pages/advertisement/advertisement.component';
import { MyAdvertisementsComponent } from './pages/my-advertisements/my-advertisements.component';
import { TrendingComponent } from './pages/trending/trending.component';

@NgModule({
  declarations: [
    AddAdvertisementComponent,
    AdvertisementCardComponent,
    AdvertisementMarkerComponent,
    AdvertisementComponent,
    MyAdvertisementsComponent,
    TrendingComponent
  ],
  imports: [CommonModule, SharedModule, AdvertisementRoutingModule],
  exports: [AdvertisementCardComponent, AdvertisementMarkerComponent]
})
export class AdvertisementModule {}
