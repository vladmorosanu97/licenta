import {
  Component,
  OnInit,
  Input,
  HostListener,
  Output,
  EventEmitter
} from '@angular/core';
import AdvertisementCardModel from 'src/app/shared/models/advertisement-card-model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-advertisement-card',
  templateUrl: './advertisement-card.component.html',
  styleUrls: ['./advertisement-card.component.scss']
})
export class AdvertisementCardComponent implements OnInit {
  @Input() advertisementCard: AdvertisementCardModel;
  @Input() userAdvertisement = false;
  @Output() clickDelete = new EventEmitter();
  isFocusInsideComponent = false;
  isComponentClicked = false;

  constructor(private router: Router) {}

  ngOnInit() {}

  redirectToAdvertisement() {
    this.router.navigate([
      'advertisement',
      this.advertisementCard.advertisementId
    ]);
  }

  confirm(advertisementId): void {
    this.clickDelete.emit(advertisementId);
  }

  clickInside() {
    this.isFocusInsideComponent = true;
    this.isComponentClicked = true;
  }

  @HostListener('document:click')
  clickOut() {
    if (!this.isFocusInsideComponent && this.isComponentClicked) {
      // do the heavy process

      this.isComponentClicked = false;
    }
    this.isFocusInsideComponent = false;
  }
}
