import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvertisementMarkerComponent } from './advertisement-marker.component';

describe('AdvertisementMarkerComponent', () => {
  let component: AdvertisementMarkerComponent;
  let fixture: ComponentFixture<AdvertisementMarkerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdvertisementMarkerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvertisementMarkerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
