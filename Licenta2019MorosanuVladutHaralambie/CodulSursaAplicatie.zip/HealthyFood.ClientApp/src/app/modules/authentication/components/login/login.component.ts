import { CommonMethods } from './../../../../shared/common.methods';
import { AuthService } from '../../../../services/auth.service';
import { debounceTime } from 'rxjs/operators';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import LoginUserModel from 'src/app/shared/models/login-user-model';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { HeaderService } from 'src/app/services/header.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;

  formValidation = {
    email: 'normal',
    password: 'normal'
  };
  isFetchingLogin: boolean;
  formError = '';
  constructor(
    private authService: AuthService,
    private router: Router,
    headerService: HeaderService
  ) {}

  ngOnInit() {
    this.loginForm = new FormGroup({
      email: new FormControl(''),
      password: new FormControl(''),
      remember: new FormControl(false)
    });

    this.initFormControls();
  }

  submitForm() {
    if (!this.validateFormOnSubmit()) {
      return false;
    }

    const loginModel = new LoginUserModel();

    loginModel.email = this.loginForm.get('email').value;
    loginModel.password = this.loginForm.get('password').value;
    loginModel.remember = this.loginForm.get('remember').value;
    this.isFetchingLogin = true;
    this.formError = '';
    this.authService.loginUserAndLoadUserProfile(loginModel).then(
      data => {
        this.router.navigate(['search']);
        this.clearForm();
        this.isFetchingLogin = false;
        console.log(data);

        this.authService.isLoggedIn();
      },
      error => {
        this.formError = error.error;
        this.isFetchingLogin = false;
      }
    );
  }

  initFormControls() {
    const emailField = this.loginForm.get('email');
    emailField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0) {
        emailField.setErrors({ required: true });
        this.formValidation.email = 'error';
      } else if (value.match(/\S+@\S+\.\S+/) === null) {
        emailField.setErrors({ invalidEmail: true });
        this.formValidation.email = 'error';
      } else {
        this.formValidation.email = 'normal';
      }
    });
    emailField.valueChanges.pipe().subscribe(value => {
      this.formValidation.email = 'normal';
    });

    const passwordField = this.loginForm.get('password');
    passwordField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length < 8 && value.length > 0) {
        passwordField.setErrors({ minLength: true });
        this.formValidation.password = 'error';
      } else if (value.length === 0) {
        passwordField.setErrors({ required: true });
        this.formValidation.password = 'error';
      } else {
        passwordField.setErrors(null);
        this.formValidation.password = 'normal';
      }
    });
    passwordField.valueChanges.pipe().subscribe(value => {
      this.formValidation.password = 'normal';
    });
  }

  validateFormOnSubmit() {
    CommonMethods.markFormGroupTouchedAndDirty(this.loginForm);
    if (this.loginForm.get('password').value.length === 0) {
      this.formValidation.password = 'error';
      this.loginForm.controls.password.setErrors({ required: true });
    }
    if (this.loginForm.get('email').value.length === 0) {
      this.formValidation.email = 'error';
      this.loginForm.controls.email.setErrors({ required: true });
    }

    if (!this.loginForm.valid) {
      return false;
    }
    return true;
  }

  clearForm() {
    this.loginForm.controls.email.setValue('');
    this.loginForm.controls.password.setValue('');
  }
}
