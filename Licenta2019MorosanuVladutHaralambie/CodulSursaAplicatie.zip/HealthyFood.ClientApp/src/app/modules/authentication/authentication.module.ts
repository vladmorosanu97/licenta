import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthenticationRoutingModule } from './authentication-routing.module';
import { AgmCoreModule } from '@agm/core';
import { AuthenticationComponent } from './pages/authentication/authentication.component';
import { LoginComponent } from './components/login/login.component';
import { AuthComponent } from './components/auth/auth.component';
import { RegisterComponent } from './components/register/register.component';
import { ConfirmAccountComponent } from './pages/confirm-account/confirm-account.component';
import { RegisterDoneComponent } from './pages/register-done/register-done.component';
import { NzButtonModule } from 'ng-zorro-antd';
import { SharedModule } from 'src/app/shared/shared.module';
import { mapsConfig } from 'src/environments/maps.config';

@NgModule({
  declarations: [
    LoginComponent,
    AuthComponent,
    RegisterComponent,
    ConfirmAccountComponent,
    RegisterDoneComponent,
    AuthenticationComponent
  ],
  imports: [
    CommonModule,
    NzButtonModule,
    SharedModule,
    AuthenticationRoutingModule,
    SharedModule
  ],
  exports: [AuthenticationComponent]
})
export class AuthenticationModule {}
