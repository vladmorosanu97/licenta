import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfirmAccountComponent } from './pages/confirm-account/confirm-account.component';
import { AuthenticationComponent } from './pages/authentication/authentication.component';
import { RegisterDoneComponent } from './pages/register-done/register-done.component';

const routes: Routes = [
  { path: 'authentication/confirm-account', component: ConfirmAccountComponent },
  {
    path: 'authentication/registration-done',
    component: RegisterDoneComponent
  },
  {
    path: 'authentication/:action',
    component: AuthenticationComponent
  },
  {
    path: 'authentication',
    redirectTo: 'authentication/login',
    pathMatch: 'full'
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthenticationRoutingModule {}
