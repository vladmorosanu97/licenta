import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddDeliveryComponent } from './pages/add-delivery/add-delivery.component';
import { DeliveryRoutingModule } from './delivery-routing.module';
import { DeliveriesComponent } from './pages/deliveries/deliveries.component';
import { MyDeliveriesComponent } from './pages/my-deliveries/my-deliveries.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { UserAvatarComponent } from './components/user-avatar/user-avatar.component';
import { CoreModule } from 'src/app/core/core.module';
import { DeliveryMapComponent } from './components/delivery-map/delivery-map.component';
import { DeliveryCardComponent } from './components/delivery-card/delivery-card.component';
import { DeliveryDescriptionComponent } from './components/delivery-description/delivery-description.component';
import { MyDeliveryMapComponent } from './components/my-delivery-map/my-delivery-map.component';
import { MyDeliveryDescriptionComponent } from './components/my-delivery-description/my-delivery-description.component';
import { HomeDeliveryPointComponent } from './components/home-delivery-point/home-delivery-point.component';
import { LocationDeliveryPointComponent } from './components/location-delivery-point/location-delivery-point.component';

@NgModule({
  declarations: [
    AddDeliveryComponent,
    DeliveriesComponent,
    MyDeliveriesComponent,
    UserAvatarComponent,
    DeliveryMapComponent,
    DeliveryCardComponent,
    DeliveryDescriptionComponent,
    MyDeliveryMapComponent,
    MyDeliveryDescriptionComponent,
    HomeDeliveryPointComponent,
    LocationDeliveryPointComponent
  ],
  imports: [CoreModule, SharedModule, CommonModule, DeliveryRoutingModule],
  exports: [UserAvatarComponent]
})
export class DeliveryModule {}
