import {
  Component,
  OnInit,
  NgZone,
  ElementRef,
  ViewChild
} from '@angular/core';
import { MapService } from 'src/app/services/map.service';
import { FormGroup, FormControl } from '@angular/forms';
import DeliveryTypeModel from 'src/app/shared/models/delivery-type-model';
import DeliveryTypesConstants from 'src/app/shared/constants/delivery-types-constants';
import CreateLocationDeliveryPointModel from 'src/app/shared/models/create-location-delivery-point-model';
import UserModel from 'src/app/shared/models/user-model';
import { UserService } from 'src/app/services/user.service';
import UserSearchSuggestionModel from 'src/app/shared/models/user-search-suggestion-model';
import { debug } from 'util';
import { CommonMethods } from 'src/app/shared/common.methods';
import CreateLocationDeliveryModel from 'src/app/shared/models/create-location-delivery-model';
import { DeliveryService } from 'src/app/services/delivery.service';
import { Router } from '@angular/router';
import CreateHomeDeliveryModel from 'src/app/shared/models/create-home-delivery-model';
import CreateHomeDeliveryPointModel from 'src/app/shared/models/create-home-delivery-point-model';
import HomeDeliveryModel from 'src/app/shared/models/home-delivery-model';
import HomeDeliveryPointModel from 'src/app/shared/models/home-delivery-point-model';

@Component({
  selector: 'app-add-delivery',
  templateUrl: './add-delivery.component.html',
  styleUrls: ['./add-delivery.component.scss']
})
export class AddDeliveryComponent implements OnInit {
  latitude: number;
  longitude: number;
  zoom: number;

  addDeliveryForm: FormGroup;

  deliveryTypes: Array<DeliveryTypeModel>;

  formValidation = {
    deliveryType: 'normal',
    day: 'normal',
    timeStart: 'normal',
    timeEnd: 'normal',
    searchLocationName: 'normal',
    locationName: 'normal',
    searchFriends: 'normal',
    arrivalTime: 'normal',
    deliveryDescription: 'normal'
  };
  stepsCount = 1;

  locationDeliveryPoints: Array<CreateLocationDeliveryPointModel> = new Array<
    CreateLocationDeliveryPointModel
  >();
  homeDeliveryPoints: Array<CreateHomeDeliveryPointModel> = new Array<
    CreateHomeDeliveryPointModel
  >();

  searchFriendsList: Array<UserSearchSuggestionModel>;

  isFetchingCurrentPosition = false;
  geoLocationError = false;
  convertCoordinatesError: boolean;
  tooManyRequestsError: boolean;
  friendsSelected: Array<UserSearchSuggestionModel> = new Array<
    UserSearchSuggestionModel
  >();

  formError = '';
  selectedFriend: UserSearchSuggestionModel = null;

  @ViewChild('search')
  public searchElementRef: ElementRef;
  constructor(
    private mapService: MapService,
    private zone: NgZone,
    private userService: UserService,
    private deliveryService: DeliveryService,
    private router: Router
  ) {}

  ngOnInit() {
    this.resetCoordinates();
    this.addDeliveryForm = new FormGroup({
      deliveryType: new FormControl(null),
      day: new FormControl(null),
      timeStart: new FormControl(null),
      timeEnd: new FormControl(null),
      searchLocationName: new FormControl(''),
      locationName: new FormControl(''),
      latitude: new FormControl(),
      longitude: new FormControl(),
      searchFriends: new FormControl(''),
      selectAllFriends: new FormControl(true),
      arrivalTime: new FormControl(null),
      deliveryDescription: new FormControl('')
    });
    this.deliveryTypes = DeliveryTypesConstants.getDeliveryTypes();
    this.addDeliveryForm.get('deliveryType').setValue(this.deliveryTypes[0].id);
    this.initSearchLocation();

    this.initFormControls();
  }

  initFormControls() {
    const searchFriendsField = this.addDeliveryForm.get('searchFriends');
    searchFriendsField.valueChanges.subscribe(value => {
      if (value.length !== 0) {
        this.userService.getUsersSearchSuggestions(value).subscribe(data => {
          this.searchFriendsList = data;
          console.log(data);
        });
      }
    });

    const locationNameField = this.addDeliveryForm.get('locationName');
    locationNameField.valueChanges.subscribe(value => {
      if (value.length !== 0) {
        locationNameField.setErrors(null);
        this.formValidation.locationName = 'normal';
      }
    });

    const searchLocationField = this.addDeliveryForm.get('searchLocationName');
    searchLocationField.valueChanges.subscribe(value => {
      if (value.length !== 0) {
        this.initSearchLocation();
        locationNameField.setErrors(null);
        this.formValidation.locationName = 'normal';
      }
    });

    const timeStartField = this.addDeliveryForm.get('timeStart');
    timeStartField.valueChanges.subscribe(value => {
      if (value !== null) {
        timeStartField.setErrors(null);
        this.formValidation.timeStart = 'normal';
      }
    });

    const timeEndField = this.addDeliveryForm.get('timeEnd');
    timeEndField.valueChanges.subscribe(value => {
      if (value !== null) {
        timeEndField.setErrors(null);
        this.formValidation.timeEnd = 'normal';
      }
    });

    const dayField = this.addDeliveryForm.get('day');
    dayField.valueChanges.subscribe(value => {
      if (value !== null) {
        dayField.setErrors(null);
        this.formValidation.day = 'normal';
      }
    });

    const deliveryTypeField = this.addDeliveryForm.get('deliveryType');
    deliveryTypeField.valueChanges.subscribe(value => {
      if (value !== null) {
        deliveryTypeField.setErrors(null);
        this.formValidation.deliveryType = 'normal';
        this.resetForm();
      }
    });

    const descriptionField = this.addDeliveryForm.get('deliveryDescription');
    descriptionField.valueChanges.subscribe(value => {
      if (value !== null) {
        descriptionField.setErrors(null);
        this.formValidation.deliveryDescription = 'normal';
      }
    });

    const arrivalTimeField = this.addDeliveryForm.get('arrivalTime');
    arrivalTimeField.valueChanges.subscribe(value => {
      if (value !== null) {
        arrivalTimeField.setErrors(null);
        this.formValidation.arrivalTime = 'normal';
      }
    });
  }

  resetCoordinates() {
    const mapSettings = this.mapService.initMap();
    this.zoom = mapSettings.zoom;
    this.latitude = mapSettings.latitude;
    this.longitude = mapSettings.longitude;
  }

  onChangeDayPicker(result: Date): void {
    this.addDeliveryForm.get('day').setValue(result);
  }

  getCurrentPosition() {
    this.isFetchingCurrentPosition = true;
    const coordinatesCallback = value => {
      if (value.success) {
        this.geoLocationError = false;
        this.latitude = value.latitude + Math.random() * 0.00000001;
        this.longitude = value.longitude + Math.random() * 0.00000001;

        this.addDeliveryForm.get('latitude').setValue(value.latitude);
        this.addDeliveryForm.get('longitude').setValue(value.longitude);

        // this.latitudeMarker = value.latitude;
        // this.longitudeMarker = value.longitude;
        this.zoom = value.zoom;
        this.convertGeolocation();
        this.isFetchingCurrentPosition = false;
      } else {
        this.geoLocationError = true;
        this.isFetchingCurrentPosition = false;
      }
    };
    this.mapService.setCurrentPosition(coordinatesCallback);
  }

  convertGeolocation() {
    const locationNameCallBack = response => {
      if (response.success) {
        this.convertCoordinatesError = false;
        this.tooManyRequestsError = false;
        this.addDeliveryForm
          .get('searchLocationName')
          .setValue(response.locationName);
        this.addDeliveryForm.get('searchLocationName').markAsDirty();
        this.addDeliveryForm
          .get('locationName')
          .setValue(response.locationName);
      } else if (!response.success && response.status === 'OVER_QUERY_LIMIT') {
        this.tooManyRequestsError = true;
      } else {
        this.convertCoordinatesError = true;
        this.addDeliveryForm.get('searchLocationName').markAsDirty();
        this.addDeliveryForm.get('searchLocationName').setValue('');
        this.addDeliveryForm.get('locationName').setValue('');
      }

      this.zone.run(() => {
        console.log('enabled time travel');
      });
    };
    this.mapService.convertGeolocation(
      this.addDeliveryForm.get('longitude').value,
      this.addDeliveryForm.get('latitude').value,
      locationNameCallBack
    );
  }

  onClearLocation() {
    this.addDeliveryForm.get('locationName').setValue('');
    this.resetCoordinates();
  }

  initSearchLocation() {
    const locationCallBack = response => {
      if (response.success) {
        this.addDeliveryForm
          .get('locationName')
          .setValue(response.locationName);
        this.addDeliveryForm.get('latitude').setValue(response.latitude);
        this.addDeliveryForm.get('longitude').setValue(response.longitude);
      }
    };
    if (this.searchElementRef !== undefined) {
      this.mapService.searchLocation(this.searchElementRef, locationCallBack);
    }
  }

  onClickFriendSuggestion(value) {
    this.addDeliveryForm.get('searchFriends').setValue('');
    const user = this.searchFriendsList.filter(a => a.userId === value)[0];
    if (user && this.friendsSelected.indexOf(user) === -1) {
      this.friendsSelected.push(user);
      this.addDeliveryForm.get('searchFriends').setErrors(null);
      this.formValidation.searchFriends = 'normal';
      console.log(this.friendsSelected);
    }
  }

  onClickFriendHomeLocation(value) {
    const user = this.searchFriendsList.filter(a => a.userId === value)[0];
    if (user && this.friendsSelected.indexOf(user) === -1) {
      this.selectedFriend = user;
      this.addDeliveryForm.get('searchFriends').setErrors(null);
      this.formValidation.searchFriends = 'normal';
      console.log(this.selectedFriend);
    }
  }

  addLocationDeliveryPoint() {
    if (!this.validateLocationDeliveryForm()) {
      return false;
    }
    const deliveryPoint = new CreateLocationDeliveryPointModel();
    deliveryPoint.locationName = this.addDeliveryForm.get('locationName').value;
    deliveryPoint.latitude = this.addDeliveryForm.get('latitude').value;
    deliveryPoint.longitude = this.addDeliveryForm.get('longitude').value;
    deliveryPoint.timeStart = this.addDeliveryForm.get('timeStart').value;
    deliveryPoint.timeEnd = this.addDeliveryForm.get('timeEnd').value;
    if (this.addDeliveryForm.get('selectAllFriends').value === true) {
      deliveryPoint.isForAllFriends = true;
    } else {
      deliveryPoint.friendsList = this.friendsSelected.map(a => a.userId);
    }
    deliveryPoint.description = this.addDeliveryForm.get(
      'deliveryDescription'
    ).value;
    this.locationDeliveryPoints.push(deliveryPoint);
    this.resetAddPointForm();

    console.log(this.locationDeliveryPoints);
    this.stepsCount++;
  }

  addHomeDeliveryStep() {
    if (!this.validateHomeDeliveryForm()) {
      return false;
    }
    const deliveryPoint = new CreateHomeDeliveryPointModel();
    deliveryPoint.arrivalTime = this.addDeliveryForm.get('arrivalTime').value;
    deliveryPoint.userId = this.selectedFriend.userId;
    deliveryPoint.user = this.selectedFriend;
    deliveryPoint.description = this.addDeliveryForm.get(
      'deliveryDescription'
    ).value;

    this.resetAddHomeStepForm();
    this.homeDeliveryPoints.push(deliveryPoint);
    console.log(this.homeDeliveryPoints);
    this.stepsCount++;
  }

  resetAddPointForm() {
    this.addDeliveryForm.get('searchLocationName').setValue('');
    this.addDeliveryForm.get('locationName').setValue('');
    this.addDeliveryForm.get('latitude').setValue('');
    this.addDeliveryForm.get('longitude').setValue('');
    this.addDeliveryForm.get('timeStart').setValue(null);
    this.addDeliveryForm.get('timeEnd').setValue(null);
    this.addDeliveryForm.get('selectAllFriends').setValue(true);
    this.addDeliveryForm.get('deliveryDescription').setValue('');
  }

  resetAddHomeStepForm() {
    this.addDeliveryForm.get('searchFriends').setValue('');
    this.addDeliveryForm.get('arrivalTime').setValue(null);
    this.addDeliveryForm.get('deliveryDescription').setValue('');
    this.selectedFriend = null;
  }

  resetForm() {
    this.addDeliveryForm.get('searchLocationName').setValue('');
    this.addDeliveryForm.get('locationName').setValue('');
    this.addDeliveryForm.get('latitude').setValue('');
    this.addDeliveryForm.get('longitude').setValue('');

    this.addDeliveryForm.get('timeStart').setValue(null);

    this.addDeliveryForm.get('timeEnd').setValue(null);
    this.addDeliveryForm.get('selectAllFriends').setValue(true);
    this.addDeliveryForm.get('day').setValue(null);
    this.addDeliveryForm.get('arrivalTime').setValue(null);
    this.addDeliveryForm.get('deliveryDescription').setValue('');
    this.addDeliveryForm.get('searchFriends').setValue('');

    this.homeDeliveryPoints = new Array<CreateHomeDeliveryPointModel>();
    this.locationDeliveryPoints = new Array<CreateLocationDeliveryPointModel>();
    this.stepsCount = 1;
  }

  onChangePointLocation(event) {
    console.log(event);
    this.addDeliveryForm.get('latitude').setValue(event.coords.lat);
    this.addDeliveryForm.get('longitude').setValue(event.coords.lng);
    this.convertGeolocation();
  }

  validateLocationDeliveryForm() {
    CommonMethods.markFormGroupTouchedAndDirty(this.addDeliveryForm);

    const dayField = this.addDeliveryForm.get('day');
    if (dayField.value === null) {
      dayField.setErrors({ required: true });
      this.formValidation.day = 'error';
    }

    const deliveryType = this.addDeliveryForm.get('deliveryType');
    if (deliveryType.value === null) {
      deliveryType.setErrors({ required: true });
      this.formValidation.deliveryType = 'error';
    }

    const locationNameField = this.addDeliveryForm.get('locationName');
    if (locationNameField.value.length === 0) {
      locationNameField.setErrors({ required: true });
      this.formValidation.locationName = 'error';
    }

    const timeStartField = this.addDeliveryForm.get('timeStart');
    if (timeStartField.value === null) {
      timeStartField.setErrors({ required: true });
      this.formValidation.timeStart = 'error';
    }

    const timeEndField = this.addDeliveryForm.get('timeEnd');
    if (timeEndField.value === null) {
      timeEndField.setErrors({ required: true });
      this.formValidation.timeEnd = 'error';
    }

    const searchFriendsField = this.addDeliveryForm.get('searchFriends');
    if (
      this.addDeliveryForm.get('selectAllFriends').value === false &&
      this.friendsSelected.length === 0
    ) {
      searchFriendsField.setErrors({ required: true });
      this.formValidation.searchFriends = 'error';
    }

    const descriptionField = this.addDeliveryForm.get('deliveryDescription');
    if (
      descriptionField.value === null ||
      descriptionField.value.length === 0
    ) {
      descriptionField.setErrors({ required: true });
      this.formValidation.deliveryDescription = 'error';
    }

    if (!this.addDeliveryForm.valid) {
      return false;
    }
    return true;
  }

  validateHomeDeliveryForm() {
    CommonMethods.markFormGroupTouchedAndDirty(this.addDeliveryForm);

    const dayField = this.addDeliveryForm.get('day');
    if (dayField.value === null) {
      dayField.setErrors({ required: true });
      this.formValidation.day = 'error';
    }

    const deliveryType = this.addDeliveryForm.get('deliveryType');
    if (deliveryType.value === null) {
      deliveryType.setErrors({ required: true });
      this.formValidation.deliveryType = 'error';
    }

    const arrivalTimeField = this.addDeliveryForm.get('arrivalTime');
    if (arrivalTimeField.value === null) {
      arrivalTimeField.setErrors({ required: true });
      this.formValidation.arrivalTime = 'error';
    }

    const descriptionField = this.addDeliveryForm.get('deliveryDescription');
    if (
      descriptionField.value === null ||
      descriptionField.value.length === 0
    ) {
      descriptionField.setErrors({ required: true });
      this.formValidation.deliveryDescription = 'error';
    }

    const searchFriends = this.addDeliveryForm.get('searchFriends');
    if (this.selectedFriend === null) {
      searchFriends.setErrors({ required: true });
      this.formValidation.searchFriends = 'error';
    }

    if (!this.addDeliveryForm.valid) {
      return false;
    }
    return true;
  }

  saveDeliveryPlan() {
    CommonMethods.markFormGroupTouchedAndDirty(this.addDeliveryForm);
    this.formError = '';
    const dayField = this.addDeliveryForm.get('day');
    if (dayField.value === null) {
      dayField.setErrors({ required: true });
      this.formValidation.day = 'error';
    }

    const deliveryType = this.addDeliveryForm.get('deliveryType');
    if (deliveryType.value === null) {
      deliveryType.setErrors({ required: true });
      this.formValidation.deliveryType = 'error';
    }

    if (this.locationDeliveryPoints.length === 0) {
      this.formError = 'You must have at least one delivery point';
      return false;
    }

    const locationDelivery = new CreateLocationDeliveryModel();
    locationDelivery.day = this.addDeliveryForm.get('day').value;
    locationDelivery.deliveryTypeId = this.addDeliveryForm.get(
      'deliveryType'
    ).value;

    locationDelivery.locationDeliveryPoints = this.locationDeliveryPoints;

    this.deliveryService.addLocationDelivery(locationDelivery).subscribe(
      () => {
        console.log('success');
        this.resetForm();
        this.router.navigate(['./my-deliveries']);
      },
      error => {
        console.log(error.error);
      }
    );
  }

  saveHomeDeliveryPlan() {
    console.log(this.homeDeliveryPoints);

    CommonMethods.markFormGroupTouchedAndDirty(this.addDeliveryForm);
    this.formError = '';
    const dayField = this.addDeliveryForm.get('day');
    if (dayField.value === null) {
      dayField.setErrors({ required: true });
      this.formValidation.day = 'error';
    }

    const deliveryType = this.addDeliveryForm.get('deliveryType');
    if (deliveryType.value === null) {
      deliveryType.setErrors({ required: true });
      this.formValidation.deliveryType = 'error';
    }

    if (this.homeDeliveryPoints.length === 0) {
      this.formError = 'You must have at least one delivery point';
      return false;
    }

    const homeDelivery = new CreateHomeDeliveryModel();
    homeDelivery.day = this.addDeliveryForm.get('day').value;
    homeDelivery.deliveryTypeId = this.addDeliveryForm.get(
      'deliveryType'
    ).value;

    homeDelivery.homeDeliveryPoints = this.homeDeliveryPoints;

    this.deliveryService.addHomeDelivery(homeDelivery).subscribe(
      () => {
        console.log('success');
        this.resetForm();
        this.router.navigate(['./my-deliveries']);
      },
      error => {
        console.log(error.error);
      }
    );
  }
}
