import { Component, OnInit } from '@angular/core';
import LocationDeliveryModel from 'src/app/shared/models/location-delivery-model';
import HomeDeliveryModel from 'src/app/shared/models/home-delivery-model';
import { DeliveryService } from 'src/app/services/delivery.service';

@Component({
  selector: 'app-my-deliveries',
  templateUrl: './my-deliveries.component.html',
  styleUrls: ['./my-deliveries.component.scss']
})
export class MyDeliveriesComponent implements OnInit {
  locationDeliveries: Array<LocationDeliveryModel>;
  homeDeliveries: Array<HomeDeliveryModel>;
  currentDelivery = 0;
  currentTabSelected = 0;
  constructor(private deliveryService: DeliveryService) {}

  ngOnInit() {
    this.deliveryService.getUserLocationDeliveries().subscribe(data => {
      this.locationDeliveries = data;
      console.log(data);
    });

    this.deliveryService.getUserHomeDeliveries().subscribe(data => {
      this.homeDeliveries = data;
      console.log(this.homeDeliveries);
    });
  }

  onChangeDelivery(value) {
    this.currentDelivery = value;
  }

  onCurrentTabChange(value) {
    this.currentTabSelected = value.index;
    this.currentDelivery = 0;
  }
}
