import { Component, OnInit } from '@angular/core';
import LocationDeliveryModel from 'src/app/shared/models/location-delivery-model';
import { DeliveryService } from 'src/app/services/delivery.service';
import HomeDeliveryModel from 'src/app/shared/models/home-delivery-model';

@Component({
  selector: 'app-deliveries',
  templateUrl: './deliveries.component.html',
  styleUrls: ['./deliveries.component.scss']
})
export class DeliveriesComponent implements OnInit {
  locationDeliveries: Array<LocationDeliveryModel>;
  homeDeliveries: Array<HomeDeliveryModel>;
  currentDelivery = 0;
  currentTabSelected = 0;
  constructor(private deliveryService: DeliveryService) {}

  ngOnInit() {
    this.deliveryService.getLocationDeliveries().subscribe(data => {
      this.locationDeliveries = data;
      console.log(data);
    });

    this.deliveryService.getHomeDeliveries().subscribe(data => {
      this.homeDeliveries = data;
      console.log(this.homeDeliveries);
    });
  }

  onChangeDelivery(value) {
    this.currentDelivery = value;
  }

  onCurrentTabChange(value) {
    this.currentTabSelected = value.index;
    this.currentDelivery = 0;
  }
}
