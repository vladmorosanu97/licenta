import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeDeliveryPointComponent } from './home-delivery-point.component';

describe('HomeDeliveryPointComponent', () => {
  let component: HomeDeliveryPointComponent;
  let fixture: ComponentFixture<HomeDeliveryPointComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeDeliveryPointComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeDeliveryPointComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
