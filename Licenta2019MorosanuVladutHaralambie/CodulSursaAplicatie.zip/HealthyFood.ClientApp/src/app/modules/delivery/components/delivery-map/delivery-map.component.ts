import { Component, OnInit, Input } from '@angular/core';
import LocationDeliveryModel from 'src/app/shared/models/location-delivery-model';
import HomeDeliveryModel from 'src/app/shared/models/home-delivery-model';
import UserLocationsModel from 'src/app/shared/models/user-locations-model';

@Component({
  selector: 'app-delivery-map',
  templateUrl: './delivery-map.component.html',
  styleUrls: ['./delivery-map.component.scss']
})
export class DeliveryMapComponent implements OnInit {
  @Input() locationDelivery: LocationDeliveryModel = null;
  @Input() homeDelivery: HomeDeliveryModel = null;
  constructor() {}

  ngOnInit() {}
}
