import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LocationDeliveryPointComponent } from './location-delivery-point.component';

describe('LocationDeliveryPointComponent', () => {
  let component: LocationDeliveryPointComponent;
  let fixture: ComponentFixture<LocationDeliveryPointComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LocationDeliveryPointComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LocationDeliveryPointComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
