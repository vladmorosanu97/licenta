import { Component, OnInit, Input } from '@angular/core';
import UserSearchSuggestionModel from 'src/app/shared/models/user-search-suggestion-model';

@Component({
  selector: 'app-user-avatar',
  templateUrl: './user-avatar.component.html',
  styleUrls: ['./user-avatar.component.scss']
})
export class UserAvatarComponent implements OnInit {
  @Input() user: UserSearchSuggestionModel;
  @Input() size: string;
  constructor() {}

  ngOnInit() {}
}
