import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryDescriptionComponent } from './delivery-description.component';

describe('DeliveryDescriptionComponent', () => {
  let component: DeliveryDescriptionComponent;
  let fixture: ComponentFixture<DeliveryDescriptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryDescriptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryDescriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
