import { Component, OnInit, Input } from '@angular/core';
import HomeDeliveryPointModel from 'src/app/shared/models/home-delivery-point-model';

@Component({
  selector: 'app-home-delivery-point',
  templateUrl: './home-delivery-point.component.html',
  styleUrls: ['./home-delivery-point.component.scss']
})
export class HomeDeliveryPointComponent implements OnInit {
  @Input() homeDeliveryPoint: HomeDeliveryPointModel;
  constructor() {}

  ngOnInit() {}
}
