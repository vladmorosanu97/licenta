import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddDeliveryComponent } from './pages/add-delivery/add-delivery.component';
import { IsAuthenticatedGuard } from 'src/app/core/guards/is-authenticated.guard';
import { Routes, RouterModule } from '@angular/router';
import { DeliveriesComponent } from './pages/deliveries/deliveries.component';
import { MyDeliveriesComponent } from './pages/my-deliveries/my-deliveries.component';

const routes: Routes = [
  {
    path: 'add-delivery',
    component: AddDeliveryComponent,
    canActivate: [IsAuthenticatedGuard]
  },
  {
    path: 'deliveries',
    component: DeliveriesComponent,
    canActivate: [IsAuthenticatedGuard]
  },
  {
    path: 'my-deliveries',
    component: MyDeliveriesComponent,
    canActivate: [IsAuthenticatedGuard]
  }
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(routes)]
})
export class DeliveryRoutingModule {}
