import { debounceTime } from 'rxjs/operators';
import { FormGroup, FormControl } from '@angular/forms';
import { Component, OnInit, ViewChild } from '@angular/core';
import { AdvertisementService } from 'src/app/services/advertisement.service';
import AdvertisementCardModel from 'src/app/shared/models/advertisement-card-model';
import { MapService } from 'src/app/services/map.service';
import { element } from '@angular/core/src/render3';
import { AgmMap } from '@agm/core';
import { HeaderService } from 'src/app/services/header.service';
import SearchInputModel from 'src/app/shared/models/search-input-model';
import SearchAdvertisementsModel from 'src/app/shared/models/search-advertisements-model';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
  advertisementsCards: Array<AdvertisementCardModel>;
  latitude: number;
  longitude: number;
  latitudeUserMarker: number;
  longitudeUserMarker: number;
  geoLocationError = false;
  toggleMap = true;
  previous: any;
  @ViewChild(AgmMap)
  public agmMap: AgmMap;
  searchForm: FormGroup;
  isFetchingAdvertisements = false;
  pageNumber = 1;
  searchInputModel: SearchInputModel;
  isSearchByDistance = true;
  constructor(
    private advertisementService: AdvertisementService,
    private mapService: MapService,
    private headerService: HeaderService
  ) {}

  ngOnInit() {
    this.searchForm = new FormGroup({
      distance: new FormControl(25),
      maxDistance: new FormControl(50),
      toggleMap: new FormControl()
    });
    this.initFormControls();
    const val = localStorage.getItem('toggleMap');
    if (val === undefined) {
      this.searchForm.get('toggleMap').setValue(false);
    } else {
      this.searchForm.get('toggleMap').setValue(val === 'true');
    }

    const initMap = this.mapService.initMap();
    this.latitude = initMap.latitude;
    this.longitude = initMap.longitude;

    this.getCurrentPosition();
    // this.getAdvertisements(null);
    this.headerService.getSearchProductsObserver().subscribe(item => {
      this.searchInputModel = item;
      this.isSearchByDistance = false;
      this.getAdvertisements();
    });

    this.searchForm.get('toggleMap').valueChanges.subscribe(data => {
      localStorage.setItem('toggleMap', data);
    });
  }

  getAdvertisements() {
    const currentCoordinates = value => {
      let latitude: number = null;
      let longitude: number = null;
      if (value.success === true) {
        latitude = value.latitude;
        longitude = value.longitude;
      }
      const distance = this.searchForm.get('distance').value;
      this.isFetchingAdvertisements = true;
      const searchAdvertisementsModel = new SearchAdvertisementsModel();
      searchAdvertisementsModel.latitude = latitude;
      searchAdvertisementsModel.longitude = longitude;
      searchAdvertisementsModel.maxDistance = distance;
      searchAdvertisementsModel.pageNumber = this.pageNumber;
      searchAdvertisementsModel.searchText = this.searchInputModel
        ? this.searchInputModel.searchText
        : null;

      searchAdvertisementsModel.isSearchByDistance = this.isSearchByDistance;

      this.advertisementService
        .getAdvertisementsCard(searchAdvertisementsModel)
        .subscribe(
          data => {
            this.advertisementsCards = data;
            this.isFetchingAdvertisements = false;
          },
          () => {
            this.isFetchingAdvertisements = false;
          }
        );
    };
    this.mapService.setCurrentPosition(currentCoordinates);
  }

  onToggleMap() {
    this.toggleMap = !this.toggleMap;
  }

  onClickMarkerInfo(infoWindow, gm: any) {
    if (gm.lastOpen) {
      gm.lastOpen.close();
    }
    gm.lastOpen = infoWindow;

    infoWindow.open();
  }

  closeMarkerInfo(gm: any) {
    if (gm.lastOpen) {
      gm.lastOpen.close();
    }
  }

  changeMaxDistance(event) {
    this.searchForm.get('maxDistance').setValue(event);
  }

  initFormControls() {
    const distanceField = this.searchForm.get('distance');
    distanceField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      this.isSearchByDistance = true;
      this.getAdvertisements();
    });
  }

  onChangePageNumber(value) {
    console.log(value);
    this.pageNumber = value;
    this.getAdvertisements();
  }

  getCurrentPosition() {
    const coordinatesCallback = value => {
      if (value.success) {
        this.geoLocationError = false;

        this.latitudeUserMarker = value.latitude;
        this.longitudeUserMarker = value.longitude;
      } else {
        this.geoLocationError = true;
      }
    };
    this.mapService.setCurrentPosition(coordinatesCallback);
  }
}
