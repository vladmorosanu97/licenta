import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchComponent } from './pages/search/search.component';
import { IsAuthenticatedGuard } from 'src/app/core/guards/is-authenticated.guard';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'search',
    component: SearchComponent,
    canActivate: [IsAuthenticatedGuard]
  }
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(routes)]
})
export class SearchRoutingModule {}
