import { SharedModule } from './../../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatComponent } from './pages/chat/chat.component';
import { MessageRoutingModule } from './message-routing.module';
import { ConversationInfoComponent } from './components/conversation-info/conversation-info.component';
import { MessageComponent } from './components/message/message.component';
import { CoreModule } from 'src/app/core/core.module';
import { ConversationCardComponent } from './components/conversation-card/conversation-card.component';
import { DeliveryModule } from '../delivery/delivery.module';

@NgModule({
  declarations: [
    ChatComponent,
    ConversationCardComponent,
    ConversationInfoComponent,
    MessageComponent
  ],
  imports: [
    CoreModule,
    SharedModule,
    CommonModule,
    MessageRoutingModule,
    DeliveryModule
  ]
})
export class MessageModule {}
