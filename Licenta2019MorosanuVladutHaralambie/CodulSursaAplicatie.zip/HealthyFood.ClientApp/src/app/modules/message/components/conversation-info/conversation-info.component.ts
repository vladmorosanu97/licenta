import {
  Component,
  OnInit,
  Input,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import ChatModel from 'src/app/shared/models/chat-model';
import { MapService } from 'src/app/services/map.service';

@Component({
  selector: 'app-conversation-info',
  templateUrl: './conversation-info.component.html',
  styleUrls: ['./conversation-info.component.scss']
})
export class ConversationInfoComponent implements OnInit, OnChanges {
  @Input() chat: ChatModel;
  latitudeUserMarker: number;
  longitudeUserMarker: number;
  geoLocationError = false;
  distance: number;
  constructor(private mapService: MapService) {}

  ngOnInit() {
    this.getCurrentPosition();
  }

  getCurrentPosition() {
    const coordinatesCallback = value => {
      if (value.success) {
        this.geoLocationError = false;

        this.latitudeUserMarker = value.latitude;
        this.longitudeUserMarker = value.longitude;
        if (this.chat == null) {
          return false;
        }
        this.distance = this.mapService.calculateDistance(
          this.latitudeUserMarker,
          this.longitudeUserMarker,
          this.chat.user.latitude,
          this.chat.user.longitude
        );
      } else {
        this.geoLocationError = true;
      }
    };
    this.mapService.setCurrentPosition(coordinatesCallback);
  }

  ngOnChanges(changes: SimpleChanges) {
    this.getCurrentPosition();
  }
}
