import { Routes, RouterModule } from '@angular/router';
import { IsAuthenticatedGuard } from 'src/app/core/guards/is-authenticated.guard';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatComponent } from './pages/chat/chat.component';

const routes: Routes = [
  {
    path: 'messages',
    children: [{ path: ':userId', component: ChatComponent }],
    component: ChatComponent,
    canActivate: [IsAuthenticatedGuard]
  }
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(routes)]
})
export class MessageRoutingModule {}
