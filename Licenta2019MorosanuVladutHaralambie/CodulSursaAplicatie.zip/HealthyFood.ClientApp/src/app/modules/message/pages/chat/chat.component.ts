import { Subject, BehaviorSubject } from 'rxjs';
import { FormGroup, FormControl } from '@angular/forms';
import { join } from 'path';
import { AuthService } from '../../../../services/auth.service';
import { HttpClient } from '@angular/common/http';
import { SignalrService } from './../../../../services/signalr.service';
import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import ChatModel from 'src/app/shared/models/chat-model';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import MessageModel from 'src/app/shared/models/message-model';
import { ChatService } from 'src/app/services/chat.service';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss']
})
export class ChatComponent implements OnInit {
  chats: Array<ChatModel>;
  currentChat: ChatModel = null;
  chatName: string;
  chatId: number;
  messages: Array<MessageModel> = new Array<MessageModel>();
  userId: number;
  sendMessageForm: FormGroup;
  parameterId: number = null;
  isFetchingMessages = false;
  isFetchingChatInfo = false;
  isFetchingChatList = false;
  connectedToPartnerId: number;
  constructor(
    private signalrService: SignalrService,
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private chatService: ChatService
  ) {
    router.events.subscribe(val => {
      // see also
      if (
        val instanceof NavigationEnd &&
        val.url === '/messages' &&
        this.parameterId !== null
      ) {
        this.chatService.chatObserver.next(this.parameterId);
        this.router.navigate(['/messages', this.parameterId]);
      }
    });
  }

  ngOnInit() {
    this.userId = this.authService.getUserId();
    if (this.route.children.length > 0) {
      this.parameterId = this.route.children[0].snapshot.params.userId;
      if (this.parameterId !== undefined && this.parameterId !== null) {
        this.chatService.chatObserver.next(this.parameterId);
      }
    }

    this.signalrService.connectionObserver.subscribe(data => {
      if (data == null) {
        return false;
      }
      this.isFetchingChatInfo = true;
      this.signalrService.getChats();
      this.chatService.chatObserver.subscribe(partnerId => {
        this.parameterId = partnerId;
        // tslint:disable-next-line: radix
        console.log('receive from observer');
        if (
          partnerId !== null &&
          partnerId !== undefined &&
          partnerId !== this.connectedToPartnerId
        ) {
          this.isFetchingChatInfo = true;
          this.signalrService.joinToChat(partnerId).then((chat: ChatModel) => {
            this.connectedToPartnerId = partnerId;
            this.isFetchingChatInfo = false;

            this.currentChat = chat;
            console.log(this.currentChat);
            this.chatName = chat.name;
            this.chatId = chat.chatId;

            this.isFetchingMessages = true;
            this.signalrService
              .getMessages(this.chatId)
              .then((messages: Array<MessageModel>) => {
                this.messages = messages;
                this.isFetchingMessages = false;
              });
          });
        }
      });
    });
    this.signalrService.getMessageListener(this.getMessageCallback);

    this.signalrService.GetChatsListener(this.getChatCallback);
    this.sendMessageForm = new FormGroup({
      content: new FormControl('')
    });
  }

  getChatCallback = (data: Array<ChatModel>) => {
    this.isFetchingChatList = false;
    this.chats = data;
    if (this.parameterId === null && this.chats[0] !== undefined) {
      this.parameterId = this.chats[0].user.userId;
      this.router.navigate(['/messages', this.chats[0].user.userId]);
      this.chatService.chatObserver.next(this.parameterId);
    }
  };

  getMessageCallback = (message: MessageModel) => {
    this.messages.push(message);
  };

  sendMessageToGroup() {
    const content = this.sendMessageForm.get('content').value;
    if (content.length === 0) {
      return false;
    }

    const message = new MessageModel();
    message.authorId = this.userId;
    message.content = content;
    message.chatId = this.chatId;

    this.signalrService.sendMessageToGroup(message);
    this.sendMessageForm.get('content').setValue('');
  }

  selectChat(value) {
    this.parameterId = value;
    this.chatService.chatObserver.next(this.parameterId);
  }
}
