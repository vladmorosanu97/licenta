import { NgModule } from '@angular/core';
import { HeaderComponent } from './header/header.component';
import { SharedModule } from '../shared/shared.module';
import { MenuComponent } from './menu/menu.component';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthorizationInterceptor } from './interceptors/authorization.interceptor';
import { DatePipe } from './pipes/date.pipe';
import { ChatActivityPipe } from './pipes/chat-activity.pipe';
import { TimePipe } from './pipes/time.pipe';

@NgModule({
  declarations: [
    HeaderComponent,
    MenuComponent,
    DatePipe,
    ChatActivityPipe,
    TimePipe
  ],
  imports: [SharedModule],
  exports: [
    HeaderComponent,
    MenuComponent,
    DatePipe,
    ChatActivityPipe,
    TimePipe
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthorizationInterceptor,
      multi: true
    }
  ]
})
export class CoreModule {}
