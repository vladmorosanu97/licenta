import { Component, OnInit, Input } from '@angular/core';
import { Subject } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';
import { AdvertisementService } from 'src/app/services/advertisement.service';
import SearchSuggestionModel from 'src/app/shared/models/search-suggestion-model';
import { FormGroup, FormControl } from '@angular/forms';
import { HeaderService } from 'src/app/services/header.service';
import SearchInputModel from 'src/app/shared/models/search-input-model';
import { MenuService } from 'src/app/services/menu.service';
import MenuItems from 'src/app/shared/constants/menu-items-constants';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import SettingsItems from 'src/app/shared/constants/settings-items-constants';
import UserSearchSuggestionModel from 'src/app/shared/models/user-search-suggestion-model';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  inputValue: string;
  optionsProducts: Array<SearchSuggestionModel> = [];
  optionsUsers: Array<UserSearchSuggestionModel> = [];
  isMenuVisible = true;
  data = '';
  menuItems = MenuItems;
  settingsItems = SettingsItems;
  selectedItemMenu = '';

  productsFormGroup: FormGroup;
  usersFormGroup: FormGroup;
  constructor(
    private authService: AuthService,
    private advertisementService: AdvertisementService,
    private headerService: HeaderService,
    private router: Router,
    private userService: UserService
  ) {}

  ngOnInit() {
    this.selectedItemMenu = this.menuItems.search;
    this.productsFormGroup = new FormGroup({
      searchText: new FormControl('')
    });

    this.usersFormGroup = new FormGroup({
      searchText: new FormControl('')
    });

    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.selectedItemMenu = event.url;
      }
    });
  }

  onInputProducts(value: string): void {
    if (value.length > 0) {
      this.advertisementService.getSearchSuggestions(value).subscribe(data => {
        this.optionsProducts = data;
      });
    } else {
      this.optionsProducts = [];
    }
  }

  onInputUsers(value: string): void {
    if (value.length > 0) {
      this.userService.getUsersSearchSuggestions(value).subscribe(data => {
        this.optionsUsers = data;
      });
    } else {
      this.optionsUsers = [];
    }
  }

  onToggleMenu() {
    this.isMenuVisible = !this.isMenuVisible;
    this.headerService.onToggleMenu(this.isMenuVisible);
  }

  submitSearchProducts() {
    const searchText = this.productsFormGroup.get('searchText').value;
    let searchAdvertisements = new SearchInputModel();
    if (searchText === undefined || searchText.length === 0) {
      this.headerService.onSearchProducts(null);
      return false;
    }
    searchAdvertisements.searchText = searchText;
    this.headerService.onSearchProducts(searchAdvertisements);
  }

  submitSearchUsers() {
    const searchText = this.usersFormGroup.get('searchText').value;
    let searchUsers = '';
    if (searchText === undefined || searchText.length === 0) {
      this.headerService.onSearchUsers(null);
      return false;
    }
    searchUsers = searchText;
    this.headerService.onSearchUsers(searchUsers);
  }

  logout() {
    this.authService.logOut();
    this.headerService.onLogout(true);
  }
}
