import { Component, OnInit, NgZone } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { UserRoles } from 'src/app/shared/constants/user-roles-constants';
import { MenuService } from 'src/app/services/menu.service';
import MenuItems from 'src/app/shared/constants/menu-items-constants';
import { HeaderService } from 'src/app/services/header.service';
import { SignalrService } from 'src/app/services/signalr.service';
import ChatModel from 'src/app/shared/models/chat-model';
import { Router, NavigationEnd } from '@angular/router';
import UserModel from 'src/app/shared/models/user-model';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {
  userProfile: UserModel;
  userRole: string;
  userRoles = UserRoles;
  menuItems = MenuItems;
  isMenuVisible = true;
  chats: Array<ChatModel>;
  newMessagesCount: number;
  selectedItemMenu = '';
  firstStart: string = '';
  friendsRequestsCount = 0;
  constructor(
    private authService: AuthService,
    private headerService: HeaderService,
    private signalrService: SignalrService,
    private router: Router,
    private ngZone: NgZone,
    private userService: UserService
  ) {}

  ngOnInit() {
    this.userProfile = this.authService.getClaims();
    this.userRole = this.authService.getRole();

    this.authService.loggedIn.subscribe(() => {
      console.log(this.authService.getClaims());
      if (this.authService.isAuthenticated()) {
        this.userProfile = this.authService.getClaims();
        this.userRole = this.authService.getRole();
      }

      this.ngZone.run(() => {});
    });

    this.headerService.getToggleMenuObserver().subscribe(data => {
      this.isMenuVisible = data;
    });

    this.signalrService.connectionObserver.subscribe(data => {
      if (data == null) {
        return false;
      }
      this.signalrService.getChats();
    });

    this.signalrService.GetChatsListener(this.getChatCallback);

    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.selectedItemMenu = event.url;

        if (this.firstStart === '') {
          this.firstStart = this.selectedItemMenu;
        }
      }
    });

    this.getFriendsRequests();
  }

  getFriendsRequests() {
    this.userService.getFriendsRequests().subscribe(data => {
      this.friendsRequestsCount = data.length;
      console.log(this.friendsRequestsCount);
    });
  }

  getChatCallback = (data: Array<ChatModel>) => {
    this.chats = data;
    this.newMessagesCount = this.chats.filter(a => a.messagesCount > 0).length;
  };

  resetFriendsRequest() {
    this.getFriendsRequests();
  }
}
