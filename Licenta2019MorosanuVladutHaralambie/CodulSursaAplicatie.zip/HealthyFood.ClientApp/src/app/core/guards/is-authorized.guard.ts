import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  CanActivate,
  Router
} from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';
import { UserRoles } from 'src/app/shared/constants/user-roles-constants';

@Injectable({
  providedIn: 'root'
})
export class IsAuthorizedGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    // const role = this.authService.isAuthorized();
    // if (role  !== UserRoles.client && role !== UserRoles.client) {
    //   this.router
    //     .navigate(['/unauthorized'], { queryParams: { returnUrl: state.url } })
    //     .then(x => {});
    //   return false;
    // }
    return true;
  }
}
