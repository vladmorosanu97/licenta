import ChatUserModel from './chat-user-model';
import UserModel from './user-model';

export default class ChatModel {
  chatId: number;
  name: string;
  user: UserModel;
  messagesCount: number;
  isOnline: boolean;
  rating: number;
  lastTimeOnline: Date;
}
