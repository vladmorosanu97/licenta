import { NumberSymbol } from '@angular/common';

export default class AdvertisementCardModel {
  advertisementId: number;
  title: string;
  price: number;
  locationName: string;
  longitude: number;
  latitude: number;
  firstName: string;
  lastName: string;
  guidFileName: string;
  imagePath: string;
  distance: number;
  totalPages: number;
  pageNumber: number;
  categoryId: number;
}
