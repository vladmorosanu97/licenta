export default class CategoryModel {
  name: string;
  categoryId: number;
}
