import { FormGroup } from '../../../node_modules/@angular/forms';

export class CommonMethods {
  public static markFormGroupTouched(formGroup: FormGroup) {
    (<any>Object).values(formGroup.controls).forEach(control => {
      if (control.dirty === false) {
        control.markAsTouched();
        control.markAsDirty();
        control.setErrors({ required: true });
      }

      if (control.controls) {
        this.markFormGroupTouched(control);
      }
    });
  }

  public static resetForm(formGroup: FormGroup) {
    (<any>Object).values(formGroup.controls).forEach(control => {
      control.setValue('');
    });
  }

  public static markFormGroupTouchedAndDirty(formGroup: FormGroup) {
    (<any>Object).values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      control.markAsDirty();

      if (control.controls) {
        this.markFormGroupTouched(control);
      }
    });
  }

  public static toBytesArray(str) {
    const result = [];
    for (let i = 0; i < str.length; i++) {
      result.push(str.charCodeAt(i));
    }
    return result;
  }

  public static stringFromBytes(bytes) {
    let text = '';
    for (let i = 0, l = bytes.length; i < l; i++) {
      text += String.fromCharCode(bytes[i]);
    }
    return text;
  }

  public static b64DecodeUnicode(str) {
    return decodeURIComponent(
      Array.prototype.map
        .call(atob(str), function(c) {
          return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        })
        .join('')
    );
  }

  /**
   * Get a random color for charts
   */
  public static getRandomColor(): any {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }

  /**
   * Generic sorting function for alphabetic ascending sorting
   * @param firstObject First Object
   * @param secondModule Second Object
   */
  public static sortObjectsByName(firstObject, secondModule) {
    const firstObjectName = firstObject.Name.toUpperCase();
    const secondSecondName = secondModule.Name.toUpperCase();
    if (firstObjectName < secondSecondName) {
      return -1;
    }
    if (firstObjectName > secondModule) {
      return 1;
    }
    return 0;
  }

  public static getBase64(img: File, callback): void {
    const reader = new FileReader();
    reader.addEventListener('load', () =>
      callback(reader.result as ArrayBuffer)
    );
    reader.readAsDataURL(img);
  }
}
