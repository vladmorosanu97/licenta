import DeliveryTypeModel from '../models/delivery-type-model';

export default class DeliveryTypesConstants {
  public static homeDelivery: DeliveryTypeModel;
  public static locationDelivery: DeliveryTypeModel;
  /**
   *
   */
  constructor() {}

  public static getDeliveryTypes(): Array<DeliveryTypeModel> {
    this.homeDelivery = new DeliveryTypeModel();
    this.homeDelivery.name = 'Home delivery';
    this.homeDelivery.id = 2;

    this.locationDelivery = new DeliveryTypeModel();
    this.locationDelivery.name = 'Location delivery';
    this.locationDelivery.id = 1;

    const deliveryArray = new Array<DeliveryTypeModel>();
    deliveryArray.push(this.homeDelivery);
    deliveryArray.push(this.locationDelivery);

    return deliveryArray;
  }
}
