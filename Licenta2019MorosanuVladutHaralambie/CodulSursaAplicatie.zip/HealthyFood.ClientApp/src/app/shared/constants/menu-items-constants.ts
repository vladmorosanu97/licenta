export default class MenuItems {
  public static home = '/home';
  public static search = '/search';
  public static trending = '/trending';
  public static addAdvertisement = '/add-advertisement';
  public static myAdvertisements = '/my-advertisements';
  public static messages = 'messages';
  public static advertisement = 'advertisement';
  public static editAdvertisement = 'edit-advertisement';
  public static people = 'people';
  public static settings = 'settings';
  public static myPresentation = '/my-presentation';
  public static peopleRequests = '/people-requests';
  public static myDeliveries = '/my-deliveries';
}
