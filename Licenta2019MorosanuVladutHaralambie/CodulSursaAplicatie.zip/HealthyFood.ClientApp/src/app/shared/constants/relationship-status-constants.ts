export default class RelationshipStatusConstants {
  public static request = 'request';
  public static friend = 'friend';
  public static block = 'block';
}
