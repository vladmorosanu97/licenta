import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-paginator',
  templateUrl: './paginator.component.html',
  styleUrls: ['./paginator.component.scss']
})
export class PaginatorComponent implements OnInit {
  pageSize = 10;
  @Input() pageNumber = 1;
  @Output() pageNumberEmitter = new EventEmitter<number>();
  @Input() totalPages = 1;
  constructor() {}

  ngOnInit() {}

  onPageChange(value) {
    this.pageNumber = value;
    this.pageNumberEmitter.emit(value);
    console.log(this.pageNumber);
  }
}
