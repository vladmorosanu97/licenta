import { Component, OnInit } from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';
import { authConfig } from './modules/authentication/auth.config';
import { Subject } from 'rxjs';
import { AuthService } from './services/auth.service';
import { HeaderService } from './services/header.service';
import { SignalrService } from './services/signalr.service';
import { debug } from 'util';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'HealthyFood';
  toggleMenu = true;
  isUserAuthenticated = false;
  constructor(
    private oauthService: OAuthService,
    private authService: AuthService,
    private headerService: HeaderService,
    private signalrService: SignalrService
  ) {}
  ngOnInit(): void {
    this.configureWithNewConfigApi();
    // this.authService.setLoggedIn();
    // this.authService.isLoggedIn.subscribe(x => {
    //   this.isUserLoggedIn = x;
    // });

    this.headerService.getToggleMenuObserver().subscribe(value => {
      this.toggleMenu = value;
    });

    this.isUserAuthenticated = this.authService.isAuthenticated();

    this.authService.loggedIn.subscribe(() => {
      this.isUserAuthenticated = this.authService.isAuthenticated();
      if (this.isUserAuthenticated) {
        this.signalrService
          .startConnection(this.authService.getAccessToken())
          .then(() => {
            this.signalrService.connectionObserver.next(true);
          })
          .catch(err => console.log('Error while starting connection: ' + err));
      } else {
        this.signalrService.stopConnection();
      }
    });

    this.headerService.getLogoutObserver().subscribe(value => {
      if (value === true) {
        this.isUserAuthenticated = false;
        this.signalrService.stopConnection();
      }
    });

    this.signalrService
      .startConnection(this.authService.getAccessToken())
      .then(() => {
        this.signalrService.connectionObserver.next(true);
      })
      .catch(err => console.log('Error while starting connection: ' + err));
  }
  private configureWithNewConfigApi() {
    this.oauthService.configure(authConfig);
    this.oauthService.setStorage(localStorage);
  }

  // loginCheck(value) {
  //   const isAuthorized = this.authService.isAuthorized();
  //   if (isAuthorized === false) {
  //     this.isUserLoggedIn = false;
  //     this.router.navigate(['login']);
  //   }
  // }
}
