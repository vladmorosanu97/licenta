import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  chatObserver: BehaviorSubject<number> = new BehaviorSubject(null);
  constructor() {}

  getChatObserver() {
    return this.chatObserver;
  }

  onSelectChat(item: number) {
    this.chatObserver.next(item);
  }
}
