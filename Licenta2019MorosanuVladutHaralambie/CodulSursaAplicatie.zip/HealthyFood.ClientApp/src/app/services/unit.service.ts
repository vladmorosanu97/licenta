import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import UnitTypeModel from '../shared/models/unit-type-model';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

const API_URL = `${environment.apiEndpoint}/units/unit-types`;
@Injectable({
  providedIn: 'root'
})
export class UnitService {
  private url: string;
  constructor(private http: HttpClient) {
    this.url = API_URL;
  }

  getUnitTypes(): Observable<Array<UnitTypeModel>> {
    return this.http.get(this.url) as Observable<Array<UnitTypeModel>>;
  }
}
