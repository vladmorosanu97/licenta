import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import UserCardModel from '../shared/models/user-card-model';
import RegisterUserModel from '../shared/models/register-user-model';
import ConfirmAccountModel from '../shared/models/confirm-account-model';
import SearchUsersModel from '../shared/models/search-users-model';
import UpdateUserModel from '../shared/models/update-user-model';
import ChangePasswordModel from '../shared/models/change-password-model';
import UserLocationsModel from '../shared/models/user-locations-model';
import UserSearchSuggestionModel from '../shared/models/user-search-suggestion-model';

const API_URL = `${environment.apiEndpoint}/accounts`;
@Injectable({
  providedIn: 'root'
})
export class UserService {
  private url: string;
  constructor(private http: HttpClient) {
    this.url = API_URL;
  }

  getFriends(
    searchUsersModel: SearchUsersModel
  ): Observable<Array<UserCardModel>> {
    return this.http.post(
      `${this.url}/friends`,
      searchUsersModel
    ) as Observable<Array<UserCardModel>>;
  }

  getUsers(
    searchUsersModel: SearchUsersModel
  ): Observable<Array<UserCardModel>> {
    return this.http.post(`${this.url}/users`, searchUsersModel) as Observable<
      Array<UserCardModel>
    >;
  }

  getFriendsRequests(): Observable<Array<UserCardModel>> {
    return this.http.get(`${this.url}/requests`) as Observable<
      Array<UserCardModel>
    >;
  }

  getUsersSearchSuggestions(
    text: string
  ): Observable<Array<UserSearchSuggestionModel>> {
    return this.http.get(
      `${this.url}/friends-search-suggestions?text=${text}`
    ) as Observable<Array<UserSearchSuggestionModel>>;
  }

  registerUser(user: RegisterUserModel): Observable<string> {
    return this.http.post(this.url, user) as Observable<string>;
  }

  changePassword(changePassword: ChangePasswordModel): Observable<boolean> {
    return this.http.put(this.url + '/password', changePassword) as Observable<
      boolean
    >;
  }

  updateUser(user: UpdateUserModel): Observable<string> {
    return this.http.put(this.url, user) as Observable<string>;
  }

  confirmAccount(
    confirmAccountModel: ConfirmAccountModel
  ): Observable<ConfirmAccountModel> {
    return this.http.post(
      this.url + '/confirm-account',
      confirmAccountModel
    ) as Observable<ConfirmAccountModel>;
  }

  validateEmail(email: string): Observable<string> {
    return this.http.get(
      `${this.url}/validate-email?email=${email}`
    ) as Observable<string>;
  }

  getSavedLocations(): Observable<UserLocationsModel> {
    return this.http.get(`${this.url}/locations`) as Observable<
      UserLocationsModel
    >;
  }

  updateSavedLocations(userLocations: UserLocationsModel): Observable<boolean> {
    return this.http.put(`${this.url}/locations`, userLocations) as Observable<
      boolean
    >;
  }
}
