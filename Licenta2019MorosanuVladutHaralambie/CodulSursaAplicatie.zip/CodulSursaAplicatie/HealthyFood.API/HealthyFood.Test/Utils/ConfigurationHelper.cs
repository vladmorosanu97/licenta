﻿using HealthyFood.Utils;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;


namespace HealthyFood.Tests.Utils
{
    public class ConfigurationHelper
    {
        public static IConfiguration GetIConfiguration()
        {
            return new ConfigurationBuilder()
                .AddJsonFile("appsettings.test.json", optional: false)
                .Build() as IConfiguration;
        }

        public static AppSettings GetApplicationConfiguration()
        {
            var collection = new ServiceCollection();

            var config = GetIConfiguration();

            collection.Configure<AppSettings>(config);

            var services = collection.BuildServiceProvider();

            return services.GetService<IOptions<AppSettings>>().Value;
        }
    }
}