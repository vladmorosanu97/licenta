﻿using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Hangfire;
using HealthyFood.BusinessLogic.Implementation.Hangfire;
using HealthyFood.BusinessLogic.Implementation.SignalR;
using HealthyFood.Ioc;
using HealthyFood.Utils;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;

namespace HealthyFood.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            
            services.RegisterServices(Configuration);
            services.AddCors(f => f.AddPolicy("AllowAllHeaders", c => c.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin()));

            services.AddAuthentication(options =>
                {
                    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                })
                .AddJwtBearer(cfg =>
                {
                    cfg.SaveToken = true;

                    cfg.TokenValidationParameters = new TokenValidationParameters()
                    {
                        ValidateIssuerSigningKey = true,
                        ValidateIssuer = true,
                        ValidIssuer = Configuration["Tokens:Issuer"],
                        ValidAudience = Configuration["Tokens:Audience"],
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Tokens:Key"]))
                    };

                    cfg.Events = new JwtBearerEvents
                    {
                        OnMessageReceived = context =>
                        {
                            var accessToken = context.Request.Query["access_token"];

                            // If the request is for our hub...
                            var path = context.HttpContext.Request.Path;
                            if (!string.IsNullOrEmpty(accessToken) &&
                                (path.StartsWithSegments("/messagesHub")))
                            {
                                // Read the token out of the query string
                                context.Token = accessToken;
                            }
                            return Task.CompletedTask;
                        }
                    };

                });

            services.AddAuthorization(options =>
            {
                options.AddPolicy(RoleConstants.Admin, policy => policy.RequireClaim(ClaimTypes.Role, RoleConstants.Admin));
                options.AddPolicy(RoleConstants.Client, policy => policy.RequireClaim(ClaimTypes.Role, RoleConstants.Client));
                options.AddPolicy(RoleConstants.Seller, policy => policy.RequireClaim(ClaimTypes.Role, RoleConstants.Seller));

                options.AddPolicy("seller-client", policy =>
                    policy.RequireAssertion(context =>
                        context.User.HasClaim(c =>
                            ((c.Type == ClaimTypes.Role && c.Value == RoleConstants.Seller) ||
                             (c.Type == ClaimTypes.Role && c.Value == RoleConstants.Client)))));
            });
         


            services.AddMvc();
            services.AddRouting();
            services.AddSignalR();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseHangfireDashboard("/hangfire", new DashboardOptions
            {
                Authorization = new[]
                {
                    new HangfireDashboardAuthorizationFilter()
                }
            });


            app.UseHangfireServer(new BackgroundJobServerOptions
            {
                WorkerCount = 1
            });



            GlobalJobFilters.Filters.Add(new AutomaticRetryAttribute()
            {
                Attempts = 0
            });
            HangfireJobScheduler.ScheduleRecurringJobs();

            app.UseCors("AllowAllHeaders");
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

         


            app.UseSignalR(routes =>
            {
                routes.MapHub<MessageHub>("/messagesHub");
            });

            app.UseStaticFiles();
            app.UseHttpsRedirection();
            app.UseDefaultFiles();
            app.UseAuthentication();

            
            app.UseMvc();


        }
    }
}