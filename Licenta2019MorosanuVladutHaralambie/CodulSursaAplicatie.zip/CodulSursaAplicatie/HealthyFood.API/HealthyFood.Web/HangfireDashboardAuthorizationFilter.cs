﻿using Hangfire.Dashboard;

namespace HealthyFood.Web
{
    public class HangfireDashboardAuthorizationFilter: IDashboardAuthorizationFilter
    {
        public bool Authorize(DashboardContext context)
        {
            return true;
        }
    }
}
