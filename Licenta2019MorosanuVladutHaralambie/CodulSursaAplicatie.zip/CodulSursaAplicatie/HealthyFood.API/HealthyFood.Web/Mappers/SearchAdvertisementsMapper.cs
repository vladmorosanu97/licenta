﻿using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Web.Models;

namespace HealthyFood.Web.Mappers
{
    public static class SearchAdvertisementsMapper
    {
        public static SearchAdvertisementsBlModel GetBlModel(this SearchAdvertisementsViewModel item)
        {
            return new SearchAdvertisementsBlModel
            {
               UserId = item.UserId,
               SearchText = item.SearchText,
               Longitude = item.Longitude,
               Latitude = item.Latitude,
               MaxDistance = item.MaxDistance,
               PageNumber = item.PageNumber,
               IsSearchByDistance = item.IsSearchByDistance
            };
        }
    }
}
