﻿using HealthyFood.BusinessLogic.Models.PrimitiveModels.Images;
using HealthyFood.Web.Models;

namespace HealthyFood.Web.Mappers
{
    public static class ImageMapper
    {
        public static ImageBlModel GetBlModel(this ImageViewModel item)
        {
            var blItem = new ImageBlModel
            {
                Base64 = item.Base64,
                ImageId = item.ImageId,
                Name = item.Name,
                ImagePath = item.ImagePath,
                GuidPathName = item.GuidPathName
            };
            return blItem;
        }
    }
}
