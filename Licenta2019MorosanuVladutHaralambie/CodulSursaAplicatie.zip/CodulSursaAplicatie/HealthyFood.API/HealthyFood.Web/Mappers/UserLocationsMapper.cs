﻿using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Web.ViewModels;

namespace HealthyFood.Web.Mappers
{
    public static class UserLocationsMapper
    {
        public static UserLocationsBlModel GetBlModel(this UserLocationsViewModel item)
        {
            return new UserLocationsBlModel()
            {
                HomeLatitude = item.HomeLatitude,
                HomeLocationName = item.HomeLocationName,
                Longitude = item.Longitude,
                LocationName = item.LocationName,
                Latitude = item.Latitude,
                HomeLongitude = item.HomeLongitude,
                AutomaticallyUpdateLocation = item.AutomaticallyUpdateLocation
            };
        }
    }
}
