﻿using System;
using System.Collections.Generic;

namespace HealthyFood.Web.ViewModels
{
    public class CreateLocationDeliveryViewModel
    {
        public byte DeliveryTypeId { get; set; }
        public DateTime Day { get; set; }
        public List<CreateLocationDeliveryPointViewModel> LocationDeliveryPoints { get; set; }
    }
}
