﻿using System;

namespace HealthyFood.Web.ViewModels
{
    public class CreateHomeDeliveryPointViewModel
    {
        public DateTime ArrivalTime { get; set; }
        public long UserId { get; set; }
        public string Description { get; set; }
    }
}
