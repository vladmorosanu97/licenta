﻿namespace HealthyFood.Web.ViewModels
{
    public class UserLocationsViewModel
    {
        public string LocationName { get; set; }
        public decimal Longitude { get; set; }
        public decimal Latitude { get; set; }
        public string HomeLocationName { get; set; }
        public decimal HomeLatitude { get; set; }
        public decimal HomeLongitude { get; set; }
        public bool AutomaticallyUpdateLocation { get; set; }
    }
}
