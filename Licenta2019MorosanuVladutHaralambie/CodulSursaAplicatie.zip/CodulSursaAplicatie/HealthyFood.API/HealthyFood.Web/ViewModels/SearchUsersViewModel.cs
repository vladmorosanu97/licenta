﻿namespace HealthyFood.Web.ViewModels
{
    public class SearchUsersViewModel
    {
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public string SearchText { get; set; }
    }
}