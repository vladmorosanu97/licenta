﻿namespace HealthyFood.Web.Models
{
    public class ImageViewModel
    {
        public long ImageId { get; set; }
        public string Name { get; set; }
        public string Base64 { get; set; }
        public string ImagePath { get; set; }
        public string GuidPathName { get; set; }
    }
}
