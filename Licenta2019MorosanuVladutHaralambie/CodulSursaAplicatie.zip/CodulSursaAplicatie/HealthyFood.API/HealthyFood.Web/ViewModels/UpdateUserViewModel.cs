﻿using HealthyFood.Web.Models;

namespace HealthyFood.Web.ViewModels
{
    public class UpdateUserViewModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public ImageViewModel Avatar { get; set; }
    }
}
