﻿namespace HealthyFood.Web.Models
{
    public class ConfirmAccountViewModel
    {
        public string Token { get; set; }
        public string UserRole { get; set; }
        public string LocationName { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
    }
}
