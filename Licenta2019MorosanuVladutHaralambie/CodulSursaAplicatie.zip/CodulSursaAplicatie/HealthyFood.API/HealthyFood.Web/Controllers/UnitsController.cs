﻿using System.Collections.Generic;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Models;
using Microsoft.AspNetCore.Mvc;

namespace HealthyFood.Web.Controllers
{
    public class UnitsController : BaseController
    {
        private readonly IUnitService _unitService;

        public UnitsController(IUnitService unitService)
        {
            _unitService = unitService;
        }
        [HttpGet("unit-types")]
        public IActionResult GetUnitTypes()
        {
            Result<List<UnitTypeBlModel>> unitTypesResult = _unitService.GetUnitTypes();
            if (unitTypesResult.IsFailure)
            {
                return BadRequest(unitTypesResult.Error);
            }
            return Ok(unitTypesResult.Value);
        }
    }
}