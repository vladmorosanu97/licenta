﻿using System.Linq;
using System.Security.Claims;
using HealthyFood.Utils;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace HealthyFood.Web.Controllers
{
    [Authorize]
    [ApiController]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [EnableCors(PolicyName = "AllowAllHeaders")]
    public abstract class BaseController : Controller
    {

        public UserClaims GetUserClaims()
        {
            UserClaims userClaims = new UserClaims();
            var userClaimsPrincipal = User.Claims;
            var claimsPrincipal = userClaimsPrincipal as Claim[] ?? userClaimsPrincipal.ToArray();
            userClaims.Role = claimsPrincipal.First(item => item.Type == ClaimTypes.Role).Value;
            userClaims.UserId = int.Parse(claimsPrincipal.First(item => item.Type == "userId").Value);
            userClaims.Email = claimsPrincipal.First(item => item.Type == ClaimTypes.Email).Value;
            userClaims.FirstName = claimsPrincipal.First(item => item.Type == "firstName").Value;
            userClaims.LastName = claimsPrincipal.First(item => item.Type == "lastName").Value;
            return userClaims;
        }
    }
}