﻿using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Models;
using HealthyFood.BusinessLogic.Models.PrimitiveModels.UserModels;
using HealthyFood.Data.Models.AdvertisementModels;
using HealthyFood.Web.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HealthyFood.Web.Controllers
{
    public class ReviewsController : BaseController
    {
        private readonly IReviewService _reviewService;
        private readonly IUserService _userService;

        public ReviewsController(IReviewService reviewService, IUserService userService)
        {
            _reviewService = reviewService;
            _userService = userService;
        }


        [Authorize(Policy = "seller-client")]
        [HttpGet("{userId}")]
        public IActionResult GetReviewsForUserId(long userId)
        {
            return Ok(_reviewService.GetReviewsForUserId(userId));
        }

        [Authorize(Policy = "seller-client")]
        [HttpPost]
        public IActionResult CreateReview(CreateReviewViewModel createReviewViewModel)
        {
            Result<Description> contentResult = Description.Create(createReviewViewModel.Content);
            Result<Mark> markResult = Mark.Create(createReviewViewModel.Mark);
            Result recipientIdResult = _userService.ValidateUserId(createReviewViewModel.RecipientId);

            Result result = Result.Combine(contentResult, markResult, recipientIdResult);
            if (result.IsFailure)
                return BadRequest(result.Error);

            var userId = GetUserClaims().UserId;
            var reviewBlModel = new ReviewBlModel();
            reviewBlModel.Mark = markResult.Value;
            reviewBlModel.Content = contentResult.Value;
            reviewBlModel.CreatorId = userId;
            reviewBlModel.RecipientId = createReviewViewModel.RecipientId;

            var createReviewResult = _reviewService.CreateReview(reviewBlModel);
            if (createReviewResult.IsFailure)
            {
                return BadRequest(createReviewResult.Error);
            }
            return Ok();
        }
    }
}