﻿using System.Collections.Generic;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Models;
using Microsoft.AspNetCore.Mvc;

namespace HealthyFood.Web.Controllers
{
    public class CategoriesController : BaseController
    {
        private readonly ICategoryService _categoryService;

        public CategoriesController(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }
        [HttpGet]
        public IActionResult GetCategories()
        {

            Result<List<CategoryBlModel>> categoryResult = _categoryService.GetCategories();
            if (categoryResult.IsFailure)
            {
                return BadRequest(categoryResult.Error);
            }

            return Ok(categoryResult.Value);
        }
    }
}