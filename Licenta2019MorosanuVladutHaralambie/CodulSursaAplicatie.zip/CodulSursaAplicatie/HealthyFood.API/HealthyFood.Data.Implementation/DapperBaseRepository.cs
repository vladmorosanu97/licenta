﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using Dapper;
using HealthyFood.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace HealthyFood.Data.Implementation
{
    public class DapperBaseRepository: IDapperBaseRepository
    {
        private readonly DatabaseContext _databaseContext;

        public DapperBaseRepository(DatabaseContext databaseContext)
        {
            _databaseContext = databaseContext;
        }
        public IEnumerable<T> QuerySync<T>(string sql, object param = null, CommandType commandType = CommandType.Text)
        {
            var connection = _databaseContext.Database.GetDbConnection();
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }

            return connection.Query<T>(sql, param, commandType: commandType);
        }

        public T QueryFirstOrDefaultSync<T>(string sql, object param = null, CommandType commandType = CommandType.Text)
        {
            var item = QuerySync<T>(sql, param, commandType: commandType);
            return item.FirstOrDefault();
        }

        public int ExecuteSync(string sql, object param = null)
        {
            var connection = _databaseContext.Database.GetDbConnection();
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }

            return connection.Execute(sql, param);
        }
    }
}
