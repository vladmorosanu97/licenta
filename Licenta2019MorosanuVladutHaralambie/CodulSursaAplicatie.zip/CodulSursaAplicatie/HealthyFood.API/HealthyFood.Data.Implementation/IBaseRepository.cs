﻿namespace HealthyFood.Data.Implementation
{
    interface IBaseRepository
    {
    }
}
