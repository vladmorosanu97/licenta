﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Models;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models.DapperModels;
using HealthyFood.Data.Models.Models;
using HealthyFood.Utils;
using Microsoft.EntityFrameworkCore;

namespace HealthyFood.Data.Implementation.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly DatabaseContext _databaseContext;
        private readonly IDapperBaseRepository _dapperBaseRepository;

        public UserRepository(DatabaseContext databaseContext, IDapperBaseRepository dapperBaseRepository)
        {
            _databaseContext = databaseContext;
            _dapperBaseRepository = dapperBaseRepository;
        }

        public Result CreateUser(User user)
        {
            _databaseContext.Users.Add(user);
            return SaveChanges();
        }

        public Result UpdateUser(User user)
        {
            var userToUpdate = _databaseContext.Users.FirstOrDefault(a => a.UserId == user.UserId);
            if (userToUpdate == null)
            {
                return Result.Fail("Unable to update user. Invalid user id");
            }

            userToUpdate.FirstName = user.FirstName;
            userToUpdate.LastName = user.LastName;
            userToUpdate.Email = user.Email;
            userToUpdate.PhoneNumber = user.PhoneNumber;
            userToUpdate.Modified = DateTime.Now;

            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result UpdatePassword(long userId, string password)
        {
            var passwordHash = SecurePasswordHasher.Hash(password);
            var user = _databaseContext.Users.FirstOrDefault(a => a.UserId == userId);
            if (user == null)
            {
                return Result.Fail("Invalid user id");
            }

            user.PasswordHash = passwordHash;
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result UpdateAvatar(User user)
        {
            var userToUpdate = _databaseContext.Users.FirstOrDefault(a => a.UserId == user.UserId);
            if (userToUpdate == null)
            {
                return Result.Fail("Unable to update user. Invalid user id");
            }

            userToUpdate.AvatarName = user.AvatarName;
            userToUpdate.GuidAvatarName = user.GuidAvatarName;
            userToUpdate.Modified = DateTime.Now;

            _databaseContext.SaveChanges();
            return Result.Ok();
        }


        public User GetUserById(long userId)
        {
            return _databaseContext.Users.FirstOrDefault(c => c.UserId == userId);
        }

        public Result<Maybe<User>> FindByEmail(string email)
        {
            var user = _databaseContext.Users.FirstOrDefault(a => a.Email.ToUpper() == email.ToUpper());
            return Result.Ok<Maybe<User>>(user);
        }

        public Result AddClaim(User user, Claim claim)
        {
            var userToUpdate = _databaseContext.Users.FirstOrDefault(a => a.Email == user.Email);
            if (userToUpdate == null)
            {
                return Result.Fail($"Invalid user with email {user.Email}");
            }

            var userClaim = new UserClaim {ClaimType = claim.Type, ClaimValue = claim.Value};
            userToUpdate.UserClaims.Add(userClaim);
            return SaveChanges();
        }

        public Result ValidateToken(string token)
        {
            var user = _databaseContext.Users.FirstOrDefault(u =>
                u.ActivationToken != null && u.ActivationToken == token);
            if (user == null)
            {
                return Result.Fail("This token is invalid");
            }

            if (user.EmailConfirmed)
            {
                return Result.Fail("Account already confirmed. You can close this tab");
            }

            return Result.Ok();
        }

        public Result<User> GetUserByToken(string token)
        {
            var user = _databaseContext.Users.FirstOrDefault(u => u.ActivationToken == token);
            if (user == null)
            {
                return Result.Fail<User>("This token is invalid");
            }

            return Result.Ok(user);
        }

        public Result ConfirmAccount(User user)
        {
            var userToUpdate = _databaseContext.Users.FirstOrDefault(u => u.ActivationToken == user.ActivationToken);
            if (userToUpdate == null)
            {
                return Result.Fail("User not found");
            }

            userToUpdate.LocationName = user.LocationName;
            userToUpdate.Longitude = user.Longitude;
            userToUpdate.Latitude = user.Latitude;
            userToUpdate.EmailConfirmed = true;
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result ValidateEmail(string email)
        {
            //            var result = _databaseContext.User.FirstOrDefault(a => a.NormalizedEmail != null && a.NormalizedEmail == email.ToUpper());

            var result = _databaseContext.Users.FirstOrDefault(u => u.Email.ToUpper() == email.ToUpper());
            if (result != null)
            {
                return Result.Fail("Email already exists");
            }

            return Result.Ok();
        }

        public Result ValidateUserId(long userId)
        {
            var user = _databaseContext.Users.FirstOrDefault(a => a.UserId == userId);
            if (user == null)
            {
                return Result.Fail("Invalid userId");
            }

            return Result.Ok();
        }

        public IEnumerable<UserCard> GetFriendsCards(long userId, decimal? latitude, decimal? longitude,
            string searchText)
        {
            var param = new
            {
                latitude,
                longitude,
                userId,
                searchText
            };
            var items = _dapperBaseRepository.QuerySync<UserCard>
                ("[dbo].[GetFriendsCards]", param, CommandType.StoredProcedure);
            return items;
        }

        public IEnumerable<UserCard> GetUsersCards(long userId, decimal? latitude, decimal? longitude, string searchText)
        {
            var param = new
            {
                latitude,
                longitude,
                userId,
                searchText
            };
            var items = _dapperBaseRepository.QuerySync<UserCard>
                ("[dbo].[GetUsersCards]", param, CommandType.StoredProcedure);
            return items;
        }

        public IEnumerable<UserCard> GetFriendsRequestsCards(long userId)
        {
            var param = new
            {
                userId,
            };
            var items = _dapperBaseRepository.QuerySync<UserCard>
                ("[dbo].[GetFriendsRequestsCards]", param, CommandType.StoredProcedure);
            return items;
        }

        public IEnumerable<UserSearchSuggestion> GetFriendsSearchSuggestions(string text, long userId)
        {
            var param = new
            {
                text,
                userId
            };
            var items = _dapperBaseRepository.QuerySync<UserSearchSuggestion>
                ("[dbo].[GetFriendsSearchSuggestions]", param, CommandType.StoredProcedure);
            return items;
        }


        public Result<UserClaim> GetUserClaimByUserId(long userId)
        {
            var userClaim = _databaseContext.UserClaims.FirstOrDefault(a => a.UserId == userId);
            if (userClaim == null)
            {
                return Result.Fail<UserClaim>("This user does not have any claims");
            }

            return Result.Ok(userClaim);
        }

        public Result<UserLocations> GetSavedLocations(long userId)
        {
            var user = _databaseContext.Users.FirstOrDefault(a => a.UserId == userId);
            if (user == null)
            {
                return Result.Fail<UserLocations>("Invalid userId");
            }

            var userLocations = new UserLocations()
            {
                LocationName = user.LocationName,
                Latitude = user.Latitude,
                Longitude = user.Longitude,
                HomeLocationName = user.HomeLocationName,
                HomeLatitude = user.HomeLatitude,
                AutomaticallyUpdateLocation =  user.AutomaticallyUpdateLocation,
                HomeLongitude = user.HomeLongitude
            };

            return Result.Ok(userLocations);
        }

        public Result UpdateSavedLocations(long userId, UserLocations userLocations)
        {
            var user = _databaseContext.Users.FirstOrDefault(a => a.UserId == userId);
            if (user == null)
            {
                return Result.Fail<UserLocations>("Invalid userId");
            }


            user.LocationName = userLocations.LocationName;
            user.Latitude = userLocations.Latitude;
            user.Longitude = userLocations.Longitude;

            user.HomeLocationName = userLocations.HomeLocationName;
            user.HomeLatitude = userLocations.HomeLatitude;
            user.HomeLongitude = userLocations.HomeLongitude;

            user.AutomaticallyUpdateLocation = userLocations.AutomaticallyUpdateLocation;
            _databaseContext.SaveChanges();

            return Result.Ok();
        }

        public Result CheckPassword(string email, string password)
        {
            var user = _databaseContext.Users.FirstOrDefault(a => a.Email.ToUpper() == email.ToUpper());
            if (user == null)
            {
                return Result.Fail("The password is incorrect");
            }

            if (!user.EmailConfirmed)
            {
                return Result.Fail("Invalid email or password");
            }

            var result = SecurePasswordHasher.Verify(password, user.PasswordHash);
            return result ? Result.Ok() : Result.Fail("Invalid email or password");
        }

        public Result CheckPassword(long userId, string password)
        {
            var user = _databaseContext.Users.FirstOrDefault(a => a.UserId == userId);
            if (user == null)
            {
                return Result.Fail("The password is incorrect");
            }

            if (!user.EmailConfirmed)
            {
                return Result.Fail("Email is not confirmed");
            }

            var result = SecurePasswordHasher.Verify(password, user.PasswordHash);
            return result ? Result.Ok() : Result.Fail("The password is incorrect");
        }

        public ICollection<UserClaim> GetUserClaims(User user)
        {
            return _databaseContext.Users.Include(u => u.UserClaims).FirstOrDefault(u => u.Email == user.Email)
                ?.UserClaims;
        }

        private Result SaveChanges()
        {
            try
            {
                var result = _databaseContext.SaveChanges();
                return result > 0 ? Result.Ok(SaveChangesEnum.Success) : Result.Fail("Not updated");
            }
            catch (DbUpdateException ex)
            {
                return Result.Fail(ex.Message);
            }
            catch (ArgumentException ex)
            {
                return Result.Fail(ex.Message);
            }
        }

        public void Dispose()
        {
            _databaseContext?.Dispose();
        }
    }
}