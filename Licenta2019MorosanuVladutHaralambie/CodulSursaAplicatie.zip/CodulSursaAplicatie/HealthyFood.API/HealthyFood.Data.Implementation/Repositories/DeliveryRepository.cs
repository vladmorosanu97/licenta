﻿using System.Collections.Generic;
using System.Linq;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace HealthyFood.Data.Implementation.Repositories
{
    public class DeliveryRepository: IDeliveryRepository
    {
        private readonly DatabaseContext _databaseContext;

        public DeliveryRepository(DatabaseContext databaseContext)
        {
            _databaseContext = databaseContext;
        }
        public Result ValidateDeliveryTypeId(int deliveryTypeId)
        {
            var deliveryType = _databaseContext.DeliveryTypes.FirstOrDefault(a => a.DeliveryTypeId == deliveryTypeId);
            if (deliveryType == null)
            {
                return Result.Fail("Invalid delivery type id");
            }
            return Result.Ok();
        }

        public Result<long> CreateDelivery(Delivery delivery)
        {
            if (delivery == null)
            {
                return Result.Fail<long>("Delivery should not be null");
            }

            _databaseContext.Deliveries.Add(delivery);
            _databaseContext.SaveChanges();
            return Result.Ok(delivery.DeliveryId);
        }

        public Result<long> CreateLocationDeliveryPoint(LocationDeliveryPoint locationDeliveryPoint)
        {
            var delivery = _databaseContext.Deliveries.FirstOrDefault(a => a.DeliveryId == locationDeliveryPoint.DeliveryId);
            if (delivery == null)
            {
                return Result.Fail<long>("Invalid delivery Id");
            }


            _databaseContext.LocationDeliveryPoints.Add(locationDeliveryPoint);
            _databaseContext.SaveChanges();
            return Result.Ok(locationDeliveryPoint.LocationDeliveryPointId);
        }

        public Result CreateHomeDeliveryPoint(HomeDeliveryPoint homeDeliveryPoint)
        {
            var delivery = _databaseContext.Deliveries.FirstOrDefault(a => a.DeliveryId == homeDeliveryPoint.DeliveryId);
            if (delivery == null)
            {
                return Result.Fail<long>("Invalid delivery Id");
            }


            _databaseContext.HomeDeliveryPoints.Add(homeDeliveryPoint);
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result CreateLocationDeliveryPointsUsers(List<LocationDeliveryPointsUser> deliveryPointsUsers)
        {
            _databaseContext.LocationDeliveryPointsUsers.AddRange(deliveryPointsUsers);
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result<List<Delivery>> GetLocationDeliveries(long userId)
        {
            var deliveries = _databaseContext.Deliveries.Include(a => a.LocationDeliveryPoints)
                .ThenInclude(a => a.LocationDeliveryPointsUsers).Include(a=> a.Author).Where(a => a.AuthorId != userId && a.DeliveryTypeId == 1);

            var newDeliveries = new List<Delivery>();
            foreach (var delivery in deliveries)
            {
                var copyDev = delivery;

                copyDev.LocationDeliveryPoints = delivery.LocationDeliveryPoints.Where(a =>
                    a.IsForAllFriends ||
                    a.LocationDeliveryPointsUsers.Where(u => u.UserId == userId).ToList().Count > 0).ToList();
                if (copyDev.LocationDeliveryPoints.Count > 0)
                {
                    newDeliveries.Add(copyDev);
                }
               
            }

            return Result.Ok(newDeliveries);

        }

        public Result<List<Delivery>> GetHomeDeliveries(long userId)
        {
            var deliveries = _databaseContext.Deliveries.Include(a => a.HomeDeliveryPoints).ThenInclude(a => a.User)
                .Include(a => a.Author).Where(a => a.AuthorId != userId && a.DeliveryTypeId == 2);

            var newDeliveries = new List<Delivery>();
            foreach (var delivery in deliveries)
            {
                var copyDev = delivery;

                copyDev.HomeDeliveryPoints = delivery.HomeDeliveryPoints.Where(a =>
                    a.UserId == userId).ToList();
                if (copyDev.HomeDeliveryPoints.Count > 0)
                {
                    newDeliveries.Add(copyDev);
                }

            }

            return Result.Ok(newDeliveries);
        }

        public Result<List<Delivery>> GetUserLocationDeliveries(long userId)
        {
            var deliveries = _databaseContext.Deliveries.Include(a => a.LocationDeliveryPoints)
                .ThenInclude(a => a.LocationDeliveryPointsUsers).ThenInclude(a => a.User).Include(a => a.Author).Where(a => a.AuthorId == userId && a.DeliveryTypeId == 1).ToList();

            return Result.Ok(deliveries);
        }

        public Result<List<Delivery>> GetUserHomeDeliveries(long userId)
        {
            var deliveries = _databaseContext.Deliveries.Include(a => a.HomeDeliveryPoints).ThenInclude(a => a.User)
                .Include(a => a.Author).Where(a => a.AuthorId == userId && a.DeliveryTypeId == 2).ToList();

            return Result.Ok(deliveries);
        }
    }
}
