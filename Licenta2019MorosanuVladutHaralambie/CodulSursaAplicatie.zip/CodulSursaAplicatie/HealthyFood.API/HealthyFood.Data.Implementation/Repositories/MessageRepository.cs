﻿using System;
using System.Collections.Generic;
using System.Linq;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace HealthyFood.Data.Implementation.Repositories
{
    public class MessageRepository : IMessageRepository
    {
        private readonly DatabaseContext _databaseContext;

        public MessageRepository(DatabaseContext databaseContext)
        {
            _databaseContext = databaseContext;
        }

        public Result<List<ChatCard>> GetChatsForUserId(long userId)
        {
            var chats = _databaseContext.ChatUsers.Include(a => a.Chat).Where(a => a.UserId == userId)
                .Select(a => a.Chat).ToList();
            var chatCards = new List<ChatCard>();
            foreach (var chat in chats)
            {
                var chatCopy = _databaseContext.Chats.Include(a => a.ChatUsers)
                    .ThenInclude(a => a.User).ThenInclude(a => a.UserConnections)
                    .FirstOrDefault(a => a.ChatId == chat.ChatId);
                if (chatCopy == null)
                {
                    return Result.Fail<List<ChatCard>>("No chats");
                }

                var partnerId = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User.UserId;
                var chatCard = new ChatCard
                {
                    ChatId = chatCopy.ChatId,
                    Name = chatCopy.Name,
                    PartnerId = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User.UserId ?? 0,
                    PartnerFirstName = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User.FirstName,
                    PartnerLastName = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User.LastName,
                    MessagesCount = _databaseContext.Messages.Count(a =>
                        a.ChatId == chat.ChatId && a.Seen == false && a.AuthorId != userId),
                    IsOnline = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User.UserConnections
                                   .FirstOrDefault(a => a.UserId == partnerId)?.IsOnline ?? false,
                    TotalMessages = _databaseContext.Messages.Count(a => a.ChatId == chatCopy.ChatId),
                    LastTimeOnline = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User.UserConnections
                                   .FirstOrDefault(a => a.UserId == partnerId)?.Modified,
                };
                if (chatCard.TotalMessages > 0)
                {
                    chatCards.Add(chatCard);
                }
            }

            return Result.Ok(chatCards);
        }

        public Result<User> GetSecondUserForChat(long chatId, long userId)
        {
            var user = _databaseContext.ChatUsers
                .Include(a => a.User)
                .Where(a => a.ChatId == chatId)
                .Select(a => a.User)
                .ToList()
                .FirstOrDefault(a => a.UserId != userId);
            if (user == null)
            {
                return Result.Fail<User>("Cannot find another user in this chat");
            }

            return Result.Ok(user);
        }

        public Result<ChatCard> GetChatByUsersIds(long userId, long partnerId)
        {
            var chats = _databaseContext.Chats
                .Include(a => a.ChatUsers);
            foreach (var chat in chats)
            {
                var users = chat.ChatUsers.Select(a => a.UserId);
                if (chat.ChatUsers.Select(a => a.UserId).Contains(userId) &&
                    chat.ChatUsers.Select(a => a.UserId).Contains(partnerId))
                {
                    var chatCopy = _databaseContext.Chats.Include(a => a.ChatUsers)
                        .ThenInclude(a => a.User).FirstOrDefault(a => a.ChatId == chat.ChatId);

                    if (chatCopy == null)
                    {
                        return Result.Fail<ChatCard>("Chat id invalid");
                    }

                    var chatCard = new ChatCard()
                    {
                        ChatId = chatCopy.ChatId,
                        Name = chatCopy.Name,
                        PartnerId = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User.UserId ?? 0,
                        PartnerFirstName = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User.FirstName,
                        PartnerLastName = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User.LastName,
                        PartnerEmail = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User.Email,
                        Longitude = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User.Longitude,
                        Latitude = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User.Latitude,
                        LocationName = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User.LocationName,
                    };


                    return Result.Ok(chatCard);
                }
            }

            return Result.Fail<ChatCard>("No chat found");
        }

        public Result ValidateChatId(long chatId)
        {
            var chat = _databaseContext.Chats.FirstOrDefault(a => a.ChatId == chatId);
            if (chat == null)
            {
                return Result.Fail("Invalid chatId");
            }

            return Result.Ok();
        }

        public Result CreateMessage(Message message)
        {
            _databaseContext.Messages.Add(message);
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result<long> CreateChat(Chat chat)
        {
            _databaseContext.Chats.Add(chat);
            _databaseContext.SaveChanges();
            return Result.Ok(chat.ChatId);
        }

        public Result AddUserToChat(ChatUser chatUser)
        {
            _databaseContext.ChatUsers.Add(chatUser);
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result<List<Message>> GetMessages(long chatId)
        {
            var messages = _databaseContext.Messages
                .Include(a => a.Author)
                .Where(a => a.ChatId == chatId)
                .OrderByDescending(a => a.Created)
                .Take(50).OrderBy(a => a.Created).ToList();
            return Result.Ok(messages);
        }

        public Result AddUserConnection(UserConnection userConnection)
        {
            var userConnectionToUpdate =
                _databaseContext.UserConnections.FirstOrDefault(a => a.UserId == userConnection.UserId);
            if (userConnectionToUpdate != null)
            {
                userConnectionToUpdate.ConnectionId = userConnection.ConnectionId;
                userConnectionToUpdate.IsOnline = userConnection.IsOnline;
                userConnectionToUpdate.Modified = DateTime.Now;
            }
            else
            {
                _databaseContext.UserConnections.Add(userConnection);
            }

            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result UpdateUserConnectionOffline(string connectionId)
        {
            var connection = _databaseContext.UserConnections.FirstOrDefault(a => a.ConnectionId == connectionId);
            if (connection == null)
            {
                return Result.Fail("Connection Id not found");
            }

            connection.IsOnline = false;
            connection.Modified = DateTime.Now;
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result<string> GetUserConnection(long userId)
        {
            return Result.Ok(_databaseContext.UserConnections.FirstOrDefault(a => a.UserId == userId)?.ConnectionId);
        }

        public Result UpdateSeenMessages(long userId, long chatId)
        {
            var messages = _databaseContext.Messages.Where(a => a.AuthorId != userId && a.ChatId == chatId);
            foreach (var message in messages)
            {
                message.Seen = true;
            }

            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result<long> GetUserIdByConnectionId(string connectionId)
        {
            var userConnection = _databaseContext.UserConnections.FirstOrDefault(a => a.ConnectionId == connectionId);
            if (userConnection == null)
            {
                return Result.Fail<long>("Invalid connectionId");
            }

            return Result.Ok(userConnection.UserId);
        }

        public Result<List<string>> GetUsersPartners(long userId)
        {
            var chats = _databaseContext.ChatUsers.Include(a => a.Chat).Where(a => a.UserId == userId)
                .Select(a => a.Chat);

            List<string> userConnections = new List<string>();
            foreach (var chat in chats)
            {
                var chatCopy = _databaseContext.Chats.Include(a => a.ChatUsers)
                    .ThenInclude(a => a.User).ThenInclude(a => a.UserConnections)
                    .FirstOrDefault(a => a.ChatId == chat.ChatId);
                if (chatCopy == null)
                {
                    return Result.Fail<List<string>>("No chats");
                }


                var user = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User;
                if (user != null && user.UserConnections.FirstOrDefault(a => a.UserId == user.UserId)?.IsOnline == true)
                {
                    userConnections.Add(user.UserConnections.FirstOrDefault(a => a.UserId == user.UserId)
                        ?.ConnectionId);
                }
            }

            return Result.Ok<List<string>>(userConnections);
        }

        public Result ValidateChatIdByUserId(long chatId, long userId)
        {
            var chat = _databaseContext.ChatUsers.FirstOrDefault(a => a.ChatId == chatId && a.UserId == userId);
            if (chat == null)
            {
                return Result.Fail("User does not have the rights to view messages for chat id: " + chatId.ToString());
            }

            return Result.Ok();
        }

        public Result<long> GetUserPartner(long userId, long chatId)
        {
            var chat = _databaseContext.ChatUsers.Include(a => a.Chat)
                .FirstOrDefault(a => a.UserId == userId && a.ChatId == chatId)?.Chat;

            if (chat == null)
            {
                return Result.Fail<long>("Invalid chatId or userId");
            }

            var chatCopy = _databaseContext.Chats.Include(a => a.ChatUsers)
                .ThenInclude(a => a.User).ThenInclude(a => a.UserConnections)
                .FirstOrDefault(a => a.ChatId == chat.ChatId);
            if (chatCopy == null)
            {
                return Result.Fail<long>("No chats");
            }

            var user = chatCopy.ChatUsers.FirstOrDefault(a => a.UserId != userId)?.User;
            if (user != null && user.UserConnections.FirstOrDefault(a => a.UserId == user.UserId)?.IsOnline == true)
            {
                var partnerId = user.UserConnections.FirstOrDefault(a => a.UserId == user.UserId)?.UserId;
                if (partnerId != null)
                {
                    return Result.Ok(partnerId.Value);
                }
            }

            return Result.Fail<long>("User null or user is not online");
        }

        public Result<string> GetChatNameByChatId(long chatId)
        {
            var chat = _databaseContext.Chats.FirstOrDefault(a => a.ChatId == chatId);
            if (chat == null)
            {
                return Result.Fail<string>("Invalid chatId");
            }

            return Result.Ok(chat.Name);
        }
    }
}