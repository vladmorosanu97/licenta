﻿using System.Linq;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;
using HealthyFood.Utils;

namespace HealthyFood.Data.Implementation.Repositories
{
    public class RelationshipRepository : IRelationshipRepository
    {
        private readonly DatabaseContext _databaseContext;

        public RelationshipRepository(DatabaseContext databaseContext)
        {
            _databaseContext = databaseContext;
        }

        public Result SendFriendRequest(long userId, long receiverId)
        {
            var friendRequest = _databaseContext.Relationships.FirstOrDefault(a =>
                (a.RelatingUserId == userId && a.RelatedUserId == receiverId) ||
                (a.RelatingUserId == receiverId && a.RelatedUserId == userId));
            if (friendRequest != null)
            {
                return Result.Fail("Already friends");
            }

            var relationship = new Relationship()
            {
                RelatingUserId = userId,
                RelatedUserId = receiverId,
                Type = RelationshipStatusConstants.Request
            };

            _databaseContext.Relationships.Add(relationship);
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result CancelFriendRequest(long userId, long receiverId)
        {
            var friendRequest = _databaseContext.Relationships.FirstOrDefault(a =>
                a.RelatingUserId == userId && a.RelatedUserId == receiverId);
            if (friendRequest == null)
            {
                return Result.Fail("Friend request not found");
            }

            if (friendRequest.Type != RelationshipStatusConstants.Request)
            {
                return Result.Fail("Already friends");
            }


            _databaseContext.Relationships.Remove(friendRequest);
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result AcceptFriendRequest(long userId, long senderId)
        {
            var friendRequest = _databaseContext.Relationships.FirstOrDefault(a =>
                a.RelatingUserId == senderId && a.RelatedUserId == userId);
            if (friendRequest == null)
            {
                return Result.Fail("Friend request not found");
            }

            if (friendRequest.Type != RelationshipStatusConstants.Request)
            {
                return Result.Fail("Other status than a request");
            }


            friendRequest.Type = RelationshipStatusConstants.Friend;
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result RemoveFriendRequest(long userId, long senderId)
        {
            var friendRequest = _databaseContext.Relationships.FirstOrDefault(a =>
                a.RelatingUserId == senderId && a.RelatedUserId == userId);
            if (friendRequest == null)
            {
                return Result.Fail("Friend relationship not found");
            }

            if (friendRequest.Type != RelationshipStatusConstants.Request)
            {
                return Result.Fail("Other status than a friend request");
            }

            _databaseContext.Relationships.Remove(friendRequest);
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result RemoveFriend(long userId, long receiverId)
        {
            var friendRequest = _databaseContext.Relationships.FirstOrDefault(a =>
                (a.RelatingUserId == userId && a.RelatedUserId == receiverId) ||
                (a.RelatingUserId == receiverId && a.RelatedUserId == userId));
            if (friendRequest == null)
            {
                return Result.Fail("Friend relationship not found");
            }

            if (friendRequest.Type != RelationshipStatusConstants.Friend)
            {
                return Result.Fail("Other status than a friend relationship");
            }

            _databaseContext.Relationships.Remove(friendRequest);
            _databaseContext.SaveChanges();
            return Result.Ok();
        }
    }
}