﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;

namespace HealthyFood.Data.Implementation.Repositories
{
    public class SearchRepository : ISearchRepository
    {
        private readonly DatabaseContext _databaseContext;

        public SearchRepository(DatabaseContext databaseContext)
        {
            _databaseContext = databaseContext;
        }

        public List<SearchSuggestion> GetAllSearchSuggestions()
        {
            return _databaseContext.SearchSuggestions.ToList();
        }

        public Result<List<long>> GetViewsCountLastSevenDays(long searchSuggestionId)
        {
            var searchSuggestion =
                _databaseContext.SearchSuggestions.FirstOrDefault(a => a.SearchSuggestionId == searchSuggestionId);
            if (searchSuggestion == null)
            {
                return Result.Fail<List<long>>("Invalid searchSuggestionId");
            }

            DateTime[] last7Days = Enumerable.Range(1, 7)
                .Select(i => DateTime.Now.Date.AddDays(-i))
                .ToArray()
                .OrderBy(a => a).ToArray();

            var lastDaysViews = new List<long>();
            foreach (var day in last7Days)
            {
                var viewsCount = _databaseContext.SearchHistory.Count(a =>
                    a.Created.Value.Date == day.Date && a.SearchSuggestionId == searchSuggestionId);
                lastDaysViews.Add(viewsCount);
            }

            return Result.Ok(lastDaysViews);
        }

        public Result<long> GetViewsCountToday(long searchSuggestionId)
        {
            var searchSuggestion =
                _databaseContext.SearchSuggestions.FirstOrDefault(a => a.SearchSuggestionId == searchSuggestionId);
            if (searchSuggestion == null)
            {
                return Result.Fail<long>("Invalid searchSuggestionId");
            }

            return Result.Ok<long>(
                _databaseContext.SearchHistory.Count(a =>
                    a.Created.Value.Date == DateTime.Now.Date && a.SearchSuggestionId == searchSuggestionId));
        }

        public async Task<Result> UpdateSearchSuggestionTrending(SearchSuggestionTrending searchSuggestionTrending)
        {
            var searchSuggestionTrendingToUpdate =
                _databaseContext.SearchSuggestionTrending.FirstOrDefault(a =>
                    a.SearchSuggestionId == searchSuggestionTrending.SearchSuggestionId);
            if (searchSuggestionTrendingToUpdate == null)
            {
                _databaseContext.SearchSuggestionTrending.Add(searchSuggestionTrending);
            }
            else
            {
                searchSuggestionTrendingToUpdate.TrendingValue = searchSuggestionTrending.TrendingValue;
                searchSuggestionTrendingToUpdate.Modified = DateTime.Now;
            }

            await _databaseContext.SaveChangesAsync();
            return Result.Ok();
        }
    }
}