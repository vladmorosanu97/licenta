﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;
using HealthyFood.Data.Models.DapperModels;
using Microsoft.EntityFrameworkCore;
using SearchSuggestionDapper = HealthyFood.Data.Models.DapperModels.SearchSuggestionDapper;

namespace HealthyFood.Data.Implementation.Repositories
{
    public class AdvertisementRepository : IAdvertisementRepository
    {
        private readonly DatabaseContext _databaseContext;
        private readonly IDapperBaseRepository _dapperBaseRepository;

        public AdvertisementRepository(DatabaseContext databaseContext, IDapperBaseRepository dapperBaseRepository)
        {
            _databaseContext = databaseContext;
            _dapperBaseRepository = dapperBaseRepository;
        }

        public Result<long> CreateAdvertisement(Advertisement advertisement)
        {
            _databaseContext.Advertisements.Add(advertisement);
            _databaseContext.SaveChanges();
            return Result.Ok(advertisement.AdvertisementId);
        }

        public Result UpdateAdvertisement(Advertisement advertisement)
        {
            var advertisementToUpdate =
                _databaseContext.Advertisements.FirstOrDefault(a => a.AdvertisementId == advertisement.AdvertisementId);
            if (advertisementToUpdate == null)
            {
                return Result.Fail("Invalid advertisement id");
            }

            advertisementToUpdate.Description = advertisement.Description;
            advertisementToUpdate.CategoryId = advertisement.CategoryId;
            advertisementToUpdate.CreatedById = advertisement.CreatedById;
            advertisementToUpdate.DeactivationReason = advertisement.DeactivationReason;
            advertisementToUpdate.DeletedById = advertisement.DeletedById;
            advertisementToUpdate.HomeDelivery = advertisement.HomeDelivery;
            advertisementToUpdate.IsDeleted = advertisement.IsDeleted;
            advertisementToUpdate.IsDisabled = advertisement.IsDisabled;
            advertisementToUpdate.Latitude = advertisement.Latitude;
            advertisementToUpdate.Longitude = advertisement.Longitude;
            advertisementToUpdate.LocationName = advertisement.LocationName;
            advertisementToUpdate.PhoneNumber = advertisement.PhoneNumber;
            advertisementToUpdate.Price = advertisement.Price;
            advertisementToUpdate.UnitTypeId = advertisement.UnitTypeId;
            advertisementToUpdate.Title = advertisement.Title;

            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result AddAdvertisementImages(List<AdvertisementImage> advertisementImages)
        {
            var advertisementId = advertisementImages.FirstOrDefault()?.AdvertisementId;
            if (advertisementId == null)
            {
                return Result.Fail("Unable to save photos because advertisementId is empty");
            }

            var images = _databaseContext.AdvertisementImages.Where(a =>
                a.AdvertisementId == advertisementId).ToList();
            _databaseContext.AdvertisementImages.RemoveRange(images);
            _databaseContext.SaveChanges();
            foreach (var advertisementImage in advertisementImages)
            {
                _databaseContext.AdvertisementImages.Add(advertisementImage);
                _databaseContext.SaveChanges();
            }

            return Result.Ok();
        }


        public IEnumerable<AdvertisementCard> GetAdvertisementsCards(decimal? latitude, decimal? longitude,
            int distance, int pageNumber, long userId, string searchText)
        {
            var param = new
            {
                latitude,
                longitude,
                distance,
                pageNumber,
                userId,
                searchText
            };
            var items = _dapperBaseRepository.QuerySync<AdvertisementCard>
                ("[dbo].[GetAdvertisementsCards]", param, CommandType.StoredProcedure);
            return items;
        }

        public IEnumerable<AdvertisementCard> GetUserAdvertisementsCards(decimal? latitude, decimal? longitude,
            long userId)
        {
            var param = new
            {
                latitude,
                longitude,
                userId,
            };
            var items = _dapperBaseRepository.QuerySync<AdvertisementCard>
                ("[dbo].[GetUserAdvertisementsCards]", param, CommandType.StoredProcedure);
            return items;
        }

        public IEnumerable<SearchSuggestionDapper> GetSearchSuggestions(string text, long userId)
        {
            var param = new
            {
                text,
                userId
            };
            var items = _dapperBaseRepository.QuerySync<SearchSuggestionDapper>
                ("[dbo].[GetAdvertisementsSearchSuggestions]", param, CommandType.StoredProcedure);
            return items;
        }

        public Result<long> CreateSearchSuggestion(SearchSuggestion searchSuggestion)
        {
            _databaseContext.SearchSuggestions.Add(searchSuggestion);
            _databaseContext.SaveChanges();
            return Result.Ok(searchSuggestion.SearchSuggestionId);
        }

        public Result CountSearchSuggestion(long searchSuggestionId)
        {
            var searchSuggestion =
                _databaseContext.SearchSuggestions.FirstOrDefault(a => a.SearchSuggestionId == searchSuggestionId);
            if (searchSuggestion == null)
            {
                return Result.Fail("Invalid suggestion id");
            }

            searchSuggestion.Count++;
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result CreateSearchHistory(SearchHistory searchHistory)
        {
            _databaseContext.SearchHistory.Add(searchHistory);
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result<long> GetSearchSuggestionIdByText(string searchSuggestionText)
        {
            var searchSuggestion =
                _databaseContext.SearchSuggestions.FirstOrDefault(a => a.Text == searchSuggestionText);
            if (searchSuggestion == null)
            {
                return Result.Fail<long>("Invalid suggestion id");
            }

            return Result.Ok(searchSuggestion.SearchSuggestionId);
        }

        public Result<Advertisement> GetAdvertisementById(long advertisementId)
        {
            var advertisement =
                _databaseContext.Advertisements
                    .Include(a => a.AdvertisementImages)
                    .Include(a => a.CreatedBy)
                    .ThenInclude(a => a.ReviewsRecipient)
                    .Include(a => a.UnitType)
                    .Include(a => a.Category)
                    .FirstOrDefault(a => a.AdvertisementId == advertisementId);
            if (advertisement == null)
            {
                return Result.Fail<Advertisement>("Advertisement id is invalid");
            }

            return Result.Ok(advertisement);
        }

        public Result DeleteAdvertisementById(long advertisementId)
        {
            var advertisement =
                _databaseContext.Advertisements.FirstOrDefault(a => a.AdvertisementId == advertisementId);
            if (advertisement == null)
            {
                return Result.Fail("Advertisement not found");
            }

            var advertisementImages =
                _databaseContext.AdvertisementImages.Where(a => a.AdvertisementId == advertisementId);
            _databaseContext.AdvertisementImages.RemoveRange(advertisementImages);
            _databaseContext.SaveChanges();


            _databaseContext.Advertisements.Remove(advertisement);
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result AddAdvertisementHistory(AdvertisementHistory advertisementHistory)
        {
            _databaseContext.AdvertisementsHistory.Add(advertisementHistory);
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public List<Advertisement> GetAllAdvertisements()
        {
            return _databaseContext.Advertisements.ToList();
        }

        public Result<List<long>> GetViewsCountLastSevenDays(long advertisementId)
        {
            var advertisement =
                _databaseContext.Advertisements.FirstOrDefault(a => a.AdvertisementId == advertisementId);
            if (advertisement == null)
            {
                return Result.Fail<List<long>>("Invalid advertisementId");
            }

            DateTime[] last7Days = Enumerable.Range(1, 7)
                .Select(i => DateTime.Now.Date.AddDays(-i))
                .ToArray()
                .OrderBy(a => a).ToArray();

            var lastDaysViews = new List<long>();
            foreach (var day in last7Days)
            {
                var viewsCount = _databaseContext.AdvertisementsHistory.Count(a =>
                    a.Created.Value.Date == day.Date && a.AdvertisementId == advertisementId);
                lastDaysViews.Add(viewsCount);
            }

            return Result.Ok(lastDaysViews);
        }

        public Result<long> GetViewsCountToday(long advertisementId)
        {
            var advertisement =
                _databaseContext.Advertisements.FirstOrDefault(a => a.AdvertisementId == advertisementId);
            if (advertisement == null)
            {
                return Result.Fail<long>("Invalid advertisementId");
            }

            return Result.Ok<long>(
                _databaseContext.AdvertisementsHistory.Count(a =>
                    a.Created.Value.Date == DateTime.Now.Date && a.AdvertisementId == advertisementId));
        }

        public async Task<Result> UpdateTrendingValue(AdvertisementTrending advertisementTrending)
        {
            var advertisementTrendingToUpdate =
                _databaseContext.AdvertisementsTrending.FirstOrDefault(a =>
                    a.AdvertisementId == advertisementTrending.AdvertisementId);
            if (advertisementTrendingToUpdate == null)
            {
                _databaseContext.AdvertisementsTrending.Add(advertisementTrending);
            }
            else
            {
                advertisementTrendingToUpdate.TrendingValue = advertisementTrending.TrendingValue;
                advertisementTrendingToUpdate.Modified = DateTime.Now;
            }

            await _databaseContext.SaveChangesAsync();
            return Result.Ok();
        }

        public IEnumerable<AdvertisementCard> GetTrendingAdvertisements(decimal? latitude, decimal? longitude, int distance, long userId)
        {
            var param = new
            {
                latitude, 
                longitude,
                distance,
                userId
            };
            var items = _dapperBaseRepository.QuerySync<AdvertisementCard>
                ("[dbo].[GetTrendingAdvertisementsCards]", param, CommandType.StoredProcedure);
            return items;
        }
    }
}