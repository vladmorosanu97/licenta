﻿using System.Collections.Generic;
using System.Linq;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;

namespace HealthyFood.Data.Implementation.Repositories
{
    public class CategoryRepository: ICategoryRepository
    {
        private readonly DatabaseContext _databaseContext;

        public CategoryRepository(DatabaseContext databaseContext)
        {
            _databaseContext = databaseContext;
        }
        public Result<List<Category>> GetCategories()
        {
            return Result.Ok(_databaseContext.Categories.ToList());
        }

        public Result ValidateCategory(int categoryId)
        {
            var result = _databaseContext.Categories.FirstOrDefault(a => a.CategoryId == categoryId);
            if (result == null)
            {
                return Result.Fail("Invalid category id");
            }
            return Result.Ok();
        }
    }
}
