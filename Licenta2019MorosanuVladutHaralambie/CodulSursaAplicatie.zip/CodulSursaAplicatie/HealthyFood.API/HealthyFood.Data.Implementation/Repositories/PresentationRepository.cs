﻿using System;
using System.Linq;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;
using HealthyFood.Utils;
using Microsoft.EntityFrameworkCore;

namespace HealthyFood.Data.Implementation.Repositories
{
    public class PresentationRepository : IPresentationRepository
    {
        private readonly DatabaseContext _databaseContext;

        public PresentationRepository(DatabaseContext databaseContext)
        {
            _databaseContext = databaseContext;
        }

        public Result<UserPresentation> GetSellerPresentation(long userId, long authenticatedUserId)
        {
            var user = _databaseContext.Users
                .Include(a => a.UserClaims)
                .Include(a => a.AdvertisementsCreatedBy)
                .Include(a => a.SellerPresentations)
                .Include(a => a.ReviewsRecipient)
                .FirstOrDefault(a => a.UserId == userId);
            if (user == null)
            {
                return Result.Fail<UserPresentation>("User with current id not found");
            }

            if (user.UserClaims?.FirstOrDefault(a => a.UserId == userId)?.ClaimValue != RoleConstants.Seller)
            {
                return Result.Fail<UserPresentation>("This user is not a seller");
            }

            var sellerPresentation = new UserPresentation
            {
                Role = user.UserClaims?.FirstOrDefault(a => a.UserId == user.UserId)?.ClaimValue,
                AdvertisementsCount = user.AdvertisementsCreatedBy.Count,
                Description = user.SellerPresentations?.FirstOrDefault(a => a.UserId == userId)?.Description,
                FirstName = user.FirstName,
                LastName = user.LastName,
                FollowersCount = 10,
                LocationName = user.LocationName,
                RegisterDate = user.Created,
                UserId = user.UserId,
                BannerPath = user.SellerPresentations?.FirstOrDefault(a => a.UserId == user.UserId)?.GuidBannerName,
                ReviewsCount = user.ReviewsRecipient.Count,
                Rating = user.ReviewsRecipient.Count > 0
                    ? user.ReviewsRecipient.Select(a => a.Mark).ToList().Average()
                    : 0,
                Relationship = _databaseContext.Relationships.FirstOrDefault(a =>
                    (a.RelatingUserId == authenticatedUserId && a.RelatedUserId == userId) || (
                        a.RelatingUserId == userId && a.RelatedUserId == authenticatedUserId))
            };
            return Result.Ok(sellerPresentation);
        }


        public Result<UserPresentation> GetClientPresentation(long userId, long authenticatedUserId)
        {
            var user = _databaseContext.Users
                .Include(a => a.UserClaims)
                .Include(a => a.ReviewsRecipient)
                .FirstOrDefault(a => a.UserId == userId);
            if (user == null)
            {
                return Result.Fail<UserPresentation>("User with current id not found");
            }

            if (user.UserClaims?.FirstOrDefault(a => a.UserId == userId)?.ClaimValue != RoleConstants.Client)
            {
                return Result.Fail<UserPresentation>("This user is not a client");
            }

            var clientPresentation = new UserPresentation
            {
                Role = user.UserClaims?.FirstOrDefault(a => a.UserId == user.UserId)?.ClaimValue,
                FirstName = user.FirstName,
                LastName = user.LastName,
                LocationName = user.LocationName,
                RegisterDate = user.Created,
                UserId = user.UserId,
                ReviewsCount = user.ReviewsRecipient.Count,
                Rating = user.ReviewsRecipient.Count > 0
                    ? user.ReviewsRecipient.Select(a => a.Mark).ToList().Average()
                    : 0,
                Relationship = _databaseContext.Relationships.FirstOrDefault(a =>
                    (a.RelatingUserId == authenticatedUserId && a.RelatedUserId == userId) || (
                        a.RelatingUserId == userId && a.RelatedUserId == authenticatedUserId))
            };
            return Result.Ok(clientPresentation);
        }

        public Result UpdateSellerPresentation(SellerPresentation sellerPresentation)
        {
            var sellerToUpdate = _databaseContext.SellerPresentations.FirstOrDefault(a =>
                a.SellerPresentationId == sellerPresentation.SellerPresentationId);
            if (sellerToUpdate == null)
            {
                return Result.Fail("Seller with id not found");
            }

            sellerToUpdate.BannerName = sellerPresentation.BannerName;
            sellerToUpdate.Description = sellerPresentation.Description;
            sellerToUpdate.GuidBannerName = sellerPresentation.GuidBannerName;
            sellerToUpdate.Modified = DateTime.Now;
            _databaseContext.SaveChanges();
            return Result.Ok();
        }

        public Result<SellerPresentation> GetSellerPresentationByUserId(long userId)
        {
            var sellerPresentation = _databaseContext.SellerPresentations.FirstOrDefault(a => a.UserId == userId);
            if (sellerPresentation == null)
            {
                return Result.Fail<SellerPresentation>(" Seller presentation not found");
            }

            return Result.Ok(sellerPresentation);
        }

        public Result CreateSellerPresentation(SellerPresentation sellerPresentation)
        {
            _databaseContext.SellerPresentations.Add(sellerPresentation);
            _databaseContext.SaveChanges();
            return Result.Ok();
        }
    }
}