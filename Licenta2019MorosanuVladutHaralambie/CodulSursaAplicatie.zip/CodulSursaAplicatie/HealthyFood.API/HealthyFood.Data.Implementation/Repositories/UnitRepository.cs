﻿using System.Collections.Generic;
using System.Linq;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;

namespace HealthyFood.Data.Implementation.Repositories
{
    public class UnitRepository: IUnitRepository
    {
        private readonly DatabaseContext _databaseContext;

        public UnitRepository(DatabaseContext databaseContext)
        {
            _databaseContext = databaseContext;
        }
        public Result<List<UnitType>> GetUnitTypes()
        {
            return Result.Ok(_databaseContext.UnitTypes.ToList());
        }

        public Result ValidateUnitTypeId(byte unitTypeId)
        {
            var unitType = _databaseContext.UnitTypes.FirstOrDefault(a => a.UnitTypeId == unitTypeId);
            if (unitType == null)
            {
                return Result.Fail("Invalid unit type id");
            }
            return  Result.Ok();
        }
    }
}
