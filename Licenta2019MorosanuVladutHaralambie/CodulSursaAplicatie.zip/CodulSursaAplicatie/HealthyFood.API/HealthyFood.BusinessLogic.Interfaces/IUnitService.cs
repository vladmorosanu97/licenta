﻿using System.Collections.Generic;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Models;

namespace HealthyFood.BusinessLogic.Interfaces
{
    public interface IUnitService
    {
        Result<List<UnitTypeBlModel>> GetUnitTypes();
        Result ValidateUnitTypeId(byte unitTypeId);
    }
}
