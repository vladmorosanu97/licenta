﻿using System.Collections.Generic;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Models;
using HealthyFood.BusinessLogic.Models.PrimitiveModels.AdvertisementModels;
using HealthyFood.BusinessLogic.Models.PrimitiveModels.Images;
using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models.DapperModels;

namespace HealthyFood.BusinessLogic.Interfaces
{
    public interface IAdvertisementService
    {
        Result<long> CreateAdvertisement(AdvertisementBlModel model);
        Result UpdateAdvertisement(AdvertisementBlModel model);
        Result AddPhotoToAdvertisement(List<ImageBlModel> model, long advertisementId);
        IEnumerable<AdvertisementCard> GetAdvertisementsCards(SearchAdvertisementsBlModel model);
        IEnumerable<AdvertisementCard> GetUserAdvertisementsCards(decimal? latitude, decimal? longitude, long userId);
        byte[] GetFileAdvertisementCard(string guidFileName);
        byte[] GetFileAdvertisement(string guidFileName);
        IEnumerable<SearchSuggestionDapper> GetSearchSuggestions(SearchText text, long userId);
        Result<AdvertisementBlModel> GetAdvertisementById(long advertisementId);
        Result DeleteAdvertisementById(long advertisementId);
        Result AddAdvertisementHistory(long userId, long advertisementId);
        IEnumerable<AdvertisementCard> GetTrendingAdvertisements(SearchAdvertisementsBlModel model);
    }
}