﻿using System;
using CSharpFunctionalExtensions;

namespace HealthyFood.BusinessLogic.Interfaces
{
    public interface IEmailService
    {
       Result SendActivationToken(string email, Guid token);
    }
}