﻿﻿using HealthyFood.BusinessLogic.Models.UserModels;
 using System.Collections.Generic;
 using System.Security.Claims;
 using CSharpFunctionalExtensions;
 using HealthyFood.Data.Models.DapperModels;
 using HealthyFood.Data.Models.Models;
 using HealthyFood.Data.Models.UserModels;

 namespace HealthyFood.BusinessLogic.Interfaces
{
    public interface IUserService
    {
        Result CreateUser(RegisterUserBlModel registerUserModel);
        Result UpdateUser(UpdateUserBlModel updateUserBlModel);
        Result<UserBlModel> CheckCredentials(LoginUserBlModel loginUserBlModel);
        Result<JwtTokenViewModel> GenerateToken(UserBlModel user, List<Claim> claims);
        Result<List<Claim>> GetUserClaims(UserBlModel user);
        Result ValidateToken(Token token);
        Result ConfirmAccount(ConfirmAccountBlModel confirmAccountBlModel);
        Result ValidateEmail(Email email);
        Result ValidateUserId(long userId);
        Result<UserBlModel> GetUserByToken(Token token);
        IEnumerable<UserCard> GetFriendsCards(long userId, decimal? latitude, decimal? longitude, string searchText);
        IEnumerable<UserCard> GetUsersCards(long userId, decimal? latitude, decimal? longitude, string searchText);
        IEnumerable<UserCard> GetFriendsRequestsCards(long userId);
        IEnumerable<UserSearchSuggestion> GetFriendsSearchSuggestions(string text, long userId);
        Result<UserBlModel> GetUserById(long userId);
        byte[] GetAvatarImageFile(string guidFileName);
        Result UpdatePassword(long userId, ChangePasswordBlModel changePasswordBlModel);
        Result<UserLocationsBlModel> GetSavedLocations(long userId);
        Result UpdateSavedLocations(long userId, UserLocationsBlModel userLocationsBlModel);
    }
}
