﻿using System.Collections.Generic;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Models;

namespace HealthyFood.BusinessLogic.Interfaces
{
    public interface IDeliveryService
    {
        Result ValidateDeliveryTypeId(int deliveryTypeId);
        Result CreateLocationDelivery(CreateLocationDeliveryBlModel model);
        Result CreateHomeDelivery(CreateHomeDeliveryBlModel model);
        Result<List<LocationDeliveryBlModel>> GetLocationDeliveries(long userId);
        Result<List<LocationDeliveryBlModel>> GetUserLocationDeliveries(long userId);
        Result<List<HomeDeliveryBlModel>> GetHomeDeliveries(long userId);
        Result<List<HomeDeliveryBlModel>> GetUserHomeDeliveries(long userId);
    }
}
