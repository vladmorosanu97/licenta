﻿using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Models.PrimitiveModels.Images;
using HealthyFood.BusinessLogic.Models.UserModels;

namespace HealthyFood.BusinessLogic.Interfaces
{
    public interface IPresentationService
    {
        Result<UserPresentationBlModel> GetUserPresentation(long userId, long authenticatedUserId);
        Result UpdatePresentationPhoto(ImageBlModel model, long userId);
        Result UpdatePresentationDescription(string description, long userId);
        byte[] GetPresentationImageFile(string guidFileName);
        Result CreateSellerPresentation(SellerPresentationBlModel blModel);
    }
}
