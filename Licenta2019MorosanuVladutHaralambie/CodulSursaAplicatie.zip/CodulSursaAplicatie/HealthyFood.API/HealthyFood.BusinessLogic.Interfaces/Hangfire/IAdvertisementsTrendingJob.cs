﻿using System;
using System.Threading.Tasks;
using Hangfire;

namespace HealthyFood.BusinessLogic.Interfaces.Hangfire
{
    public  interface IAdvertisementsTrendingJob
    {
        Task Run(IJobCancellationToken token);
        Task RunAtTimeOf(DateTime now);
    }
}
