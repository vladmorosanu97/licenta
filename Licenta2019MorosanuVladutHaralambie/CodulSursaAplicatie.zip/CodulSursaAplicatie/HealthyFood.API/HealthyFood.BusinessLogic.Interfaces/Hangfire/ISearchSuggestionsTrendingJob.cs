﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Hangfire;

namespace HealthyFood.BusinessLogic.Interfaces.Hangfire
{
    public interface ISearchSuggestionsTrendingJob
    {
        Task Run(IJobCancellationToken token);
        Task RunAtTimeOf(DateTime now);
    }
}
