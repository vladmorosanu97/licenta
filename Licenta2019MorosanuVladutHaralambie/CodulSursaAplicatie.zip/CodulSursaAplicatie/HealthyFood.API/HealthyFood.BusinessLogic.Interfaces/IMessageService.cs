﻿namespace HealthyFood.BusinessLogic.Interfaces
{
    public interface IMessageService
    {
//        Result<List<ChatBlModel>> GetChatsForUserId(long userId);
    }
}