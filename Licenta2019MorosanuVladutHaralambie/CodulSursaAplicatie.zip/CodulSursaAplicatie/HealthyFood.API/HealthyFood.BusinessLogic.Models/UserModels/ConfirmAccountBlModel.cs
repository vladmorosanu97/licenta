﻿using HealthyFood.Data.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models.UserModels
{
    public class ConfirmAccountBlModel
    {
        public Token Token { get; set; }
        public Role UserRole { get; set; }
        public Location LocationName { get; set; }
        public Coordinate Latitude { get; set; }
        public Coordinate Longitude { get; set; }
    }
}
