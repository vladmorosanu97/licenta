﻿using HealthyFood.BusinessLogic.Models.PrimitiveModels.Images;

namespace HealthyFood.BusinessLogic.Models.UserModels
{
    public class UpdateUserBlModel
    {
        public long UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public ImageBlModel Avatar { get; set; }
    }
}
