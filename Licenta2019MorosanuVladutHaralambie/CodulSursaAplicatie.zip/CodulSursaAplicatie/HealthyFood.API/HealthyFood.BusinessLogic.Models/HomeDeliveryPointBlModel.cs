﻿using System;
using HealthyFood.BusinessLogic.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models
{
    public class HomeDeliveryPointBlModel
    {
        public long HomeDeliveryPointId { get; set; }
        public DateTime ArrivalTime { get; set; }
        public long UserId { get; set; }
        public UserBlModel User { get; set; }
        public string Description { get; set; }
    }
}