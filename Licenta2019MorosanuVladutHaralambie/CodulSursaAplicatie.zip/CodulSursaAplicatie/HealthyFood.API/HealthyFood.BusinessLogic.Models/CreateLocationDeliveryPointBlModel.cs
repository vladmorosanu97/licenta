﻿using System;
using System.Collections.Generic;

namespace HealthyFood.BusinessLogic.Models
{
    public class CreateLocationDeliveryPointBlModel
    {
        public long DeliveryId { get; set; }
        public DateTime TimeStart { get; set; }
        public DateTime TimeEnd { get; set; }
        public string LocationName { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public bool IsForAllFriends { get; set; }
        public List<long> FriendsList { get; set; }
        public long ReceiverId { get; set; }
        public string Description { get; set; }
    }
}
