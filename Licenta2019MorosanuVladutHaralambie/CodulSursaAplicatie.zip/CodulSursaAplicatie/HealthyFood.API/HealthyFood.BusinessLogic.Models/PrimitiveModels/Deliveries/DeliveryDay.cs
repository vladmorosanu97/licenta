﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;

namespace HealthyFood.BusinessLogic.Models.PrimitiveModels.Deliveries
{
    public class DeliveryDay : ValueObject
    {
        public DateTime Value { get; }

        private DeliveryDay(DateTime value)
        {
            Value = value;
        }

        public static Result<DeliveryDay> Create(Maybe<DateTime> dayOrNothing)
        {
            return dayOrNothing.ToResult("Day should not be empty")
                .Ensure(day => day >= DateTime.Now, "Day should not be in the past")
                .Map(email => new DeliveryDay(email));
        }

        public static explicit operator DeliveryDay(DateTime email)
        {
            return Create(email).Value;
        }

        public static implicit operator DateTime(DeliveryDay email)
        {
            return email.Value;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }
    }
}
