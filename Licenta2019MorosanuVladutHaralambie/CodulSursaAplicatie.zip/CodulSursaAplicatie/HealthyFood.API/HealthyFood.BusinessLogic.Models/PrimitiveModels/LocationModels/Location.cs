﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;

namespace HealthyFood.Data.Models.UserModels
{
    public class Location: ValueObject
    {
        public string Value { get; }

        private Location(string value)
        {
            Value = value;
        }

        public static Result<Location> Create(Maybe<string> locationOrNothing)
        {
            return locationOrNothing.ToResult("Location should not be empty")
                .Map(location => new Location(location));
        }

        public static explicit operator Location(string location)
        {
            return Create(location).Value;
        }

        public static implicit operator string(Location location)
        {
            return location.Value;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }
    }
}
