﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;

namespace HealthyFood.Data.Models.UserModels
{
    public class PhotoPath : ValueObject
    {
        public string Value { get; }

        private PhotoPath(string value)
        {
            Value = value;
        }

        public static Result<PhotoPath> Create(Maybe<string> profilePathOrNothing)
        {
            return profilePathOrNothing.ToResult("Profile path should not be empty")
                .Map(profilePath => new PhotoPath(profilePath));
        }

        public static explicit operator PhotoPath(string profilePath)
        {
            return Create(profilePath).Value;
        }

        public static implicit operator string(PhotoPath profilePath)
        {
            return profilePath.Value;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }
    }
}