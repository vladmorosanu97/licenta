﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using CSharpFunctionalExtensions;

namespace HealthyFood.Data.Models.AdvertisementModels
{
    public class PhoneNumber : ValueObject
    {
        public string Value { get; }

        private PhoneNumber(string value)
        {
            Value = value;
        }

        public static Result<PhoneNumber> Create(Maybe<string> itemOrNothing)
        {
            return itemOrNothing.ToResult("Phone number should not be empty")
                .Ensure(number => new Regex(@"^\(?([0-9]{3})\)?[-.●]?([0-9]{3})[-.●]?([0-9]{4})$").IsMatch(itemOrNothing.Value), "Invalid phone number")
                .Ensure(number => number.Length < 256, "Invalid phone number")
                .Map(phoneNumber => new PhoneNumber(phoneNumber));
        }

        public static explicit operator PhoneNumber(string phoneNumber)
        {
            return Create(phoneNumber).Value;
        }

        public static implicit operator string(PhoneNumber phoneNumber)
        {
            return phoneNumber.Value;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }
    }
}
