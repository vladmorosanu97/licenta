﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;

namespace HealthyFood.Data.Models.UserModels
{
    public class Password: ValueObject
    {
        public string Value { get; }

        private Password(string value)
        {
            Value = value;
        }

        public static Result<Password> Create(Maybe<string> passwordOrNothing)
        {
            return passwordOrNothing.ToResult("Password should not be empty")
                .Ensure(password => password != string.Empty, "Password should not be empty")
                .Ensure(password => password.Length <= 256, "Password is too long")
                .Map(email => new Password(email));
        }

        public static explicit operator Password(string email)
        {
            return Create(email).Value;
        }

        public static implicit operator string(Password email)
        {
            return email.Value;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }
    }
}
