﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;

namespace HealthyFood.BusinessLogic.Models.PrimitiveModels.UserModels
{
    public class Mark : ValueObject
    {
    public decimal Value { get; }

    private Mark(decimal value)
    {
        Value = value;
    }

    public static Result<Mark> Create(Maybe<decimal> emailOrNothing)
    {
        return emailOrNothing.ToResult("Mark should not be empty")
            .Ensure(mark => mark >= 0.0M && mark <= 5, "Mark cannot be negative or big than 5")
            .Map(mark => new Mark(mark));
    }

    public static explicit operator Mark(decimal mark)
    {
        return Create(mark).Value;
    }

    public static implicit operator decimal(Mark mark)
    {
        return mark.Value;
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        throw new NotImplementedException();
    }
    }
}
