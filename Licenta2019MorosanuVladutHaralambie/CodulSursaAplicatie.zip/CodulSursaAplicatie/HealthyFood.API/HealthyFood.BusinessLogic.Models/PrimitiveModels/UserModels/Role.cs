﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;
using HealthyFood.Utils;

namespace HealthyFood.Data.Models.UserModels
{
    public class Role: ValueObject
    {
        public string Value { get; }

        private Role(string value)
        {
            Value = value;
        }

        public static Result<Role> Create(Maybe<string> userRoleOrNothing)
        {
            return userRoleOrNothing.ToResult("Role should not be empty")
                .Ensure(role => role != string.Empty, "Role should not be empty")
                .Ensure(role => role == RoleConstants.Client || role == RoleConstants.Seller, "User role is invalid")
                .Map(role => new Role(role));
        }

        public static explicit operator Role(string role)
        {
            return Create(role).Value;
        }

        public static implicit operator string(Role role)
        {
            return role.Value;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }
    }
}
