﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;

namespace HealthyFood.Data.Models.AdvertisementModels
{
    public class Title : ValueObject
    {
        public string Value { get; }

        private Title(string value)
        {
            Value = value;
        }

        public static Result<Title> Create(Maybe<string> titleOrNothing)
        {
            return titleOrNothing.ToResult("Title should not be empty")
                .Ensure(name => name.Length < 256, "Title is too long")
                .Map(coordinate => new Title(coordinate));
        }

        public static explicit operator Title(string title)
        {
            return Create(title).Value;
        }

        public static implicit operator string(Title title)
        {
            return title.Value;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }
    }
}
