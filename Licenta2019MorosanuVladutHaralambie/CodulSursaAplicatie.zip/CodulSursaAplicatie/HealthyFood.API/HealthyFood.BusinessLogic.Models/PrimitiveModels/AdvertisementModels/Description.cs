﻿using System;
using System.Collections.Generic;
using CSharpFunctionalExtensions;

namespace HealthyFood.Data.Models.AdvertisementModels
{
    public class Description : ValueObject
    {
        public string Value { get; }

        private Description(string value)
        {
            Value = value;
        }

        public static Result<Description> Create(Maybe<string> itemOrNothing)
        {
            return itemOrNothing.ToResult("Description should not be empty")
                .Ensure(description => description.Length < 2048, "Description is too long")
                .Map(description => new Description(description));
        }

        public static explicit operator Description(string description)
        {
            return Create(description).Value;
        }

        public static implicit operator string(Description description)
        {
            return description.Value;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            throw new NotImplementedException();
        }
    }
}
