﻿using System;
using System.Collections.Generic;
using HealthyFood.BusinessLogic.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models
{
    public class HomeDeliveryBlModel
    {
        public long AuthorId { get; set; }
        public UserBlModel Author { get; set; }
        public byte DeliveryTypeId { get; set; }
        public DateTime Day { get; set; }
        public List<HomeDeliveryPointBlModel> HomeDeliveryPoints { get; set; }
    }
}
