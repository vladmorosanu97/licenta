﻿using System;

namespace HealthyFood.BusinessLogic.Models
{
    public class AdvertisementImageBlModel
    {
        public int AdvertisementImageId { get; set; }
        public long AdvertisementId { get; set; }
        public string FileName { get; set; }
        public string GuidFileName { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual AdvertisementBlModel Advertisement { get; set; }
        public string ImagePath { get; set; }
    }
}
