﻿using System;
using System.Collections.Generic;
using HealthyFood.BusinessLogic.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models
{
    public partial class AdminBlModel
    {
        public AdminBlModel()
        {
            Advertisements = new HashSet<AdvertisementBlModel>();
            InverseInvitedByNavigation = new HashSet<AdminBlModel>();
        }

        public long AdminId { get; set; }
        public long UserId { get; set; }
        public long InvitedBy { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual AdminBlModel InvitedByNavigation { get; set; }
        public virtual UserBlModel User { get; set; }
        public virtual ICollection<AdvertisementBlModel> Advertisements { get; set; }
        public virtual ICollection<AdminBlModel> InverseInvitedByNavigation { get; set; }
    }
}
