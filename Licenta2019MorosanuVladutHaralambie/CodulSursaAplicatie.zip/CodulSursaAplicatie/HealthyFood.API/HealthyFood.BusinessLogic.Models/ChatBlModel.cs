﻿using System;
using System.Collections.Generic;

namespace HealthyFood.BusinessLogic.Models
{
    public partial class ChatBlModel
    {
        public ChatBlModel()
        {
            ChatUsers = new HashSet<ChatUserBlModel>();
            Messages = new HashSet<MessageBlModel>();
        }

        public long ChatId { get; set; }
        public string Name { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual ICollection<ChatUserBlModel> ChatUsers { get; set; }
        public virtual ICollection<MessageBlModel> Messages { get; set; }
    }
}
