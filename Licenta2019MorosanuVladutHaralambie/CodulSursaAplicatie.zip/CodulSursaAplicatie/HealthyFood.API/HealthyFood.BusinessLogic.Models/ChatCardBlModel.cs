﻿using System;

namespace HealthyFood.BusinessLogic.Models.PrimitiveModels.MessageModels
{
    public class ChatCardBlModel
    {
        public long ChatId { get; set; }
        public string Name { get; set; }
        public long PartnerId { get; set; }
        public string PartnerFirstName { get; set; }
        public string PartnerLastName { get; set; }
        public string PartnerEmail { get; set; }
        public int MessagesCount { get; set; }
        public bool IsOnline { get; set; }

        public decimal Rating { get; set; }
        public string LocationName { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
        public DateTime? LastTimeOnline { get; set; }
    }
}
