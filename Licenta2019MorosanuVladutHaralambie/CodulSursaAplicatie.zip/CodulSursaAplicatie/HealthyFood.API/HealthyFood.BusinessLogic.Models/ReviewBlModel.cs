﻿using System;
using HealthyFood.BusinessLogic.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models
{
    public partial class ReviewBlModel
    {
        public long ReviewId { get; set; }
        public long CreatorId { get; set; }
        public long RecipientId { get; set; }
        public string Content { get; set; }
        public decimal Mark { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual UserBlModel Creator { get; set; }
        public virtual UserBlModel Recipient { get; set; }
    }
}