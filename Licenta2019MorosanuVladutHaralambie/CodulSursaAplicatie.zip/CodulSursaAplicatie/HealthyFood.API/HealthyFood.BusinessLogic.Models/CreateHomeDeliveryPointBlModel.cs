﻿using System;

namespace HealthyFood.BusinessLogic.Models
{
    public class CreateHomeDeliveryPointBlModel
    {
        public DateTime ArrivalTime { get; set; }
        public long UserId { get; set; }
        public string Description { get; set; }
    }
}
