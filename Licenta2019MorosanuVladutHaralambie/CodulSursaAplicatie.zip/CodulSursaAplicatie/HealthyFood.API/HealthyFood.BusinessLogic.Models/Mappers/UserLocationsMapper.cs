﻿using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class UserLocationsMapper
    {
        public static UserLocationsBlModel GetBlModel(this UserLocations item)
        {
            return new UserLocationsBlModel()
            {
                HomeLatitude = item.HomeLatitude,
                HomeLocationName = item.HomeLocationName,
                Longitude = item.Longitude,
                LocationName = item.LocationName,
                Latitude = item.Latitude,
                HomeLongitude = item.HomeLongitude,
                AutomaticallyUpdateLocation = item.AutomaticallyUpdateLocation
            };
        }

        public static UserLocations GetDataModel(this UserLocationsBlModel item)
        {
            return new UserLocations()
            {
                HomeLatitude = item.HomeLatitude,
                HomeLocationName = item.HomeLocationName,
                Longitude = item.Longitude,
                LocationName = item.LocationName,
                Latitude = item.Latitude,
                HomeLongitude = item.HomeLongitude,
                AutomaticallyUpdateLocation = item.AutomaticallyUpdateLocation
            };
        }
    }
}
