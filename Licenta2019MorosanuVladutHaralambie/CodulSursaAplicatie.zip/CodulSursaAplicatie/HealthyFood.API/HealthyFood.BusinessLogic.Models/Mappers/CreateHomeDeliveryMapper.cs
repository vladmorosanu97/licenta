﻿using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class CreateHomeDeliveryMapper
    {
        public static Delivery GetDeliveryDataModel(this CreateHomeDeliveryBlModel blModel)
        {
            return new Delivery()
            {
                AuthorId = blModel.AuthorId,
                Day = blModel.Day,
                DeliveryTypeId = blModel.DeliveryTypeId
            };
        }
    }
}
