﻿using System.Linq;
using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class HomeDeliveryMapper
    {
        public static HomeDeliveryBlModel GetHomeDeliveryBlModel(this Delivery model)
        {
            return new HomeDeliveryBlModel()
            {
                AuthorId = model.AuthorId,
                Day = model.Day,
                DeliveryTypeId = model.DeliveryTypeId,
                Author = model.Author?.GetBlModel(),
                HomeDeliveryPoints = model.HomeDeliveryPoints.Select(a => a.GetBlModel()).ToList()
            };
        }
    }
}
