﻿using System.Linq;
using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class LocationDeliveryPointMapper
    {
        public static LocationDeliveryPointBlModel GetBlModel(this LocationDeliveryPoint model, long receiverUserId)
        {
            return new LocationDeliveryPointBlModel()
            {
                IsForAllFriends = model.IsForAllFriends,
                Latitude = model.Latitude,
                LocationName = model.LocationName,
                Longitude = model.Longitude,
                TimeEnd = model.TimeEnd,
                TimeStart = model.TimeStart,
                DeliveryId = model.DeliveryId,
                ReceiverId = receiverUserId,
                Description = model.Description
            };
        }

        public static LocationDeliveryPointBlModel GetBlModelWithFriends(this LocationDeliveryPoint model, long receiverUserId)
        {
            return new LocationDeliveryPointBlModel()
            {
                IsForAllFriends = model.IsForAllFriends,
                Latitude = model.Latitude,
                LocationName = model.LocationName,
                Longitude = model.Longitude,
                TimeEnd = model.TimeEnd,
                TimeStart = model.TimeStart,
                DeliveryId = model.DeliveryId,
                ReceiverId = receiverUserId,
                Friends = model.LocationDeliveryPointsUsers.Select(a => a.User?.GetBlModel()).ToList(),
                Description = model.Description
            };
        }
    }
}
