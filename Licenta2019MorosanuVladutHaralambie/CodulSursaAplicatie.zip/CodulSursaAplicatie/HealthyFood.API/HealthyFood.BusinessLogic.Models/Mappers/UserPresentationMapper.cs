﻿using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class UserPresentationMapper
    {
        public static UserPresentationBlModel GetBlModel(this UserPresentation item)
        {
            return new UserPresentationBlModel()
            {
                Role = item.Role,
                UserId = item.UserId,
                Description = item.Description,
                LastName = item.LastName,
                FirstName = item.FirstName,
                LocationName = item.LocationName,
                FollowersCount = item.FollowersCount,
                RegisterDate = item.RegisterDate,
                AdvertisementsCount = item.AdvertisementsCount,
                BannerPath = item.BannerPath,
                Rating = item.Rating,
                ReviewsCount = item.ReviewsCount,
                Relationship = item.Relationship?.GetBlModel()
            };
        }
    }
}