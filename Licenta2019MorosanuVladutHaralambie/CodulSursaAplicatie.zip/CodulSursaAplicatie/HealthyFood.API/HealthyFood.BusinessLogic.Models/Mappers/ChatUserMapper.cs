﻿using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class ChatUserMapper
    {
        public static ChatUser GetDataModel(this ChatUserBlModel blItem)
        {
            var item = new ChatUser()
            {
                ChatId = blItem.ChatId,
                UserId = blItem.UserId
            };
            return item;
        }

        public static ChatUserBlModel GetBlModel(this ChatUser item)
        {
            var blItem = new ChatUserBlModel()
            {
                User = item.User?.GetBlModel(),
                UserId = item.UserId,
                ChatId = item.ChatId,
                ChatUserId = item.ChatUserId
            };
            return blItem;
        }
    }
}