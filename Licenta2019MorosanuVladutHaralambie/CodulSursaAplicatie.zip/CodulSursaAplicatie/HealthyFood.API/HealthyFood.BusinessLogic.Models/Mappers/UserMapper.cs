﻿using System.Linq;
using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models;
using HealthyFood.Data.Models.DapperModels;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class UserMapper
    {
        public static User GetDataModel(this RegisterUserBlModel blModel)
        {
            var user = new User
            {
                Email = blModel.Email,
                FirstName = blModel.FirstName,
                LastName = blModel.LastName,
                EmailConfirmed = false,
                PhoneNumberConfirmed = false,
                TwoFactorEnabled = false,
                LockoutEnabled = true,
                AccessFailedCount = 0,
                ActivationToken = blModel.ActivationToken.ToString()
            };
            return user;
        }


        public static UserBlModel GetBlModel(this User item)
        {
            var user = new UserBlModel
            {
                Email = item.Email,
                FirstName = item.FirstName,
                LastName = item.LastName,
                Role = item.UserClaims.FirstOrDefault()?.ClaimValue,
                UserId = item.UserId,
                PhoneNumber = item.PhoneNumber,
                GuidAvatarName = item.GuidAvatarName,
            };
            return user;
        }

        public static UserBlModel GetBlModelWithLocations(this User item)
        {
            var user = new UserBlModel
            {
                Email = item.Email,
                FirstName = item.FirstName,
                LastName = item.LastName,
                Role = item.UserClaims.FirstOrDefault()?.ClaimValue,
                UserId = item.UserId,
                PhoneNumber = item.PhoneNumber,
                GuidAvatarName = item.GuidAvatarName,
                LocationName = item.HomeLocationName,
                Latitude = item.HomeLatitude,
                Longitude = item.HomeLongitude
            };
            return user;
        }


        public static UserCard GetUserCardModel(this User item)
        {
            var user = new UserCard
            {
                ReviewsCount = item.ReviewsRecipient?.Count ?? 0,
                Rating = item.ReviewsRecipient?.Count > 0 ? item.ReviewsRecipient.Select(a => a.Mark).Average() : 0,
                UserId = item.UserId,
                AdvertisementsCount = item.AdvertisementsCreatedBy?.Count ?? 0,
                FirstName = item.FirstName,
                LastName = item.LastName,
            };
            return user;
        }

        public static User GetDataModel(this UserBlModel blModel)
        {
            var user = new User
            {
                Email = blModel.Email,
                FirstName = blModel.FirstName,
                LastName = blModel.LastName
            };
            return user;
        }


        public static User GetDataModel(this ConfirmAccountBlModel blModel)
        {
            var user = new User
            {
                ActivationToken = blModel.Token,
                LocationName = blModel.LocationName,
                Latitude = blModel.Latitude,
                Longitude = blModel.Longitude
            };
            return user;
        }
    }
}