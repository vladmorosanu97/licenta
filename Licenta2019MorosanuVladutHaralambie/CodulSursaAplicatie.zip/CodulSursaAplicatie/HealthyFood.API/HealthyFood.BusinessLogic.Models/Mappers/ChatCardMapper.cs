﻿using HealthyFood.BusinessLogic.Models.PrimitiveModels.MessageModels;
using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class ChatCardMapper
    {
        public static ChatCardBlModel GetBlModel(this ChatCard item)
        {
            var blItem = new ChatCardBlModel()
            {
                ChatId = item.ChatId,
                Name = item.Name,
                PartnerId = item.PartnerId,
                PartnerFirstName = item.PartnerFirstName,
                PartnerLastName = item.PartnerLastName,
                MessagesCount = item.MessagesCount,
                IsOnline = item.IsOnline,
                Longitude = item.Longitude,
                Latitude = item.Latitude,
                LocationName = item.LocationName,
                Rating = item.Rating,
                PartnerEmail = item.PartnerEmail,
                LastTimeOnline = item.LastTimeOnline
            };
            return blItem;
        }
    }
}
