﻿using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Models.Mappers
{
    public static class CategoryMapper
    {
        public static CategoryBlModel GetBlModel(this Category item)
        {
            var categoryBlItem = new CategoryBlModel()
            {
                Name = item.Name,
                CategoryId = item.CategoryId
            };
            return categoryBlItem;
        }
    }
}
