﻿namespace HealthyFood.BusinessLogic.Models
{
    public class SearchSuggestionBlModel
    {
        public long SearchSuggestionId { get; set; }
        public string Text { get; set; }
    }
}
