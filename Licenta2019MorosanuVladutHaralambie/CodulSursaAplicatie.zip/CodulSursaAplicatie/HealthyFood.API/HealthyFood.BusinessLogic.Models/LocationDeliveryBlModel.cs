﻿using System;
using System.Collections.Generic;
using HealthyFood.BusinessLogic.Models.UserModels;

namespace HealthyFood.BusinessLogic.Models
{
    public class LocationDeliveryBlModel
    {

        public long LocationDeliveryId { get; set; }
        public long AuthorId { get; set; }
        public byte DeliveryTypeId { get; set; }
        public DateTime Day { get; set; }
        public List<LocationDeliveryPointBlModel> LocationDeliveryPoints { get; set; }
        public UserBlModel Author { get; set; }
    }
}
