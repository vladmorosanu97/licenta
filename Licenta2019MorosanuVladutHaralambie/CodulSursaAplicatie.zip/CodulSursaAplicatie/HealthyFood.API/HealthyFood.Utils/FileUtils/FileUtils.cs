﻿using System.IO;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Http;

namespace HealthyFood.Utils.FileUtils
{
    public static class FileUtils
    {
        public static string GetFilename(IFormFile file)
        {
            return ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
        }

        public static void SaveFileToDisk(this IFormFile file, string fullPath)
        {
            using (var stream = new FileStream(fullPath, FileMode.Create))
            {
                file.CopyTo(stream);
            }
        }

        public static void CreateDirectoryIfNotExists(string folderName)
        {
            if (!Directory.Exists(folderName))
            {
                Directory.CreateDirectory(folderName);
            }
        }
    }
}
