﻿namespace HealthyFood.Utils
{
    public class RoleConstants
    {
        public static string Seller = "seller";
        public static string Client = "client";
        public static string Admin = "admin";
    }
}