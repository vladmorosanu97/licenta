﻿namespace HealthyFood.Utils
{
    public class UserClaims
    {
        public string Role { get; set; }
        public long UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
    }
}