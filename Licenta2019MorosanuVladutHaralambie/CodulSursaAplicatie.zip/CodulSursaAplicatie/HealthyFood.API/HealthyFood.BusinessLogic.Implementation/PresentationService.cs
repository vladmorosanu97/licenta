﻿using System;
using System.IO;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Models.Mappers;
using HealthyFood.BusinessLogic.Models.PrimitiveModels.Images;
using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;
using HealthyFood.Utils;
using HealthyFood.Utils.FileUtils;

namespace HealthyFood.BusinessLogic.Implementation
{
    public class PresentationService: IPresentationService
    {
        private readonly IUserRepository _userRepository;
        private readonly AppSettings _appSettings;
        private readonly IPresentationRepository _presentationRepository;

        public PresentationService(IUserRepository userRepository, AppSettings appSettings, IPresentationRepository presentationRepository)
        {
            _userRepository = userRepository;
            _appSettings = appSettings;
            _presentationRepository = presentationRepository;
        }
        public Result<UserPresentationBlModel> GetUserPresentation(long userId, long authenticatedUserId)
        {
            var userClaimResult = _userRepository.GetUserClaimByUserId(userId);
            if (userClaimResult.IsFailure)
            {
                return Result.Fail<UserPresentationBlModel>(userClaimResult.Error);
            }

            Result<UserPresentation> userPresentationResult;
            if (userClaimResult.Value.ClaimValue == RoleConstants.Seller)
            {
                userPresentationResult = _presentationRepository.GetSellerPresentation(userId, authenticatedUserId);
                userPresentationResult.Value.BannerPath = userPresentationResult.Value.BannerPath != null
                    ? _appSettings.ServerHost +
                      $"/api/presentations/photos?guidFileName={userPresentationResult.Value.BannerPath}"
                    : null;
            }
            else
            {
                userPresentationResult = _presentationRepository.GetClientPresentation(userId, authenticatedUserId);
            }


            if (userPresentationResult.IsFailure)
            {
                return Result.Fail<UserPresentationBlModel>(userPresentationResult.Error);
            }

            return Result.Ok(userPresentationResult.Value.GetBlModel());
        }

        public Result UpdatePresentationDescription(string description, long userId)
        {
            var presentationResult = _presentationRepository.GetSellerPresentationByUserId(userId);
            if (presentationResult.IsFailure)
            {
                return Result.Fail(presentationResult.Error);
            }

            presentationResult.Value.Description = description;
            var presentationUpdatedResult = _presentationRepository.UpdateSellerPresentation(presentationResult.Value);
            if (presentationUpdatedResult.IsFailure)
            {
                return Result.Fail(presentationUpdatedResult.Error);
            }

            return Result.Ok();
        }

        public byte[] GetPresentationImageFile(string guidFileName)
        {
            if (guidFileName == null)
            {
                return null;
            }

            var folderName = _appSettings.Images.UserPresentationPath;
            var fullPath = Path.Combine(folderName, guidFileName);
            return System.IO.File.ReadAllBytes(fullPath);
        }

        public Result CreateSellerPresentation(SellerPresentationBlModel blModel)
        {
            var createSellerPresentationResult =
                _presentationRepository.CreateSellerPresentation(blModel.GetDataModel());
            if (createSellerPresentationResult.IsFailure)
            {
                return Result.Fail(createSellerPresentationResult.Error);
            }
            return Result.Ok();
        }

        public Result UpdatePresentationPhoto(ImageBlModel model, long userId)
        {
            var folderName = _appSettings.Images.UserPresentationPath;
            FileUtils.CreateDirectoryIfNotExists(folderName);

            var presentationResult = _presentationRepository.GetSellerPresentationByUserId(userId);
            if (presentationResult.IsFailure)
            {
                return Result.Fail(presentationResult.Error);
            }

            presentationResult.Value.BannerName = model.Name;
            presentationResult.Value.GuidBannerName = Guid.NewGuid().ToString();
            _presentationRepository.UpdateSellerPresentation(presentationResult.Value);

            var fullPath = Path.Combine(folderName, presentationResult.Value.GuidBannerName);
            byte[] bytes = Convert.FromBase64String(model.Base64.Split(',')[1]);
            System.IO.File.WriteAllBytes(fullPath, bytes);
            return Result.Ok();
        }
    }
}
