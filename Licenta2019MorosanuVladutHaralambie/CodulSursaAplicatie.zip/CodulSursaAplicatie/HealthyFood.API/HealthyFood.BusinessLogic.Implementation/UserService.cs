﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Models.Mappers;
using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Models;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models.DapperModels;
using HealthyFood.Data.Models.Models;
using HealthyFood.Data.Models.UserModels;
using HealthyFood.Utils;
using HealthyFood.Utils.FileUtils;
using ImageMagick;
using Microsoft.IdentityModel.Tokens;

namespace HealthyFood.BusinessLogic.Implementation
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly AppSettings _appSettings;

        public UserService(IUserRepository userRepository, AppSettings appSettings)
        {
            _userRepository = userRepository;
            _appSettings = appSettings;
        }

        public Result CreateUser(RegisterUserBlModel registerUserModel)
        {
            Result<Maybe<User>> resultUser = _userRepository.FindByEmail(registerUserModel.Email.Value);
            if (resultUser.Value.HasValue)
            {
                return Result.Fail($"User with email {registerUserModel.Email.Value} already exists!");
            }

            var user = registerUserModel.GetDataModel();
            var passwordHash = GeneratePasswordHash(registerUserModel.Password.Value);
            user.PasswordHash = passwordHash;

            //Fail Fast Principle
            Result resultCreateUser = _userRepository.CreateUser(user);
            if (resultCreateUser.IsFailure)
            {
                return Result.Fail(resultCreateUser.Error);
            }

            return Result.Ok();
        }

        public Result UpdateUser(UpdateUserBlModel updateUserBlModel)
        {
            var folderName = _appSettings.Images.UserAvatarPath;
            FileUtils.CreateDirectoryIfNotExists(folderName);

            var validateUserIdResult = _userRepository.ValidateUserId(updateUserBlModel.UserId);
            if (validateUserIdResult.IsFailure)
            {
                return Result.Fail(validateUserIdResult.Error);
            }

            var user = updateUserBlModel.GetDataModel();
            var updateUserResult = _userRepository.UpdateUser(user);
            if (updateUserResult.IsFailure)
            {
                return Result.Fail(updateUserResult.Error);
            }

            if (updateUserBlModel.Avatar != null && updateUserBlModel.Avatar.Base64 != null)
            {
                user.AvatarName = updateUserBlModel.Avatar.Name;
                user.GuidAvatarName = Guid.NewGuid().ToString()  +".png";

                var fullPath = Path.Combine(folderName, user.GuidAvatarName);
                byte[] bytes = Convert.FromBase64String(updateUserBlModel.Avatar.Base64.Split(',')[1]);
                File.WriteAllBytes(fullPath, bytes);

                var file = new FileInfo(fullPath);
                //                sprite.Format = MagickFormat.Jpeg;
                //                sprite.Quality = 30;
                //                sprite.Resize(400, 0);

                using (MagickImage image = new MagickImage(fullPath))
                {
                    image.Format = MagickFormat.Png;
                    // - alpha set
                    image.Alpha(AlphaOption.Set);

                    // +clone
                    using (IMagickImage clone = image.Clone())
                    {
                        // -distort DePolar 0
                        clone.Distort(DistortMethod.DePolar, 0);

                        // -virtual-pixel HorizontalTile
                        clone.VirtualPixelMethod = VirtualPixelMethod.HorizontalTile;

                        // -background None
                        clone.BackgroundColor = MagickColors.None;

                        // -distort Polar 0
                        clone.Distort(DistortMethod.Polar, 0);

                        // -compose Dst_In -composite
                        image.Composite(clone, CompositeOperator.DstIn);

                     

                        // -trime
                        image.Trim();

                        // +repage
                        image.RePage();

                        // circle_masked.png
                        image.Write(fullPath);
                    }

                  
                }



                var updateAvatarResult = _userRepository.UpdateAvatar(user);
                if (updateAvatarResult.IsFailure)
                {
                    return Result.Fail(updateUserResult.Error);
                }
            }
            else if (updateUserBlModel.Avatar != null && updateUserBlModel.Avatar.ImagePath == null)
            {
                user.AvatarName = null;
                user.GuidAvatarName = null;

                var updateAvatarResult = _userRepository.UpdateAvatar(user);
                if (updateAvatarResult.IsFailure)
                {
                    return Result.Fail(updateUserResult.Error);
                }
            }


            return Result.Ok();
        }

        public string GeneratePasswordHash(string password)
        {
            return SecurePasswordHasher.Hash(password);
        }

        public Result<UserBlModel> CheckCredentials(LoginUserBlModel loginUserBlModel)
        {
            Result<Maybe<User>> resultUser = _userRepository.FindByEmail(loginUserBlModel.Email);
            if (resultUser.Value.HasNoValue)
            {
                return Result.Fail<UserBlModel>($"User with this email does not exist");
            }

            Result result =
                _userRepository.CheckPassword(loginUserBlModel.Email.Value, loginUserBlModel.Password.Value);
            if (result.IsFailure)
            {
                return Result.Fail<UserBlModel>(result.Error);
            }

            return Result.Ok(resultUser.Value.Value.GetBlModel());
        }


        public Result<JwtTokenViewModel> GenerateToken(UserBlModel user, List<Claim> claims)
        {
            var userResult = _userRepository.FindByEmail(user.Email);
            if (userResult.Value.HasNoValue)
            {
                return Result.Fail<JwtTokenViewModel>($"The user with {user.Email} does not exist.");
            }


            claims.Add(new Claim("email", user.Email));
            claims.Add(new Claim("role", claims.First(item => item.Type == ClaimTypes.Role).Value));
            claims.Add(new Claim("lastName", user.LastName ?? ""));
            claims.Add(new Claim("firstName", user.FirstName ?? ""));
            claims.Add(new Claim("userId", user.UserId.ToString()));
            claims.Add(new Claim("phoneNumber", user.PhoneNumber ?? ""));
            claims.Add(new Claim("avatarUrl",
                user.GuidAvatarName != null
                    ? _appSettings.ServerHost + "/api/accounts/photos?guidFileName=" + user.GuidAvatarName
                    : ""));
            var keyA = _appSettings.Tokens.Key;

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_appSettings.Tokens.Key));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var expiresIn = DateTime.Now.AddDays(30);
            var token = new JwtSecurityToken(
                issuer: _appSettings.Tokens.Issuer,
                audience: _appSettings.Tokens.Audience,
                claims: claims,
                expires: expiresIn,
                signingCredentials: creds);
            var tokenString = new JwtSecurityTokenHandler().WriteToken(token);
            var accessToken = new JwtTokenViewModel
            {
                access_token = tokenString,
                expires_in = (int) (expiresIn - DateTime.Now).TotalMinutes
            };

            return Result.Ok(accessToken);
        }

        public Result<List<Claim>> GetUserClaims(UserBlModel user)
        {
            return Result.Ok(_userRepository.GetUserClaims(user.GetDataModel()).Select(c => c.GetClaims()).ToList());
        }

        public Result ValidateToken(Token token)
        {
            return _userRepository.ValidateToken(token);
        }

        public Result ConfirmAccount(ConfirmAccountBlModel confirmAccountBlModel)
        {
            Result<User> userResult = _userRepository.GetUserByToken(confirmAccountBlModel.Token);
            if (userResult.IsFailure)
            {
                return Result.Fail(userResult.Error);
            }

            Result addUserClaimResult = _userRepository.AddClaim(userResult.Value,
                new Claim(ClaimTypes.Role, confirmAccountBlModel.UserRole));
            if (addUserClaimResult.IsFailure)
            {
                return Result.Fail(addUserClaimResult.Error);
            }

            Result validateEmail = _userRepository.ConfirmAccount(confirmAccountBlModel.GetDataModel());
            if (validateEmail.IsFailure)
            {
                return Result.Fail(validateEmail.Error);
            }

            return Result.Ok();
        }

        public Result ValidateEmail(Email email)
        {
            return _userRepository.ValidateEmail(email);
        }

        public Result ValidateUserId(long userId)
        {
            return _userRepository.ValidateUserId(userId);
        }

        public Result<UserBlModel> GetUserByToken(Token token)
        {
            var userResult = _userRepository.GetUserByToken(token);
            if (userResult.IsFailure)
            {
                return Result.Fail<UserBlModel>(userResult.Error);
            }

            return Result.Ok(_userRepository.GetUserByToken(token).Value.GetBlModel());
        }

        public IEnumerable<UserCard> GetFriendsCards(long userId, decimal? latitude, decimal? longitude,
            string searchText)
        {
            return _userRepository.GetFriendsCards(userId, latitude, longitude, searchText);
        }

        public IEnumerable<UserCard> GetUsersCards(long userId, decimal? latitude, decimal? longitude, string searchText)
        {
            return _userRepository.GetUsersCards(userId, latitude, longitude, searchText);
        }

        public IEnumerable<UserCard> GetFriendsRequestsCards(long userId)
        {
            return _userRepository.GetFriendsRequestsCards(userId);
        }

        public IEnumerable<UserSearchSuggestion> GetFriendsSearchSuggestions(string text, long userId)
        {
            return _userRepository.GetFriendsSearchSuggestions(text, userId);
        }

        public Result<UserBlModel> GetUserById(long userId)
        {
            var userResult = _userRepository.GetUserById(userId);
            if (userResult == null)
            {
                return Result.Fail<UserBlModel>("Invalid userId");
            }

            return Result.Ok(userResult.GetBlModel());
        }

        public byte[] GetAvatarImageFile(string guidFileName)
        {
            if (guidFileName == null)
            {
                return null;
            }

            var folderName = _appSettings.Images.UserAvatarPath;
            var fullPath = Path.Combine(folderName, guidFileName);
            return File.ReadAllBytes(fullPath);
        }

        public Result UpdatePassword(long userId, ChangePasswordBlModel changePasswordBlModel)
        {
            Result currentPasswordResult =
                _userRepository.CheckPassword(userId, changePasswordBlModel.CurrentPassword);
            if (currentPasswordResult.IsFailure)
            {
                return Result.Fail("The current password is invalid");
            }

            var changePasswordResult = _userRepository.UpdatePassword(userId, changePasswordBlModel.NewPassword);
            if (changePasswordResult.IsFailure)
            {
                return Result.Fail(changePasswordResult.Error);
            }

            return Result.Ok();
        }

        public Result<UserLocationsBlModel> GetSavedLocations(long userId)
        {
            var locationsResult = _userRepository.GetSavedLocations(userId);
            if (locationsResult.IsFailure)
            {
                return Result.Fail<UserLocationsBlModel>(locationsResult.Error);
            }

            return Result.Ok(locationsResult.Value.GetBlModel());
        }

        public Result UpdateSavedLocations(long userId, UserLocationsBlModel userLocationsBlModel)
        {
            var updateSavedLocationsResult = _userRepository.UpdateSavedLocations(userId, userLocationsBlModel.GetDataModel());
            if (updateSavedLocationsResult.IsFailure)
            {
                return Result.Fail(updateSavedLocationsResult.Error);
            }
            return Result.Ok();
        }
    }
}