﻿using System.Collections.Generic;
using System.Linq;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Models;
using HealthyFood.BusinessLogic.Models.Mappers;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Implementation
{
    public class CategoryService: ICategoryService
    {
        private readonly ICategoryRepository _categoryRepository;

        public CategoryService(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }
        public Result<List<CategoryBlModel>> GetCategories()
        {
            Result<List<Category>> result = _categoryRepository.GetCategories();
            if (result.IsFailure)
            {
                return Result.Fail<List<CategoryBlModel>>(result.Error);
            }
            return Result.Ok(result.Value.Select(a => a.GetBlModel()).ToList());
        }

        public Result ValidateCategoryId(int categoryId)
        {
            return _categoryRepository.ValidateCategory(categoryId);
        }
    }
}
