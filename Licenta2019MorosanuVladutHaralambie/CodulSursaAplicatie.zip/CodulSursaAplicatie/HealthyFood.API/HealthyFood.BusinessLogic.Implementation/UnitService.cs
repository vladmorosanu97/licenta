﻿using System.Collections.Generic;
using System.Linq;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Models;
using HealthyFood.BusinessLogic.Models.Mappers;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;

namespace HealthyFood.BusinessLogic.Implementation
{
    public class UnitService : IUnitService
    {
        private readonly IUnitRepository _unitRepository;

        public UnitService(IUnitRepository unitRepository)
        {
            _unitRepository = unitRepository;
        }

        public Result<List<UnitTypeBlModel>> GetUnitTypes()
        {
            Result<List<UnitType>> unitTypeResult = _unitRepository.GetUnitTypes();
            if (unitTypeResult.IsFailure)
            {
                return Result.Fail<List<UnitTypeBlModel>>(unitTypeResult.Error);
            }

            return Result.Ok(_unitRepository.GetUnitTypes().Value.Select(e => e.GetBlModel()).ToList());
        }

        public Result ValidateUnitTypeId(byte unitTypeId)
        {
            return _unitRepository.ValidateUnitTypeId(unitTypeId);
        }
    }
}
