﻿using System;
using System.Net;
using System.Net.Mail;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.Utils;

namespace HealthyFood.BusinessLogic.Implementation
{
    public class EmailService : IEmailService
    {
        private readonly AppSettings _appSettings;

        public EmailService(AppSettings appSettings)
        {
            _appSettings = appSettings;
        }
        public Result SendActivationToken(string email, Guid token)
        {
           
            var client = new SmtpClient(_appSettings.EmailSettings.PrimaryDomain, _appSettings.EmailSettings.PrimaryPort)
            {
                Credentials = new NetworkCredential(_appSettings.EmailSettings.Email, _appSettings.EmailSettings.Password),
                EnableSsl = true
            };
            var template = $"<table style=\"text-align: center; width: 49.7453%; height: 219px; margin-left: 25.8913%;\"><tbody><tr><th><h1 class=\"m_-6225809901619558061\\&quot;text-center\\&quot;\" style=\"text-align: center;\"><span style=\"font-family: Arial, Helvetica, sans-serif; color: rgb(102, 102, 102); font-size: 36px;\">Welcome to HealtyFood</span></h1><p style=\"text-align: center;\"><br></p><p style=\"text-align: center;\"><span style=\"color: rgb(106, 168, 79); font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 700; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; float: none; display: inline !important; font-size: small;\">Thanks for joining our community. We're excited to share everything that we know about marketing, automation, and growing your business.</span></p><p style=\"text-align: center;\"><br></p><p style=\"text-align: center;\"><a href=\"http://localhost:4200/authentication/confirm-account?token={token}\">Confirm account</a></p><p style=\"text-align: center;\"><br></p></th></tr></tbody></table>";
            var msg = new MailMessage(_appSettings.EmailSettings.Email,
                email, "Confirm Account",
                template) {IsBodyHtml = true};


            client.Send( msg);
            return Result.Ok();
        }
        
    }
}