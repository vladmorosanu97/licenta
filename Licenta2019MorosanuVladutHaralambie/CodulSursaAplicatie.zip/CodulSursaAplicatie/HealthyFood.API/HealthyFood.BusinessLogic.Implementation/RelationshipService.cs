﻿using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.Data.Interfaces;

namespace HealthyFood.BusinessLogic.Implementation
{
    public class RelationshipService: IRelationshipService
    {
        private readonly IRelationshipRepository _relationshipRepository;

        public RelationshipService(IRelationshipRepository relationshipRepository)
        {
            _relationshipRepository = relationshipRepository;
        }
        public Result SendFriendRequest(long userId, long receiverId)
        {
            return _relationshipRepository.SendFriendRequest(userId, receiverId);
        }

        public Result CancelFriendRequest(long userId, long receiverId)
        {
            return _relationshipRepository.CancelFriendRequest(userId, receiverId);
        }

        public Result AcceptFriendRequest(long userId, long senderId)
        {
            return _relationshipRepository.AcceptFriendRequest(userId, senderId);
        }

        public Result RemoveFriendRequest(long userId, long senderId)
        {
            return _relationshipRepository.RemoveFriendRequest(userId, senderId);
        }

        public Result RemoveFriend(long userId, long receiverId)
        {
            return _relationshipRepository.RemoveFriend(userId, receiverId);
        }
    }
}
