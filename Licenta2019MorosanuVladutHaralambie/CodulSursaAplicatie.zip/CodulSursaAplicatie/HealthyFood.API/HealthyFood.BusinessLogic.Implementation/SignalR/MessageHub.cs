﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Models;
using HealthyFood.BusinessLogic.Models.Mappers;
using HealthyFood.BusinessLogic.Models.PrimitiveModels.MessageModels;
using HealthyFood.BusinessLogic.Models.UserModels;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace HealthyFood.BusinessLogic.Implementation.SignalR
{
    [Authorize]
    public class MessageHub : Hub
    {
        private readonly IMessageRepository _messageRepository;
        private readonly IUserRepository _userRepository;

        public MessageHub(IMessageRepository messageRepository, IUserRepository userRepository)
        {
            _messageRepository = messageRepository;
            _userRepository = userRepository;
        }

        public async Task<ChatCardBlModel> AddToChat(long partnerId)
        {
            int userId = int.Parse(Context.User.Claims.First(item => item.Type == "userId").Value);
            var partnerIdResult = _userRepository.ValidateUserId(partnerId);
            if (partnerIdResult.IsFailure)
            {
                return new ChatCardBlModel();
            }
            var chatNameResult = _messageRepository.GetChatByUsersIds(userId, partnerId);
            if (chatNameResult.IsSuccess)
            {
                await Groups.AddToGroupAsync(Context.ConnectionId, chatNameResult.Value.Name);
                _messageRepository.UpdateSeenMessages(userId, chatNameResult.Value.ChatId);

                var chats = _messageRepository.GetChatsForUserId(userId).Value.Select(a => a.GetBlModel()).ToList();
                await Clients.Client(Context.ConnectionId).SendAsync("GetChats", chats);
                return chatNameResult.Value.GetBlModel();
            }

            var chat = new ChatBlModel();
            chat.Name = Guid.NewGuid().ToString();
            var chatIdResult = _messageRepository.CreateChat(chat.GetDataModel());
            if (chatIdResult.IsSuccess)
            {
                var chatUsers = new ChatUserBlModel();
                chatUsers.UserId = userId;
                chatUsers.ChatId = chatIdResult.Value;
                _messageRepository.AddUserToChat(chatUsers.GetDataModel());

                var chatPartner = new ChatUserBlModel();
                chatPartner.UserId = partnerId;
                chatPartner.ChatId = chatIdResult.Value;
                _messageRepository.AddUserToChat(chatPartner.GetDataModel());
            }

            await Groups.AddToGroupAsync(Context.ConnectionId, chat.Name);
            _messageRepository.UpdateSeenMessages(userId, chat.ChatId);

            var chats2 = _messageRepository.GetChatsForUserId(userId).Value.Select(a => a.GetBlModel()).ToList();
            await Clients.Client(Context.ConnectionId).SendAsync("GetChats", chats2);

            var chatNameAfterInsertResult = _messageRepository.GetChatByUsersIds(userId, partnerId);
            return chatNameAfterInsertResult.Value.GetBlModel();
        }


        public async Task SendMessageToChat(MessageBlModel message)
        {
            Result chatIdResult = _messageRepository.ValidateChatId(message.ChatId);
            Result userIdResult = _userRepository.ValidateUserId(message.AuthorId);
            Result contentResult = Content.Create(message.Content);
            Result result = Result.Combine(chatIdResult, userIdResult, contentResult);

            if (result.IsFailure)
            {
                return;
            }

            message.Seen = false;
            _messageRepository.CreateMessage(message.GetDataModel());

            var firstName = Context.User.Claims.First(item => item.Type == "firstName").Value;
            message.Author = new UserBlModel {FirstName = firstName};
            message.Created = DateTime.Now;
            var chatNameResult = _messageRepository.GetChatNameByChatId(message.ChatId);
            if (chatNameResult.IsFailure)
            {
                return;
            }
            await Clients.Group(chatNameResult.Value).SendAsync("Send", message);
            _messageRepository.UpdateSeenMessages(message.AuthorId, message.ChatId);

            // NOTIFY PARTNER ABOUT MESSAGE
            var partnerId = _messageRepository.GetUserPartner(message.AuthorId, message.ChatId);
            var userConnection = _messageRepository.GetUserConnection(partnerId.Value);

            await GetChatsByUserId(partnerId.Value, userConnection.Value);
            await GetChatsByUserId(message.AuthorId, Context.ConnectionId);
        }

        public async Task GetChats()
        {
            int userId = int.Parse(Context.User.Claims.First(item => item.Type == "userId").Value);
            await GetChatsByUserId(userId, Context.ConnectionId);
        }

        public async Task GetChatsByUserId(long userId, string connectionId)
        {
            var chats = _messageRepository.GetChatsForUserId(userId).Value.Select(a => a.GetBlModel()).ToList();
            await Clients.Client(connectionId).SendAsync("GetChats", chats);
        }


        public List<MessageBlModel> GetMessages(long chatId)
        {
            int userId = int.Parse(Context.User.Claims.First(item => item.Type == "userId").Value);
            var validateChatIdResult = _messageRepository.ValidateChatIdByUserId(chatId, userId);
            if (validateChatIdResult.IsFailure)
            {
                return new List<MessageBlModel>();
            }

            return _messageRepository.GetMessages(chatId).Value.Select(a => a.GetBlModel()).ToList();
        }

        public void RegisterConnection(long userId, string connectionId)
        {
            var userConnection = new UserConnection();
            userConnection.UserId = userId;
            userConnection.ConnectionId = connectionId;
            userConnection.IsOnline = true;
            _messageRepository.AddUserConnection(userConnection);
        }

        public override async Task OnConnectedAsync()
        {
            int userId = int.Parse(Context.User.Claims.First(item => item.Type == "userId").Value);
            RegisterConnection(userId, Context.ConnectionId);

            var userConnectionsResult = _messageRepository.GetUsersPartners(userId);
            foreach (var connection in userConnectionsResult.Value)
            {
                var userIdResult = _messageRepository.GetUserIdByConnectionId(connection);
                await GetChatsByUserId(userIdResult.Value, connection);
            }

            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception exception)
        {
            _messageRepository.UpdateUserConnectionOffline(Context.ConnectionId);
            var userIdResult = _messageRepository.GetUserIdByConnectionId(Context.ConnectionId);
            if (userIdResult.IsFailure)
            {
                return;
            }

            var chats = _messageRepository.GetChatsForUserId(userIdResult.Value);
            foreach (var chat in chats.Value)
            {
                await Groups.RemoveFromGroupAsync(Context.ConnectionId, chat.Name);
            }

            // notify all users about this event
            var userConnectionsResult = _messageRepository.GetUsersPartners(userIdResult.Value);
            foreach (var connection in userConnectionsResult.Value)
            {
                var userId2Result = _messageRepository.GetUserIdByConnectionId(connection);
                await GetChatsByUserId(userId2Result.Value, connection);
            }

            await base.OnDisconnectedAsync(exception);
        }
    }
}