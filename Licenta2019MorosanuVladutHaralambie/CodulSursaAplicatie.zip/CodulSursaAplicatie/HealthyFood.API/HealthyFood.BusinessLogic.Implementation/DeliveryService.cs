﻿using System.Collections.Generic;
using System.Linq;
using CSharpFunctionalExtensions;
using HealthyFood.BusinessLogic.Interfaces;
using HealthyFood.BusinessLogic.Models;
using HealthyFood.BusinessLogic.Models.Mappers;
using HealthyFood.Data.Interfaces;
using HealthyFood.Data.Models;
using HealthyFood.Utils;

namespace HealthyFood.BusinessLogic.Implementation
{
    public class DeliveryService : IDeliveryService
    {
        private readonly IDeliveryRepository _deliveryRepository;
        private readonly AppSettings _appSettings;

        public DeliveryService(IDeliveryRepository deliveryRepository, AppSettings appSettings)
        {
            _deliveryRepository = deliveryRepository;
            _appSettings = appSettings;
        }

        public Result ValidateDeliveryTypeId(int deliveryTypeId)
        {
            return _deliveryRepository.ValidateDeliveryTypeId(deliveryTypeId);
        }

        public Result CreateLocationDelivery(CreateLocationDeliveryBlModel model)
        {
            var delivery = model.GetDeliveryDataModel();
            var deliveryResult = _deliveryRepository.CreateDelivery(delivery);
            if (deliveryResult.IsFailure)
            {
                return Result.Fail(deliveryResult.Error);
            }

            foreach (var locationDeliveryPoint in model.LocationDeliveryPoints)
            {
                var locationDeliveryPointIdResult =
                    _deliveryRepository.CreateLocationDeliveryPoint(
                        locationDeliveryPoint.GetDataModel(deliveryResult.Value));
                if (locationDeliveryPointIdResult.IsFailure)
                {
                    return Result.Fail(locationDeliveryPointIdResult.Error);
                }

                if (locationDeliveryPoint.IsForAllFriends == false)
                {
                    var locationDeliveryPointUsers = new List<LocationDeliveryPointsUser>();
                    foreach (var friend in locationDeliveryPoint.FriendsList)
                    {
                        var locationDeliveryPointsUser = new LocationDeliveryPointsUser
                        {
                            LocationDeliveryPointId = locationDeliveryPointIdResult.Value,
                            UserId = friend
                        };
                        locationDeliveryPointUsers.Add(locationDeliveryPointsUser);
                    }

                    _deliveryRepository.CreateLocationDeliveryPointsUsers(locationDeliveryPointUsers);
                }
            }

            return Result.Ok();
        }

        public Result CreateHomeDelivery(CreateHomeDeliveryBlModel model)
        {
            var delivery = model.GetDeliveryDataModel();
            var deliveryResult = _deliveryRepository.CreateDelivery(delivery);
            if (deliveryResult.IsFailure)
            {
                return Result.Fail(deliveryResult.Error);
            }

            foreach (var homeDeliveryPoint in model.HomeDeliveryPoints)
            {
                var deliveryPointIdResult =
                    _deliveryRepository.CreateHomeDeliveryPoint(homeDeliveryPoint.GetDataModel(deliveryResult.Value));
                if (deliveryPointIdResult.IsFailure)
                {
                    return Result.Fail(deliveryPointIdResult.Error);
                }
            }

            return Result.Ok();
        }

        public Result<List<LocationDeliveryBlModel>> GetLocationDeliveries(long userId)
        {
            var result = _deliveryRepository.GetLocationDeliveries(userId);
            if (result.IsFailure)
            {
                return Result.Fail<List<LocationDeliveryBlModel>>(result.Error);
            }

            var res = result.Value.Select(a => a.GetLocationDeliveryBlModel(userId)).ToList();


            res.Select(a =>
            {
                a.Author.AvatarUrl = a.Author.GuidAvatarName != null
                    ? _appSettings.ServerHost + "/api/accounts/photos?guidFileName=" + a.Author.GuidAvatarName
                    : null;
                return a;
            }).ToList();

            return Result.Ok(res);
        }

        public Result<List<LocationDeliveryBlModel>> GetUserLocationDeliveries(long userId)
        {
            var result = _deliveryRepository.GetUserLocationDeliveries(userId);
            if (result.IsFailure)
            {
                return Result.Fail<List<LocationDeliveryBlModel>>(result.Error);
            }

            var userLocationDeliveries = result.Value.Select(a => a.GetLocationDeliveryBlModelWithFriends(userId)).ToList();
           
            foreach (var locationDelivery in userLocationDeliveries)
            {
                locationDelivery.Author.AvatarUrl = locationDelivery.Author.GuidAvatarName != null
                    ? _appSettings.ServerHost + "/api/accounts/photos?guidFileName=" +
                      locationDelivery.Author.GuidAvatarName
                    : null;
                foreach (var locationDeliveryPoint in locationDelivery.LocationDeliveryPoints)
                {
                    foreach (var friend in locationDeliveryPoint.Friends)
                    {
                        friend.AvatarUrl = friend.GuidAvatarName != null
                            ? _appSettings.ServerHost + "/api/accounts/photos?guidFileName=" +
                              friend.GuidAvatarName
                            : null;
                    }
                   
                }
            }

            return Result.Ok(userLocationDeliveries);
        }

        public Result<List<HomeDeliveryBlModel>> GetHomeDeliveries(long userId)
        {
            var result = _deliveryRepository.GetHomeDeliveries(userId);
            if (result.IsFailure)
            {
                return Result.Fail<List<HomeDeliveryBlModel>>(result.Error);
            }

            var res = result.Value.Select(a => a.GetHomeDeliveryBlModel()).ToList();
            foreach (var homeDelivery in res)
            {
                homeDelivery.Author.AvatarUrl = homeDelivery.Author.GuidAvatarName != null
                    ? _appSettings.ServerHost + "/api/accounts/photos?guidFileName=" +
                      homeDelivery.Author.GuidAvatarName
                    : null;
                foreach (var homeDeliveryPoint in homeDelivery.HomeDeliveryPoints)
                {
                    homeDeliveryPoint.User.AvatarUrl = homeDeliveryPoint.User.GuidAvatarName != null
                        ? _appSettings.ServerHost + "/api/accounts/photos?guidFileName=" +
                          homeDeliveryPoint.User.GuidAvatarName
                        : null;
                }
            }

            return Result.Ok(res);
        }

        public Result<List<HomeDeliveryBlModel>> GetUserHomeDeliveries(long userId)
        {
            var result = _deliveryRepository.GetUserHomeDeliveries(userId);
            if (result.IsFailure)
            {
                return Result.Fail<List<HomeDeliveryBlModel>>(result.Error);
            }

            var res = result.Value.Select(a => a.GetHomeDeliveryBlModel()).ToList();
            foreach (var homeDelivery in res)
            {
                homeDelivery.Author.AvatarUrl = homeDelivery.Author.GuidAvatarName != null
                    ? _appSettings.ServerHost + "/api/accounts/photos?guidFileName=" +
                      homeDelivery.Author.GuidAvatarName
                    : null;
                foreach (var homeDeliveryPoint in homeDelivery.HomeDeliveryPoints)
                {
                    homeDeliveryPoint.User.AvatarUrl = homeDeliveryPoint.User.GuidAvatarName != null
                        ? _appSettings.ServerHost + "/api/accounts/photos?guidFileName=" +
                          homeDeliveryPoint.User.GuidAvatarName
                        : null;
                }
            }

            return Result.Ok(res);
        }
    }
}