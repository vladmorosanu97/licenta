﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Models;
using HealthyFood.Data.Models.DapperModels;

namespace HealthyFood.Data.Interfaces
{
    public interface IAdvertisementRepository
    {
        Result<long> CreateAdvertisement(Advertisement advertisement);
        Result UpdateAdvertisement(Advertisement advertisement);
        Result AddAdvertisementImages(List<AdvertisementImage> advertisementImages);
        IEnumerable<AdvertisementCard> GetAdvertisementsCards(decimal? latitude, decimal? longitude, int distance,
            int pageNumber, long userId, string searchText);
        IEnumerable<AdvertisementCard> GetUserAdvertisementsCards(decimal? latitude, decimal? longitude, long userId);
        IEnumerable<SearchSuggestionDapper> GetSearchSuggestions(string text, long userId);
        Result<long> CreateSearchSuggestion(SearchSuggestion searchSuggestionId);
        Result CountSearchSuggestion(long searchSuggestionId);
        Result CreateSearchHistory(SearchHistory searchHistory);
        Result<long> GetSearchSuggestionIdByText(string searchSuggestionText);
        Result<Advertisement> GetAdvertisementById(long advertisementId);
        Result DeleteAdvertisementById(long advertisementId);
        Result AddAdvertisementHistory(AdvertisementHistory advertisementHistory);
        List<Advertisement> GetAllAdvertisements();
        Result<List<long>> GetViewsCountLastSevenDays(long advertisementId);
        Result<long> GetViewsCountToday(long advertisementId);
        Task<Result> UpdateTrendingValue(AdvertisementTrending advertisementTrending);
        IEnumerable<AdvertisementCard> GetTrendingAdvertisements(decimal? latitude, decimal? longitude, int distance,  long userId);
    }
}