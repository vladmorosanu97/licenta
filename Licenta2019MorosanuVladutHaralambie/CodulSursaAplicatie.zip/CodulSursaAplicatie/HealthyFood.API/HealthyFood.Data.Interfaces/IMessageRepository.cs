﻿using System.Collections.Generic;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Models;

namespace HealthyFood.Data.Interfaces
{
    public interface IMessageRepository
    {
        Result<List<ChatCard>> GetChatsForUserId(long userId);
        Result<User> GetSecondUserForChat(long chatId, long userId);
        Result<ChatCard> GetChatByUsersIds(long userId, long partnerId);
        Result ValidateChatId(long chatId);
        Result CreateMessage(Message message);
        Result<long> CreateChat(Chat chat);
        Result AddUserToChat(ChatUser chatUser);
        Result<List<Message>> GetMessages(long chatId);
        Result AddUserConnection(UserConnection userConnection);
        Result UpdateUserConnectionOffline(string connectionId);
        Result<string> GetUserConnection(long userId);
        Result UpdateSeenMessages(long userId, long chatId);
        Result<long> GetUserIdByConnectionId(string connectionId);
        Result<List<string>> GetUsersPartners(long userId);
        Result ValidateChatIdByUserId(long chatId, long userId);
        Result<long> GetUserPartner(long userId, long chatId);
        Result<string> GetChatNameByChatId(long chatId);
    }
}
