﻿using System.Collections.Generic;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Models;

namespace HealthyFood.Data.Interfaces
{
    public interface ICategoryRepository
    {
        Result<List<Category>> GetCategories();
        Result ValidateCategory(int categoryId);
    } 
}
