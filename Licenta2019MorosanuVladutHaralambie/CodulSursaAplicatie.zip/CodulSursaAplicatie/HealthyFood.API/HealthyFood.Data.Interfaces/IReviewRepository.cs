﻿using System.Collections.Generic;
using CSharpFunctionalExtensions;
using HealthyFood.Data.Models;

namespace HealthyFood.Data.Interfaces
{
    public interface IReviewRepository
    {
        List<Review> GetReviewsForUserId(long userId);
        Result CreateReview(Review review);
    }
}
