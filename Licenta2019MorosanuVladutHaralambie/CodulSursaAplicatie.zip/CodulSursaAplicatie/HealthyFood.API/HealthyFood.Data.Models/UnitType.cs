﻿using System.Collections.Generic;

namespace HealthyFood.Data.Models
{
    public partial class UnitType
    {
        public UnitType()
        {
            Advertisements = new HashSet<Advertisement>();
        }

        public byte UnitTypeId { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }

        public virtual ICollection<Advertisement> Advertisements { get; set; }
    }
}
