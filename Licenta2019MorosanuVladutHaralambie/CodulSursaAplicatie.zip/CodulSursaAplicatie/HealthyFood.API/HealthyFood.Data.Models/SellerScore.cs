﻿using System;

namespace HealthyFood.Data.Models
{
    public partial class SellerScore
    {
        public long SellerScoreId { get; set; }
        public long UserId { get; set; }
        public decimal Score { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual User User { get; set; }
    }
}
