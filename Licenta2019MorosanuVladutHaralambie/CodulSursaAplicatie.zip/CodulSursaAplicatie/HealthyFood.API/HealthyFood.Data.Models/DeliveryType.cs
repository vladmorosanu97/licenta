﻿using System;
using System.Collections.Generic;

namespace HealthyFood.Data.Models
{
    public partial class DeliveryType
    {
        public DeliveryType()
        {
            Deliveries = new HashSet<Delivery>();
        }

        public byte DeliveryTypeId { get; set; }
        public string Name { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual ICollection<Delivery> Deliveries { get; set; }
    }
}
