﻿using System;
using System.Collections.Generic;

namespace HealthyFood.Data.Models
{
    public partial class Category
    {
        public Category()
        {
            Advertisements = new HashSet<Advertisement>();
        }

        public long CategoryId { get; set; }
        public string Name { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual ICollection<Advertisement> Advertisements { get; set; }
    }
}
