﻿using System;

namespace HealthyFood.Data.Models
{
    public class ChatCard
    {
        public long ChatId { get; set; }
        public string Name { get; set; }
        public long PartnerId { get; set; }
        public string PartnerFirstName { get; set; }
        public string PartnerLastName { get; set; }
        public string PartnerEmail { get; set; }
        public int MessagesCount { get; set; }
        public bool IsOnline { get; set; }
        public long TotalMessages { get; set; }

        public decimal Rating { get; set; }
        public string LocationName { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
        public DateTime? LastTimeOnline { get; set; }
    }
}