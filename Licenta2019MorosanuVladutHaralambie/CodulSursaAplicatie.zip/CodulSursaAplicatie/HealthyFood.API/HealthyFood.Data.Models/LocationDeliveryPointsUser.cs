﻿using System;

namespace HealthyFood.Data.Models
{
    public partial class LocationDeliveryPointsUser
    {
        public long LocationDeliveryPointUserId { get; set; }
        public long LocationDeliveryPointId { get; set; }
        public long UserId { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual LocationDeliveryPoint LocationDeliveryPoint { get; set; }
        public virtual User User { get; set; }
    }
}
