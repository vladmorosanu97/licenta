﻿namespace HealthyFood.Data.Models.DapperModels
{
    public class SearchSuggestionDapper
    {
        public long SearchSuggestionId { get; set; }
        public string Text { get; set; }
        public int SearchSuggestionType { get; set; }
    }
}
