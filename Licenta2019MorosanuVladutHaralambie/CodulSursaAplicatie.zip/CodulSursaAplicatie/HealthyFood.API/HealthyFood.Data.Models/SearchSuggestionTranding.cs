﻿using System;
using System.Collections.Generic;

namespace HealthyFood.Data.Models
{
    public partial class SearchSuggestionTrending
    {
        public long SearchSuggestionTrendingId { get; set; }
        public long SearchSuggestionId { get; set; }
        public decimal TrendingValue { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual SearchSuggestion SearchSuggestion { get; set; }
    }
}
