﻿using System;

namespace HealthyFood.Data.Models
{
    public partial class Relationship
    {
        public long RelationshipId { get; set; }
        public long RelatingUserId { get; set; }
        public long RelatedUserId { get; set; }
        public string Type { get; set; }
        public bool SendMails { get; set; }
        public bool SendNotifications { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual User RelatedUser { get; set; }
        public virtual User RelatingUser { get; set; }
    }
}
