﻿using System;

namespace HealthyFood.Data.Models
{
    public partial class Message
    {
        public long MessageId { get; set; }
        public long ChatId { get; set; }
        public long AuthorId { get; set; }
        public string Content { get; set; }
        public bool Seen { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual User Author { get; set; }
        public virtual Chat Chat { get; set; }
    }
}
