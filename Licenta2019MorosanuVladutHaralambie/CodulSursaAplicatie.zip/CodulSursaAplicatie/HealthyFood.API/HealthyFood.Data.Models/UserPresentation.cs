﻿using System;

namespace HealthyFood.Data.Models
{
    public class UserPresentation
    {
        public long UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int AdvertisementsCount { get; set; }
        public int FollowersCount { get; set; }
        public string LocationName { get; set; }
        public DateTime? RegisterDate { get; set; }
        public string Description { get; set; }
        public string Role { get; set; }
        public string BannerPath { get; set; }
        public decimal Rating { get; set; }
        public int ReviewsCount { get; set; }
        public Relationship Relationship { get; set; }
    }
}
