﻿using System;

namespace HealthyFood.Data.Models
{
    public partial class Admin
    {
        public long AdminId { get; set; }
        public long UserId { get; set; }
        public long InvitedBy { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public virtual User InvitedByNavigation { get; set; }
        public virtual User User { get; set; }
    }
}
