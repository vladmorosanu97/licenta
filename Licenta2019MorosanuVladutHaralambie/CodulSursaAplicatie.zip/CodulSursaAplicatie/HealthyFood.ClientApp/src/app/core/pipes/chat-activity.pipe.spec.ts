import { ChatActivityPipe } from './chat-activity.pipe';

describe('ChatActivityPipe', () => {
  it('create an instance', () => {
    const pipe = new ChatActivityPipe();
    expect(pipe).toBeTruthy();
  });
});
