import { Pipe, PipeTransform } from '@angular/core';
import TimeAgo from 'javascript-time-ago';
import en from 'javascript-time-ago/locale/en';
@Pipe({
  name: 'datePipe'
})
export class DatePipe implements PipeTransform {
  transform(value: Date, args?: any): any {
    TimeAgo.addLocale(en);
    const timeAgo = new TimeAgo('en-US');
    if (value === undefined) {
      return null;
    }

    const today = new Date().getTime() - 1 * 24 * 60 * 60 * 1000;
    if (today < new Date(value).getTime()) {
      return timeAgo.format(new Date(value));
    } else if (today > new Date(value).getTime()) {
      return timeAgo.format(new Date(value).getTime(), 'twitter');
    }
  }
}
