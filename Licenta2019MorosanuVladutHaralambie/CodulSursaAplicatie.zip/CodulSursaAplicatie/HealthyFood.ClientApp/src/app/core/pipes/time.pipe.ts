import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'time'
})
export class TimePipe implements PipeTransform {
  transform(value: Date, args?: any): any {
    if (value === null || value === undefined) {
      return false;
    }
    value = new Date(value);
    let h: any = value.getHours();
    let m: any = value.getMinutes();
    m = m <= 9 ? '0' + m : m;
    h = h <= 9 ? '0' + h : h;
    return h + ':' + m;
  }
}
