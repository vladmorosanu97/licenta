import { Injectable } from '@angular/core';
import SearchInputModel from '../shared/models/search-input-model';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HeaderService {
  /* NOTE new BehaviorSubject trigger next() function
          with null value where is received in subscribe()
  */
  private searchProductsObserver = new BehaviorSubject<SearchInputModel>(null);
  private searchUsersObserver = new BehaviorSubject<string>(null);
  private toggleMenuObserver = new BehaviorSubject<boolean>(true);
  private logoutObserver = new BehaviorSubject<boolean>(null);

  getSearchProductsObserver() {
    return this.searchProductsObserver;
  }

  getSearchUsersObserver() {
    return this.searchUsersObserver;
  }

  getLogoutObserver() {
    return this.logoutObserver;
  }

  getToggleMenuObserver() {
    return this.toggleMenuObserver;
  }

  constructor() {}

  onSearchProducts(item: SearchInputModel) {
    this.searchProductsObserver.next(item);
  }

  onSearchUsers(item: string) {
    this.searchUsersObserver.next(item);
  }

  onToggleMenu(value: boolean) {
    this.toggleMenuObserver.next(value);
  }

  onLogout(value: boolean) {
    this.logoutObserver.next(value);
  }
}
