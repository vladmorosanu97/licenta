import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import CreateLocationDeliveryModel from '../shared/models/create-location-delivery-model';
import { Observable } from 'rxjs';
import LocationDeliveryModel from '../shared/models/location-delivery-model';
import CreateHomeDeliveryModel from '../shared/models/create-home-delivery-model';
import HomeDeliveryModel from '../shared/models/home-delivery-model';

const API_URL = `${environment.apiEndpoint}/deliveries`;

@Injectable({
  providedIn: 'root'
})
export class DeliveryService {
  url: string;
  constructor(private http: HttpClient) {
    this.url = API_URL;
  }

  addLocationDelivery(model: CreateLocationDeliveryModel): Observable<boolean> {
    return this.http.post(
      `${this.url}/location-deliveries`,
      model
    ) as Observable<boolean>;
  }

  addHomeDelivery(model: CreateHomeDeliveryModel): Observable<boolean> {
    return this.http.post(`${this.url}/home-deliveries`, model) as Observable<
      boolean
    >;
  }

  getLocationDeliveries(): Observable<Array<LocationDeliveryModel>> {
    return this.http.get(`${this.url}/location-deliveries`) as Observable<
      Array<LocationDeliveryModel>
    >;
  }

  getHomeDeliveries(): Observable<Array<HomeDeliveryModel>> {
    return this.http.get(`${this.url}/home-deliveries`) as Observable<
      Array<HomeDeliveryModel>
    >;
  }

  getUserLocationDeliveries(): Observable<Array<LocationDeliveryModel>> {
    return this.http.get(`${this.url}/user-location-deliveries`) as Observable<
      Array<LocationDeliveryModel>
    >;
  }

  getUserHomeDeliveries(): Observable<Array<HomeDeliveryModel>> {
    return this.http.get(`${this.url}/user-home-deliveries`) as Observable<
      Array<HomeDeliveryModel>
    >;
  }
}
