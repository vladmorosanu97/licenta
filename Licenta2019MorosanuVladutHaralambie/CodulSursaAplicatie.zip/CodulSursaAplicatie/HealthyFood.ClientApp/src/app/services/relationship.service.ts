import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

const API_URL = `${environment.apiEndpoint}/relationships`;

@Injectable({
  providedIn: 'root'
})
export class RelationshipService {
  url: string;
  constructor(private http: HttpClient) {
    this.url = API_URL;
  }

  sendFriendRequest(receiverId: number): Observable<boolean> {
    return this.http.post(
      `${this.url}/send-friend-request/${receiverId}`,
      null
    ) as Observable<boolean>;
  }

  cancelFriendRequest(receiverId: number): Observable<boolean> {
    return this.http.post(
      `${this.url}/cancel-friend-request/${receiverId}`,
      null
    ) as Observable<boolean>;
  }

  acceptFriendRequest(senderId: number): Observable<boolean> {
    return this.http.post(
      `${this.url}/accept-friend-request/${senderId}`,
      null
    ) as Observable<boolean>;
  }

  removeFriend(receiverId: number): Observable<boolean> {
    return this.http.post(
      `${this.url}/remove-friend/${receiverId}`,
      null
    ) as Observable<boolean>;
  }

  removeFriendRequest(senderId: number): Observable<boolean> {
    return this.http.post(
      `${this.url}/remove-friend-request/${senderId}`,
      null
    ) as Observable<boolean>;
  }
}
