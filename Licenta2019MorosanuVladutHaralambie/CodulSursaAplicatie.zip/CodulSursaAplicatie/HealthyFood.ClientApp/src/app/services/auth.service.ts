import UserModel from 'src/app/shared/models/user-model';
import { environment } from '../../environments/environment';
import { Injectable } from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import LoginUserModel from 'src/app/shared/models/login-user-model';
import jwt_decode from 'jwt-decode';
const API_URL = `${environment.apiEndpoint}/accounts`;
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private url: string;
  public loggedIn = new Subject<void>();
  constructor(private oAuthService: OAuthService, private router: Router) {
    this.url = API_URL;
  }

  isLoggedIn() {
    this.loggedIn.next();
  }

  loginUserAndLoadUserProfile(userModel: LoginUserModel) {
    return this.oAuthService.fetchTokenUsingPasswordFlowAndLoadUserProfile(
      userModel.email,
      userModel.password
    );
  }

  refreshToken() {
    this.setRefreshTokenEndpoint();
    return this.oAuthService.refreshToken();
  }

  setRefreshTokenEndpoint() {
    this.oAuthService.tokenEndpoint = this.url + '/refresh-token';
  }

  setLoginTokenEndpoint() {
    this.oAuthService.tokenEndpoint = this.url + '/login';
  }

  getClaims(): UserModel {
    const token = this.oAuthService.getAccessToken() || {};
    return jwt_decode(token);
  }

  getRole(): string {
    const claims = this.getClaims();
    const userRole = claims.role;
    return userRole;
  }

  getUserId(): number {
    const claims = this.getClaims();
    const userId = claims.userId;
    return userId;
  }

  getUserProfile(): UserModel {
    const claims = this.getClaims();
    const user = new UserModel();
    user.email = claims.email;
    user.firstName = claims.firstName;
    user.lastName = claims.lastName;
    user.userId = claims.userId;
    user.phoneNumber = claims.phoneNumber;
    user.avatarUrl = claims.avatarUrl;
    return user;
  }

  // isAuthorized(): boolean {
  //   const claims = this.oAuthService.getIdentityClaims();
  //   console.log(claims);
  //   if (!claims || !this.oAuthService.hasValidAccessToken()) {
  //     return false;
  //   }
  //   return true;
  // }

  isAuthenticated(): boolean {
    const claims = this.oAuthService.getIdentityClaims();
    if (
      claims === null ||
      !claims ||
      !this.oAuthService.hasValidAccessToken()
    ) {
      return false;
    }
    return true;
  }

  logOut() {
    this.oAuthService.logOut(false);
    this.loggedIn.next();
    this.router.navigate(['authentication/login']);
  }

  getAccessToken() {
    return this.oAuthService.getAccessToken();
  }
}
