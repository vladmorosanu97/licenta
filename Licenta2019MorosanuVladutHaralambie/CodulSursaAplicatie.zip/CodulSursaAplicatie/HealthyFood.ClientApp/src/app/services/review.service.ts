import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import ReviewModel from '../shared/models/review-model';
import CreateReviewModel from '../shared/models/create-review';

const API_URL = `${environment.apiEndpoint}/reviews`;
@Injectable({
  providedIn: 'root'
})
export class ReviewService {
  private url: string;
  constructor(private http: HttpClient) {
    this.url = API_URL;
  }

  getReviews(userId: number): Observable<Array<ReviewModel>> {
    return this.http.get(`${this.url}/${userId}`) as Observable<
      Array<ReviewModel>
    >;
  }

  addReview(review: CreateReviewModel): Observable<boolean> {
    return this.http.post(`${this.url}`, review) as Observable<boolean>;
  }
}
