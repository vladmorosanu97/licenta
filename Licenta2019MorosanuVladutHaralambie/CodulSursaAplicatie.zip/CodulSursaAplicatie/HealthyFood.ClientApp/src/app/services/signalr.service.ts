import { Subject, BehaviorSubject } from 'rxjs';
import MessageModel from 'src/app/shared/models/message-model';
import { Injectable } from '@angular/core';
import * as signalR from '@aspnet/signalr';
import { join } from 'path';
import ChatUserModel from '../shared/models/chat-user-model';
import ChatModel from '../shared/models/chat-model';

@Injectable({
  providedIn: 'root'
})
export class SignalrService {
  public connectionObserver: BehaviorSubject<boolean> = new BehaviorSubject(
    null
  );
  constructor() {}

  private hubConnection: signalR.HubConnection;

  startConnection(token: string) {
    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl('https://localhost:44374/messagesHub', {
        skipNegotiation: true,
        transport: signalR.HttpTransportType.WebSockets,
        accessTokenFactory: () => token
      })
      .build();

    return this.hubConnection.start();
  }

  stopConnection() {
    if (this.hubConnection) {
      this.hubConnection.stop();
    }
  }

  getMessageListener = callback => {
    this.hubConnection.on('Send', (data: MessageModel) => {
      callback(data);
    });
  };

  GetChatsListener = callback => {
    this.hubConnection.on('GetChats', (data: Array<ChatModel>) => {
      callback(data);
    });
  };

  getChats(): void {
    console.log('send request chats');
    if (this.hubConnection) {
      this.hubConnection.invoke('GetChats');
    }
  }

  getMessages(chatId: number) {
    console.log('send request chats');
    if (this.hubConnection) {
      return this.hubConnection.invoke('GetMessages', chatId);
    }
  }

  joinToChat(partnerId) {
    console.log('send join');
    if (this.hubConnection) {
      return this.hubConnection.invoke('AddToChat', partnerId);
    }
  }

  sendMessageToGroup(message: MessageModel): void {
    if (this.hubConnection) {
      this.hubConnection.invoke('SendMessageToChat', message);
    }
  }
}
