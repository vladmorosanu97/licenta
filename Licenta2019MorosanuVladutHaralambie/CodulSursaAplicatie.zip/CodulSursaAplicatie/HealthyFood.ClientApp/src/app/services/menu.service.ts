import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  private menuObserver = new BehaviorSubject<string>(null);
  constructor() {}

  getMenuObserver() {
    return this.menuObserver;
  }

  onClick(item: string) {
    this.menuObserver.next(item);
  }
}
