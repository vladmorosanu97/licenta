import { environment } from './../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import ImageModel from 'src/app/shared/models/image-model';
import { Injectable } from '@angular/core';
import UserPresentationModel from '../shared/models/user-presentation-model';

const API_URL = `${environment.apiEndpoint}/presentations`;

@Injectable({
  providedIn: 'root'
})
export class PresentationService {
  url: string;
  constructor(private http: HttpClient) {
    this.url = API_URL;
  }

  updatePresentationPhoto(image: ImageModel): Observable<string> {
    return this.http.post(this.url + '/images', image) as Observable<string>;
  }

  updatePresentationDescription(description: string): Observable<string> {
    const formData: FormData = new FormData();
    formData.append('description', description);
    return this.http.post(this.url + '/descriptions', formData) as Observable<
      string
    >;
  }

  getPresentationById(userId: number): Observable<UserPresentationModel> {
    return this.http.get(`${this.url}/${userId}`) as Observable<
      UserPresentationModel
    >;
  }
}
