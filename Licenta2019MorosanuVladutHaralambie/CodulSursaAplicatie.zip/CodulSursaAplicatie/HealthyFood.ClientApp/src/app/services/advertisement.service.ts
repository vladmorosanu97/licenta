import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import CreateOrUpdateAdvertisementModel from '../shared/models/create-or-update-advertisement-model';
import { HttpClient } from '@angular/common/http';
import AdvertisementCardModel from '../shared/models/advertisement-card-model';
import SearchSuggestionModel from '../shared/models/search-suggestion-model';
import SearchInputModel from '../shared/models/search-input-model';
import SearchAdvertisementsModel from '../shared/models/search-advertisements-model';
import AdvertisementModel from '../shared/models/advertisement-model';

const API_URL = `${environment.apiEndpoint}/advertisements`;
@Injectable({
  providedIn: 'root'
})
export class AdvertisementService {
  private url: string;
  constructor(private http: HttpClient) {
    this.url = API_URL;
  }

  createAdvertisement(
    model: CreateOrUpdateAdvertisementModel
  ): Observable<Array<CreateOrUpdateAdvertisementModel>> {
    return this.http.post(this.url, model) as Observable<
      Array<CreateOrUpdateAdvertisementModel>
    >;
  }

  updateAdvertisement(
    model: CreateOrUpdateAdvertisementModel
  ): Observable<object> {
    return this.http.put(this.url, model) as Observable<object>;
  }

  getAdvertisementsCard(
    searchAdvertisementsModel: SearchAdvertisementsModel
  ): Observable<Array<AdvertisementCardModel>> {
    return this.http.post(
      this.url + `/cards`,
      searchAdvertisementsModel
    ) as Observable<Array<AdvertisementCardModel>>;
  }

  getUserAdvertisementsCards(
    latitude,
    longitude
  ): Observable<Array<AdvertisementCardModel>> {
    if (latitude === undefined || longitude === undefined) {
      return this.http.get(this.url + `/user-advertisements`) as Observable<
        Array<AdvertisementCardModel>
      >;
    } else {
      return this.http.get(
        this.url +
          `/user-advertisements?latitude=${latitude}&longitude=${longitude}`
      ) as Observable<Array<AdvertisementCardModel>>;
    }
  }

  getSearchSuggestions(text): Observable<Array<SearchSuggestionModel>> {
    return this.http.get(
      this.url + `/search-suggestions?text=${text}`
    ) as Observable<Array<SearchSuggestionModel>>;
  }

  getAdvertisementById(advertisementId): Observable<AdvertisementModel> {
    return this.http.get(this.url + `/${advertisementId}`) as Observable<
      AdvertisementModel
    >;
  }
  getAdvertisementByIdForEditing(
    advertisementId
  ): Observable<AdvertisementModel> {
    return this.http.get(
      this.url + '/edit' + `/${advertisementId}`
    ) as Observable<AdvertisementModel>;
  }

  deleteAdvertisement(advertisementId): Observable<boolean> {
    return this.http.delete(this.url + `/${advertisementId}`) as Observable<
      boolean
    >;
  }

  getTrendingAdvertisements(
    searchAdvertisementsModel: SearchAdvertisementsModel
  ): Observable<Array<AdvertisementCardModel>> {
    return this.http.post(
      this.url + '/trending',
      searchAdvertisementsModel
    ) as Observable<Array<AdvertisementCardModel>>;
  }
}
