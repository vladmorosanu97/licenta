import { MapsAPILoader } from '@agm/core';
// import { google } from '@agm/core/services/google-maps-types';
import { Injectable, NgZone } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class MapService {
  zoom = 7;
  latitude = 45.6523093;
  longitude = 25.6102746;
  locationZoom = 10;

  constructor(private mapsAPILoader: MapsAPILoader, private ngZone: NgZone) {}

  setCurrentPosition(callback) {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        position => {
          callback({
            success: true,
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            zoom: this.locationZoom
          });
        },
        error => {
          callback({
            success: false,
            message: error.message
          });
        }
      );
    } else {
      callback({
        success: false,
        message: 'This browser does not support location finder'
      });
    }
  }

  initMap() {
    return {
      zoom: this.zoom,
      longitude: this.longitude,
      latitude: this.latitude
    };
  }

  convertGeolocation(longitude, latitude, locationNameCallBack) {
    const geocoder = new google.maps.Geocoder();

    geocoder.geocode(
      { location: { lat: latitude, lng: longitude } },
      (results, status) => {
        if (results && results.length > 0) {
          locationNameCallBack({
            success: true,
            locationName: results[0].formatted_address
          });
        } else if (status === google.maps.GeocoderStatus.OVER_QUERY_LIMIT) {
          locationNameCallBack({
            success: false,
            message: 'You are sending too many requests per second',
            status: 'OVER_QUERY_LIMIT'
          });
        } else {
          locationNameCallBack({
            success: false,
            message: 'No results found',
            status: 'OK'
          });
        }
      }
    );
  }

  searchLocation(searchElementRef, locationCallBack) {
    this.mapsAPILoader.load().then(() => {
      const autocomplete = new google.maps.places.Autocomplete(
        searchElementRef.nativeElement,
        {
          types: ['geocode']
        }
      );
      autocomplete.addListener('place_changed', () => {
        this.ngZone.run(() => {
          let place = autocomplete.getPlace();

          if (place.geometry === undefined || place.geometry === null) {
            locationCallBack({
              success: false,
              message: 'Place geometry undefined'
            });
            return;
          }

          locationCallBack({
            success: true,
            locationName: place.formatted_address,
            latitude: place.geometry.location.lat(),
            longitude: place.geometry.location.lng(),
            zoom: this.locationZoom
          });
        });
      });
    });
  }

  calculateDistance(lat1, lon1, lat2, lon2): number {
    const coordinate1 = new google.maps.LatLng(lat1, lon1);
    const coordinate2 = new google.maps.LatLng(lat2, lon2);
    return (
      google.maps.geometry.spherical.computeDistanceBetween(
        coordinate1,
        coordinate2
      ) / 1000
    );
  }
}
