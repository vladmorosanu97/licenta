import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import CategoryModel from '../shared/models/category-model';
import { HttpClient } from '@angular/common/http';

const API_URL = `${environment.apiEndpoint}/categories`;
@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  private url: string;
  constructor(private http: HttpClient) {
    this.url = API_URL;
  }

  getCategories(): Observable<Array<CategoryModel>> {
    return this.http.get(this.url) as Observable<Array<CategoryModel>>;
  }
}
