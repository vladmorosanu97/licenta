import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { SettingsComponent } from './pages/settings/settings.component';
import { IsAuthenticatedGuard } from 'src/app/core/guards/is-authenticated.guard';
import { EditPresentationComponent } from '../user/pages/edit-presentation/edit-presentation.component';
import { EditProfileComponent } from './components/edit-profile/edit-profile.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { UserLocationComponent } from './components/user-location/user-location.component';
import { NotificationsComponent } from './components/notifications/notifications.component';

const routes: Routes = [
  {
    path: 'settings',
    component: SettingsComponent,
    canActivate: [IsAuthenticatedGuard],
    children: [
      { path: 'profile', component: EditProfileComponent },
      { path: 'change-password', component: ChangePasswordComponent },
      { path: 'notifications', component: NotificationsComponent },
      { path: 'location', component: UserLocationComponent }
    ]
  }
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(routes)]
})
export class SettingsRoutingModule {}
