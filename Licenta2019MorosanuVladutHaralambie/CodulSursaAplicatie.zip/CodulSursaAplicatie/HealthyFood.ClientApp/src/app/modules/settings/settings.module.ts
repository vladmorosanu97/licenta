import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SettingsComponent } from './pages/settings/settings.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { SettingsRoutingModule } from './settings-routing.module';
import { EditProfileComponent } from './components/edit-profile/edit-profile.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { UserLocationComponent } from './components/user-location/user-location.component';
import { NotificationsComponent } from './components/notifications/notifications.component';
import { CoreModule } from 'src/app/core/core.module';

@NgModule({
  declarations: [
    SettingsComponent,
    EditProfileComponent,
    ChangePasswordComponent,
    UserLocationComponent,
    NotificationsComponent
  ],
  imports: [CoreModule, SharedModule, CommonModule, SettingsRoutingModule]
})
export class SettingsModule {}
