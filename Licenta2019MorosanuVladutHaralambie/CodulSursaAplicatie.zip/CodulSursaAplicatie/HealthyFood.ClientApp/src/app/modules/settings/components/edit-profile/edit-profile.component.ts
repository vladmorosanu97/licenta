import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { CommonMethods } from 'src/app/shared/common.methods';
import { debounceTime } from 'rxjs/operators';
import RegisterUserModel from 'src/app/shared/models/register-user-model';
import UserModel from 'src/app/shared/models/user-model';
import { AuthService } from 'src/app/services/auth.service';
import ImageModel from 'src/app/shared/models/image-model';
import { Observable, Observer } from 'rxjs';
import { NzMessageService, NzNotificationService } from 'ng-zorro-antd';
import { DomSanitizer } from '@angular/platform-browser';
import { UserService } from 'src/app/services/user.service';
import UpdateUserModel from 'src/app/shared/models/update-user-model';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss']
})
export class EditProfileComponent implements OnInit {
  updateProfile: FormGroup;

  formValidation = {
    email: 'normal',
    lastName: 'normal',
    firstName: 'normal',
    phoneNumber: 'normal'
  };
  isFetchingUpdateProfile = false;
  formError: string;
  userProfile: UserModel;
  image: ImageModel = new ImageModel();
  avatarUrl: any;
  constructor(
    private msg: NzMessageService,
    private authService: AuthService,
    private sanitizer: DomSanitizer,
    private userService: UserService,
    private notification: NzNotificationService
  ) {}

  ngOnInit() {
    this.userProfile = this.authService.getUserProfile();
    this.updateProfile = new FormGroup({
      firstName: new FormControl(this.userProfile.firstName),
      lastName: new FormControl(this.userProfile.lastName),
      email: new FormControl(this.userProfile.email),
      phoneNumber: new FormControl(this.userProfile.phoneNumber)
    });

    this.avatarUrl =
      this.userProfile.avatarUrl.length > 0 ? this.userProfile.avatarUrl : null;

    this.image.imagePath = this.avatarUrl;
    this.initFormControls();
  }

  changeAvatarUrl() {
    this.avatarUrl = this.sanitizer.bypassSecurityTrustUrl(
      `${this.image.base64}`
    );
  }

  submitForm() {
    if (!this.validateFormOnSubmit()) {
      return false;
    }
    const user = new UpdateUserModel();
    user.firstName = this.updateProfile.get('firstName').value;
    user.lastName = this.updateProfile.get('lastName').value;
    user.email = this.updateProfile.get('email').value;
    user.phoneNumber = this.updateProfile.get('phoneNumber').value;
    user.avatar = this.image;
    this.isFetchingUpdateProfile = true;
    this.formError = '';

    this.userService.updateUser(user).subscribe(
      () => {
        this.isFetchingUpdateProfile = false;
        this.notification.blank(
          'Profile updated successfully',
          'The image has been updated successfully'
        );

        this.authService
          .refreshToken()
          .then(() => {
            this.authService.setLoginTokenEndpoint();
            this.authService.isLoggedIn();
          })
          .catch(error => {
            this.authService.setLoginTokenEndpoint();
            this.authService.isLoggedIn();
          });
      },
      error => {
        this.formError = error.error;
        this.isFetchingUpdateProfile = false;
      }
    );
  }

  initFormControls() {
    const firstNameField = this.updateProfile.get('firstName');
    firstNameField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0) {
        firstNameField.setErrors({ required: true });
        this.formValidation.firstName = 'error';
      } else {
        firstNameField.setErrors(null);
        this.formValidation.firstName = 'normal';
      }
    });
    firstNameField.valueChanges.pipe().subscribe(value => {
      this.formValidation.firstName = 'normal';
    });

    const lastNameField = this.updateProfile.get('lastName');
    lastNameField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0) {
        lastNameField.setErrors({ required: true });
        this.formValidation.lastName = 'error';
      } else {
        lastNameField.setErrors(null);
        this.formValidation.lastName = 'normal';
      }
    });
    lastNameField.valueChanges.pipe().subscribe(value => {
      this.formValidation.lastName = 'normal';
    });

    const emailField = this.updateProfile.get('email');
    emailField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0) {
        emailField.setErrors({ required: true });
        this.formValidation.email = 'error';
      } else if (value.match(/\S+@\S+\.\S+/) === null) {
        emailField.setErrors({ invalidEmail: true });
        this.formValidation.email = 'error';
      } else if (value !== this.userProfile.email) {
        this.formValidation.email = 'validating';
        this.userService.validateEmail(value).subscribe(
          () => {
            this.formValidation.email = 'normal';
            emailField.setErrors(null);
          },
          error => {
            if (error.status == 400) {
              emailField.setErrors({ alreadyExists: true });
              this.formValidation.email = 'error';
            }
          }
        );
      }
    });
    emailField.valueChanges.pipe().subscribe(value => {
      this.formValidation.email = 'normal';
    });

    const phoneNumberField = this.updateProfile.get('phoneNumber');
    phoneNumberField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0) {
        phoneNumberField.setErrors({ required: true });
        this.formValidation.phoneNumber = 'error';
      } else if (value.length > 0) {
        phoneNumberField.setErrors(null);
        this.formValidation.phoneNumber = 'normal';
      }
    });
    phoneNumberField.valueChanges.subscribe(value => {
      const reg = /^-?([0-9][0-9]*)(\.[0-9]*)?$/;
      if (
        (!isNaN(+value) && reg.test(value)) ||
        value === '' ||
        value === '-'
      ) {
      } else {
        this.updateProfile.get('phoneNumber').setValue('');
      }
      this.formValidation.phoneNumber = 'normal';
    });
  }

  validateFormOnSubmit() {
    CommonMethods.markFormGroupTouchedAndDirty(this.updateProfile);

    if (!this.updateProfile.get('email').valid) {
      this.formValidation.email = 'error';
    }

    if (!this.updateProfile.get('lastName').valid) {
      this.formValidation.lastName = 'error';
    }

    if (!this.updateProfile.get('firstName').valid) {
      this.formValidation.firstName = 'error';
    }
    if (!this.updateProfile.valid) {
      return false;
    }
    return true;
  }

  beforeUpload = (event: any) => {
    new Observable((observer: Observer<boolean>) => {
      let files: Array<File>;
      if (event.target.files && event.target.files.length > 0) {
        files = event.target.files;
        Array.prototype.forEach.call(files, (file: File, index) => {
          const isJPGorPNG =
            file.type === 'image/jpeg' || file.type === 'image/png';
          if (!isJPGorPNG) {
            this.msg.error('You can only upload JPG or file!');
            observer.complete();
            return;
          }

          const isLt5M = file.size / 1024 / 1024 < 5;
          if (!isLt5M) {
            this.msg.error('Image must be smaller than  5MB!');
            observer.complete();
            return;
          }

          CommonMethods.getBase64(file, base64 => {
            this.image = {
              imageId: index,
              name: file.name,
              base64,
              imagePath: null,
              guidPathName: null
            };
            this.changeAvatarUrl();
          });

          observer.next(isJPGorPNG && isLt5M);
          observer.complete();
        });
      }
    }).subscribe(() => {});
  };

  deleteAvatar() {
    this.avatarUrl = null;
    this.image.imagePath = null;
  }
}
