import {
  Component,
  OnInit,
  NgZone,
  ElementRef,
  ViewChild
} from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { MapService } from 'src/app/services/map.service';
import { debounceTime } from 'rxjs/operators';
import { UserService } from 'src/app/services/user.service';
import { CommonMethods } from 'src/app/shared/common.methods';
import UserLocationsModel from 'src/app/shared/models/user-locations-model';
import { NzNotificationService } from 'ng-zorro-antd';

@Component({
  selector: 'app-user-location',
  templateUrl: './user-location.component.html',
  styleUrls: ['./user-location.component.scss']
})
export class UserLocationComponent implements OnInit {
  latitude: number;
  longitude: number;
  currentLatitudeMarker: number;
  currentLongitudeMarker: number;

  homeLatitudeMarker: number;
  homeLongitudeMarker: number;

  zoom: number;
  updateLocationForm: FormGroup;
  formValidation = {
    currentLocationName: 'normal',
    homeLocationName: 'normal',
    updateCurrentLocation: 'normal'
  };

  geoLocationError = false;
  currentLocationName = '';
  homeLocationName = '';
  convertCoordinatesError: boolean;
  tooManyRequestsError: boolean;

  isFetchingCurrentPosition = false;
  isFetchingHomeDeliveryPosition = false;
  isFetchingUpdateLocation = false;
  formError = '';

  @ViewChild('searchCurrentLocation')
  public searchCurrentLocationElementRef: ElementRef;

  @ViewChild('searchHomeDeliveryLocation')
  public searchHomeDeliveryLocationElementRef: ElementRef;
  constructor(
    private mapService: MapService,
    private zone: NgZone,
    private userService: UserService,
    private notification: NzNotificationService
  ) {}

  ngOnInit() {
    this.updateLocationForm = new FormGroup({
      currentLocationName: new FormControl(''),
      homeLocationName: new FormControl(''),
      updateCurrentLocation: new FormControl(false)
    });
    this.resetCoordinates();
    this.initFormControls();
    this.initSearchCurrentLocation();
    this.initSearchHomeDeliveryLocation();

    this.userService.getSavedLocations().subscribe(data => {
      this.updateLocationForm
        .get('currentLocationName')
        .setValue(data.locationName);
      this.currentLocationName = data.locationName;
      this.currentLatitudeMarker = data.latitude;
      this.currentLongitudeMarker = data.longitude;

      this.updateLocationForm
        .get('homeLocationName')
        .setValue(data.homeLocationName);
      this.homeLocationName = data.homeLocationName;
      this.homeLatitudeMarker = data.homeLatitude;
      this.homeLongitudeMarker = data.homeLongitude;

      this.updateLocationForm
        .get('updateCurrentLocation')
        .setValue(data.automaticallyUpdateLocation);
    });
  }

  initSearchCurrentLocation() {
    const locationCallBack = response => {
      if (response.success) {
        this.currentLocationName = response.locationName;
        this.currentLatitudeMarker = response.latitude;
        this.currentLongitudeMarker = response.longitude;
      }
    };
    this.mapService.searchLocation(
      this.searchCurrentLocationElementRef,
      locationCallBack
    );
  }

  initSearchHomeDeliveryLocation() {
    const locationCallBack = response => {
      if (response.success) {
        this.homeLocationName = response.locationName;
        this.homeLatitudeMarker = response.latitude;
        this.homeLongitudeMarker = response.longitude;
      }
    };
    this.mapService.searchLocation(
      this.searchHomeDeliveryLocationElementRef,
      locationCallBack
    );
  }

  resetCoordinates() {
    const mapSettings = this.mapService.initMap();
    this.zoom = mapSettings.zoom;
    this.latitude = mapSettings.latitude;
    this.longitude = mapSettings.longitude;
  }

  getCurrentPositionForLocation() {
    this.isFetchingCurrentPosition = true;
    const coordinatesCallback = value => {
      if (value.success) {
        this.geoLocationError = false;
        this.latitude = value.latitude + Math.random() * 0.00000001;
        this.longitude = value.longitude + Math.random() * 0.00000001;

        this.currentLatitudeMarker = value.latitude;
        this.currentLongitudeMarker = value.longitude;
        this.zoom = value.zoom;
        this.convertCurrentGeolocation();
        this.isFetchingCurrentPosition = false;
      } else {
        this.geoLocationError = true;
        this.isFetchingCurrentPosition = false;
      }
      this.zone.run(() => {});
    };
    this.mapService.setCurrentPosition(coordinatesCallback);
  }

  getCurrentPositionForHomeDeliveryLocation() {
    this.isFetchingHomeDeliveryPosition = true;
    const coordinatesCallback = value => {
      if (value.success) {
        this.geoLocationError = false;
        this.latitude = value.latitude + Math.random() * 0.00000001;
        this.longitude = value.longitude + Math.random() * 0.00000001;

        this.homeLatitudeMarker = value.latitude;
        this.homeLongitudeMarker = value.longitude;
        this.zoom = value.zoom;
        this.convertHomeGeolocation();
        this.isFetchingHomeDeliveryPosition = false;
      } else {
        this.geoLocationError = true;
        this.isFetchingHomeDeliveryPosition = false;
      }
      this.zone.run(() => {});
    };
    this.mapService.setCurrentPosition(coordinatesCallback);
  }

  onClearCurrentLocation() {
    this.currentLocationName = '';
    this.updateLocationForm.get('currentLocationName').setValue('');
    this.currentLatitudeMarker = null;
    this.currentLongitudeMarker = null;
    this.longitude = this.homeLongitudeMarker;
    this.latitude = this.homeLatitudeMarker;
  }

  onClearHomeLocation() {
    this.homeLocationName = '';
    this.updateLocationForm.get('homeLocationName').setValue('');
    this.homeLatitudeMarker = null;
    this.homeLongitudeMarker = null;
    this.longitude = this.currentLongitudeMarker;
    this.latitude = this.currentLatitudeMarker;
  }

  convertCurrentGeolocation() {
    const locationNameCallBack = response => {
      if (response.success) {
        this.convertCoordinatesError = false;
        this.tooManyRequestsError = false;
        this.currentLocationName = response.locationName;
        this.updateLocationForm.get('currentLocationName').markAsDirty();
        this.updateLocationForm
          .get('currentLocationName')
          .setValue(response.locationName);
      } else if (!response.success && response.status === 'OVER_QUERY_LIMIT') {
        this.tooManyRequestsError = true;
      } else {
        this.convertCoordinatesError = true;
        this.currentLocationName = '';
        this.updateLocationForm.get('currentLocationName').markAsDirty();
        this.updateLocationForm
          .get('currentLocationName')
          .setValue(response.locationName);
      }
      this.zone.run(() => {
        console.log('enabled time travel');
      });
    };
    this.mapService.convertGeolocation(
      this.currentLongitudeMarker,
      this.currentLatitudeMarker,
      locationNameCallBack
    );
  }

  convertHomeGeolocation() {
    const locationNameCallBack = response => {
      if (response.success) {
        this.convertCoordinatesError = false;
        this.tooManyRequestsError = false;
        this.homeLocationName = response.locationName;
        this.updateLocationForm.get('homeLocationName').markAsDirty();
        this.updateLocationForm
          .get('homeLocationName')
          .setValue(response.locationName);
      } else if (!response.success && response.status === 'OVER_QUERY_LIMIT') {
        this.tooManyRequestsError = true;
      } else {
        this.convertCoordinatesError = true;
        this.homeLocationName = '';
        this.updateLocationForm.get('homeLocationName').markAsDirty();
        this.updateLocationForm
          .get('homeLocationName')
          .setValue(response.locationName);
      }
      this.zone.run(() => {
        console.log('enabled time travel');
      });
    };
    this.mapService.convertGeolocation(
      this.homeLongitudeMarker,
      this.homeLatitudeMarker,

      locationNameCallBack
    );
  }

  initFormControls() {
    const currentLocationNameField = this.updateLocationForm.get(
      'currentLocationName'
    );
    currentLocationNameField.valueChanges
      .pipe(debounceTime(1000))
      .subscribe(value => {
        if (value.length === 0 && this.currentLocationName.length === 0) {
          currentLocationNameField.setErrors({ required: true });
          this.formValidation.currentLocationName = 'error';
        } else if (value.length > 0 && this.currentLocationName.length > 0) {
          currentLocationNameField.setErrors(null);
          this.formValidation.currentLocationName = 'normal';
        }
      });
    currentLocationNameField.valueChanges.pipe().subscribe(() => {
      this.formValidation.currentLocationName = 'normal';
    });

    const homeLocationNameField = this.updateLocationForm.get(
      'homeLocationName'
    );
    homeLocationNameField.valueChanges
      .pipe(debounceTime(1000))
      .subscribe(value => {
        if (value.length === 0 && this.homeLocationName.length === 0) {
          homeLocationNameField.setErrors({ required: true });
          this.formValidation.homeLocationName = 'error';
        } else if (value.length > 0 && this.homeLocationName.length > 0) {
          homeLocationNameField.setErrors(null);
          this.formValidation.homeLocationName = 'normal';
          // this.zone.run(() => {});
        }
      });
    homeLocationNameField.valueChanges.pipe().subscribe(() => {
      this.formValidation.homeLocationName = 'normal';
    });
  }

  onChangeHomeLocation(event) {
    this.homeLatitudeMarker = event.coords.lat;
    this.homeLongitudeMarker = event.coords.lng;
    this.convertHomeGeolocation();
  }

  onChangeCurrentLocation(event) {
    this.currentLatitudeMarker = event.coords.lat;
    this.currentLongitudeMarker = event.coords.lng;
    this.convertCurrentGeolocation();
  }

  validateFormOnSubmit() {
    CommonMethods.markFormGroupTouchedAndDirty(this.updateLocationForm);
    if (!this.updateLocationForm.get('currentLocationName').valid) {
      this.formValidation.currentLocationName = 'error';
      return false;
    }
    if (!this.updateLocationForm.get('homeLocationName').valid) {
      this.formValidation.homeLocationName = 'error';
      return false;
    }

    return true;
  }

  submitForm() {
    if (!this.validateFormOnSubmit()) {
      return false;
    }

    const userLocations = new UserLocationsModel();
    userLocations.locationName = this.currentLocationName;
    userLocations.latitude = this.currentLatitudeMarker;
    userLocations.longitude = this.currentLongitudeMarker;

    userLocations.homeLocationName = this.homeLocationName;
    userLocations.homeLatitude = this.homeLatitudeMarker;
    userLocations.homeLongitude = this.homeLongitudeMarker;

    userLocations.automaticallyUpdateLocation = this.updateLocationForm.get(
      'updateCurrentLocation'
    ).value;

    this.isFetchingUpdateLocation = true;
    this.userService.updateSavedLocations(userLocations).subscribe(
      () => {
        this.isFetchingUpdateLocation = false;
        this.formError = '';
        this.notification.blank(
          'The advertisement was successfully updated',
          'You added a new advertisement'
        );
      },
      error => {
        this.isFetchingUpdateLocation = false;
        this.formError = error.error;
      }
    );
  }
}
