import { CommonMethods } from '../../../../shared/common.methods';
import { AuthService } from '../../../../services/auth.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import RegisterUserModel from 'src/app/shared/models/register-user-model';
import { debounceTime } from 'rxjs/operators';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  formError: string;
  formSuccess: string;
  isFetchingRegister: boolean;
  formValidation = {
    confirmPassword: 'normal',
    password: 'normal',
    email: 'normal',
    lastName: 'normal',
    firstName: 'normal'
  };
  constructor(
    private authService: AuthService,
    private router: Router,
    private userService: UserService
  ) {}

  ngOnInit() {
    this.registerForm = new FormGroup({
      firstName: new FormControl(''),
      lastName: new FormControl(''),
      email: new FormControl(''),
      password: new FormControl(''),
      confirmPassword: new FormControl('')
    });

    this.initFormControls();
  }

  submitForm() {
    if (!this.validateFormOnSubmit()) {
      return false;
    }
    const user = new RegisterUserModel();
    user.firstName = this.registerForm.get('firstName').value;
    user.lastName = this.registerForm.get('lastName').value;
    user.email = this.registerForm.get('email').value;
    user.password = this.registerForm.get('password').value;
    this.isFetchingRegister = true;
    this.formError = '';
    this.formSuccess = '';
    this.userService.registerUser(user).subscribe(
      data => {
        this.router.navigate(['authentication/registration-done']);
        this.clearForm();
        this.isFetchingRegister = false;
      },
      error => {
        this.formError = error.error;
        this.isFetchingRegister = false;
      }
    );
  }

  clearForm() {
    this.registerForm.controls.confirmPassword.setValue('');
    this.registerForm.controls.password.setValue('');
    this.registerForm.controls.email.setValue('');
    this.registerForm.controls.lastName.setValue('');
    this.registerForm.controls.firstName.setValue('');
  }

  initFormControls() {
    const firstNameField = this.registerForm.get('firstName');
    firstNameField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0) {
        firstNameField.setErrors({ required: true });
        this.formValidation.firstName = 'error';
      } else {
        firstNameField.setErrors(null);
        this.formValidation.firstName = 'success';
      }
    });
    firstNameField.valueChanges.pipe().subscribe(value => {
      this.formValidation.firstName = 'normal';
    });

    const lastNameField = this.registerForm.get('lastName');
    lastNameField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0) {
        lastNameField.setErrors({ required: true });
        this.formValidation.lastName = 'error';
      } else {
        lastNameField.setErrors(null);
        this.formValidation.lastName = 'success';
      }
    });
    lastNameField.valueChanges.pipe().subscribe(value => {
      this.formValidation.lastName = 'normal';
    });

    const emailField = this.registerForm.get('email');
    emailField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0) {
        emailField.setErrors({ required: true });
        this.formValidation.email = 'error';
      } else if (value.match(/\S+@\S+\.\S+/) === null) {
        emailField.setErrors({ invalidEmail: true });
        this.formValidation.email = 'error';
      } else {
        this.formValidation.email = 'validating';
        this.userService.validateEmail(value).subscribe(
          () => {
            this.formValidation.email = 'success';
            emailField.setErrors(null);
          },
          error => {
            if (error.status == 400) {
              emailField.setErrors({ alreadyExists: true });
              this.formValidation.email = 'error';
            }
          }
        );
      }
    });
    emailField.valueChanges.pipe().subscribe(value => {
      this.formValidation.email = 'normal';
    });

    const passwordField = this.registerForm.get('password');
    passwordField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length < 8 && value.length > 0) {
        passwordField.setErrors({ minLength: true });
        this.formValidation.password = 'error';
      } else if (value.length === 0) {
        passwordField.setErrors({ required: true });
        this.formValidation.password = 'error';
      } else {
        passwordField.setErrors(null);
        this.formValidation.password = 'success';
      }
    });
    passwordField.valueChanges.pipe().subscribe(value => {
      this.formValidation.password = 'normal';
    });

    const confirmPasswordField = this.registerForm.get('confirmPassword');
    confirmPasswordField.valueChanges
      .pipe(debounceTime(1000))
      .subscribe(value => {
        if (value.length === 0) {
          confirmPasswordField.setErrors({ required: true });
          this.formValidation.confirmPassword = 'error';
        } else if (value.length < 8 && value.length > 0) {
          confirmPasswordField.setErrors({ minLength: true });
          this.formValidation.confirmPassword = 'error';
        } else if (
          passwordField.value.length > 0 &&
          passwordField.value !== value
        ) {
          confirmPasswordField.setErrors({ invalidPassword: true });
          this.formValidation.confirmPassword = 'error';
        } else {
          confirmPasswordField.setErrors(null);
          this.formValidation.confirmPassword = 'success';
        }
      });
    confirmPasswordField.valueChanges.pipe().subscribe(value => {
      this.formValidation.confirmPassword = 'normal';
    });
  }

  validateFormOnSubmit() {
    CommonMethods.markFormGroupTouched(this.registerForm);
    if (!this.registerForm.get('confirmPassword').valid) {
      this.formValidation.confirmPassword = 'error';
    }
    if (!this.registerForm.get('password').valid) {
      this.formValidation.password = 'error';
    }

    if (!this.registerForm.get('email').valid) {
      this.formValidation.email = 'error';
    }

    if (!this.registerForm.get('lastName').valid) {
      this.formValidation.lastName = 'error';
    }

    if (!this.registerForm.get('firstName').valid) {
      this.formValidation.firstName = 'error';
    }
    if (!this.registerForm.valid) {
      return false;
    }
    return true;
  }
}
