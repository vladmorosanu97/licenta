import { AuthService } from '../../../../services/auth.service';
import { CommonMethods } from '../../../../shared/common.methods';
import { MapService } from '../../../../services/map.service';
import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  NgZone,
  AfterViewInit,
  AfterContentInit
} from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MapsAPILoader } from '@agm/core';
import {} from 'googlemaps';
import { ActivatedRoute, Router } from '@angular/router';
import ConfirmAccountModel from 'src/app/shared/models/confirm-account-model';
import { debounceTime } from 'rxjs/operators';
import { NzNotificationService } from 'ng-zorro-antd';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-confirm-account',
  templateUrl: './confirm-account.component.html',
  styleUrls: ['./confirm-account.component.scss']
})
export class ConfirmAccountComponent implements OnInit {
  radioValue: string;
  confirmAccountForm: FormGroup;
  title = 'My first AGM project';
  latitude: number;
  longitude: number;
  zoom: number;
  geoLocationError = false;
  convertCoordinatesError = false;
  tokenError = false;
  confirmAccountErrorMessage = '';
  locationName = '';
  formValidation = {
    userRole: 'normal',
    locationName: 'normal'
  };
  isFetchingSubmit: boolean;

  @ViewChild('search')
  public searchElementRef: ElementRef;

  constructor(
    private mapService: MapService,
    private route: ActivatedRoute,
    private authService: AuthService,
    private router: Router,
    private notification: NzNotificationService,
    private userService: UserService
  ) {
    console.log(this.route.snapshot.params.token);
  }

  ngOnInit() {
    this.confirmAccountForm = new FormGroup({
      userRole: new FormControl(null, [Validators.required]),
      locationName: new FormControl('')
    });
    this.initFormControls();

    this.resetCoordinates();

    this.initCurrentPosition();
    this.initSearchLocation();
  }

  initFormControls() {
    const locationNameField = this.confirmAccountForm.get('locationName');
    locationNameField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0 && this.locationName.length === 0) {
        locationNameField.setErrors({ required: true });
        this.formValidation.locationName = 'error';
      } else {
        locationNameField.setErrors(null);
        this.formValidation.locationName = 'success';
      }
    });
    locationNameField.valueChanges.pipe().subscribe(value => {
      this.formValidation.locationName = 'normal';
    });
  }

  initSearchLocation() {
    const locationCallBack = response => {
      if (response.success) {
        this.locationName = response.locationName;
        this.latitude = response.latitude;
        this.longitude = response.longitude;
      }
    };
    this.mapService.searchLocation(this.searchElementRef, locationCallBack);
  }

  submitForm() {
    this.tokenError = false;
    this.confirmAccountErrorMessage = '';
    if (!this.validateFormOnSubmit()) {
      return false;
    }
    const token = this.route.snapshot.queryParamMap.get('token');
    if (token === undefined || token === null || token.length === 0) {
      this.tokenError = true;
      return;
    }

    const confirmAccount = new ConfirmAccountModel();
    confirmAccount.token = token;
    confirmAccount.locationName = this.locationName;
    confirmAccount.longitude = this.longitude;
    confirmAccount.latitude = this.latitude;
    confirmAccount.userRole = this.confirmAccountForm.get('userRole').value;

    this.isFetchingSubmit = true;
    this.userService.confirmAccount(confirmAccount).subscribe(
      data => {
        this.notification.blank(
          'Account confirmed successfully',
          'You can  log in now'
        );
        this.router.navigate(['/authentication/login']);
        this.isFetchingSubmit = false;
      },
      error => {
        this.confirmAccountErrorMessage = error.error;
        this.isFetchingSubmit = false;
      }
    );
  }

  initCurrentPosition() {
    const coordinatesCallback = value => {
      if (value.success) {
        this.geoLocationError = false;
        this.latitude = value.latitude;
        this.longitude = value.longitude;
        this.zoom = value.zoom;
        this.convertGeolocation();
      } else {
        console.error(value);
        this.geoLocationError = true;
      }
    };
    this.mapService.setCurrentPosition(coordinatesCallback);
  }

  convertGeolocation() {
    const locationNameCallBack = response => {
      if (response.success) {
        this.convertCoordinatesError = false;
        this.locationName = response.locationName;
        this.confirmAccountForm.get('locationName').markAsDirty();
        this.confirmAccountForm
          .get('locationName')
          .setValue(response.locationName);
      } else {
        this.convertCoordinatesError = true;
      }
    };
    this.mapService.convertGeolocation(
      this.longitude,
      this.latitude,
      locationNameCallBack
    );
  }

  onClearLocation() {
    this.locationName = '';
    this.confirmAccountForm.get('locationName').setValue('');
    this.resetCoordinates();
  }

  resetCoordinates() {
    const mapSettings = this.mapService.initMap();
    this.zoom = mapSettings.zoom;
    this.latitude = mapSettings.latitude;
    this.longitude = mapSettings.longitude;
  }

  validateFormOnSubmit() {
    CommonMethods.markFormGroupTouched(this.confirmAccountForm);
    if (!this.confirmAccountForm.get('locationName').valid) {
      this.formValidation.locationName = 'error';
    }
    if (!this.confirmAccountForm.get('userRole').valid) {
      this.formValidation.userRole = 'error';
    }
    if (!this.confirmAccountForm.valid) {
      return false;
    }
    return true;
  }
}
