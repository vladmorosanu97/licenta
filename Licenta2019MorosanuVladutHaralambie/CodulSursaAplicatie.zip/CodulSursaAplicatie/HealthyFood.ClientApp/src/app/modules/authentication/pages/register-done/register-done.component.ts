import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-done',
  templateUrl: './register-done.component.html',
  styleUrls: ['./register-done.component.scss']
})
export class RegisterDoneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
