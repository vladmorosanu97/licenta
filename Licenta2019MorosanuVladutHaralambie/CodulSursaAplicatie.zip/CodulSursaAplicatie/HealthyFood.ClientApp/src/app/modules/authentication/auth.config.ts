import { AuthConfig } from 'angular-oauth2-oidc';
import { environment } from '../../../environments/environment';

export const authConfig: AuthConfig = {
  // Url of the Identity Provider
  issuer: `${environment.clientEndpoint}`,

  // URL of the SPA to redirect the user to after login
  redirectUri: `${environment.clientEndpoint}/home`,

  // The SPA's id. The SPA is registerd with this id at the auth-server
  clientId: 'HealthyFood',

  logoutUrl: `${environment.clientEndpoint}/login`,

  // set the scope for the permissions the client should request
  // The first three are defined by OIDC. The 4th is a usecase-specific one
  scope: 'authorization healthyfood',

  responseType: 'id_token token',

  tokenEndpoint: `${environment.apiEndpoint}/accounts/login/`,

  requireHttps: false,

  userinfoEndpoint: `${environment.apiEndpoint}/accounts/user`,

  dummyClientSecret: 'd1a91a4f-5d16-4db3-cd22-92a31ccfbda7',

  oidc: false
};
