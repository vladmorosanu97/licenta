import { Component, OnInit, Input } from '@angular/core';
import AdvertisementCardModel from 'src/app/shared/models/advertisement-card-model';

@Component({
  selector: 'app-advertisement-marker',
  templateUrl: './advertisement-marker.component.html',
  styleUrls: ['./advertisement-marker.component.scss']
})
export class AdvertisementMarkerComponent implements OnInit {
  @Input() advertisementCard: AdvertisementCardModel;
  constructor() {}

  ngOnInit() {}
}
