import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/services/category.service';
import { AdvertisementService } from 'src/app/services/advertisement.service';
import AdvertisementCardModel from 'src/app/shared/models/advertisement-card-model';
import { FormGroup, FormControl } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';
import SearchInputModel from 'src/app/shared/models/search-input-model';
import { MapService } from 'src/app/services/map.service';
import SearchAdvertisementsModel from 'src/app/shared/models/search-advertisements-model';
import CategoryModel from 'src/app/shared/models/category-model';

@Component({
  selector: 'app-trending',
  templateUrl: './trending.component.html',
  styleUrls: ['./trending.component.scss']
})
export class TrendingComponent implements OnInit {
  advertisementsTrending: Array<AdvertisementCardModel>;
  categories: Array<CategoryModel>;

  latitude: number;
  longitude: number;
  latitudeUserMarker: number;
  longitudeUserMarker: number;
  geoLocationError = false;

  searchForm: FormGroup;
  isFetchingAdvertisements = false;

  searchInputModel: SearchInputModel;
  constructor(
    private categoryService: CategoryService,
    private advertisementService: AdvertisementService,
    private mapService: MapService
  ) {}

  ngOnInit() {
    this.searchForm = new FormGroup({
      distance: new FormControl(5),
      maxDistance: new FormControl(10)
    });
    this.getCategories();
    this.getTrendingAdvertisements();
    this.initFormControls();
  }

  getTrendingAdvertisements() {
    const currentCoordinates = value => {
      let latitude: number = null;
      let longitude: number = null;
      if (value.success === true) {
        latitude = value.latitude;
        longitude = value.longitude;
      }
      const distance = this.searchForm.get('distance').value;
      this.isFetchingAdvertisements = true;
      const searchAdvertisementsModel = new SearchAdvertisementsModel();
      searchAdvertisementsModel.latitude = latitude;
      searchAdvertisementsModel.longitude = longitude;
      searchAdvertisementsModel.maxDistance = distance;
      searchAdvertisementsModel.searchText = this.searchInputModel
        ? this.searchInputModel.searchText
        : null;

      this.advertisementService
        .getTrendingAdvertisements(searchAdvertisementsModel)
        .subscribe(
          data => {
            this.advertisementsTrending = data;
            this.isFetchingAdvertisements = false;
            console.log(this.advertisementsTrending);
          },
          () => {
            this.isFetchingAdvertisements = false;
          }
        );
    };
    this.mapService.setCurrentPosition(currentCoordinates);
  }

  initFormControls() {
    const distanceField = this.searchForm.get('distance');
    distanceField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      this.getTrendingAdvertisements();
    });
  }

  changeMaxDistance(event) {
    this.searchForm.get('maxDistance').setValue(event);
  }

  getCategories() {
    this.categoryService.getCategories().subscribe(data => {
      this.categories = data;
    });
  }
}
