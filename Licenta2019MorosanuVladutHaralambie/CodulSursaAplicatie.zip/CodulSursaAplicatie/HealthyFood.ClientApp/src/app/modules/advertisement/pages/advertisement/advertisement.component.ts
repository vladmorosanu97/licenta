import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MapService } from 'src/app/services/map.service';
import { AdvertisementService } from 'src/app/services/advertisement.service';
import AdvertisementModel from 'src/app/shared/models/advertisement-model';
import { Route, ActivatedRoute } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-advertisement',
  templateUrl: './advertisement.component.html',
  styleUrls: ['./advertisement.component.scss']
})
export class AdvertisementComponent implements OnInit {
  array = [1, 2, 3, 4];

  latitude: number;
  longitude: number;
  latitudeUserMarker: number;
  longitudeUserMarker: number;
  latitudeAdvertisementMarker: number;
  longitudeAdvertisementMarker: number;
  geoLocationError = false;
  advertisement: AdvertisementModel;
  showPhoneNumber = false;
  isFetchingAdvertisement = false;
  userId: number;
  @ViewChild('carousel')
  public carousel: any;
  constructor(
    private mapService: MapService,
    private advertisementService: AdvertisementService,
    private route: ActivatedRoute,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.userId = this.authService.getUserId();

    const initMap = this.mapService.initMap();
    this.latitude = initMap.latitude;
    this.longitude = initMap.longitude;

    this.getCurrentPosition();

    const advertisementId = this.route.snapshot.paramMap.get('advertisementId');
    this.isFetchingAdvertisement = true;
    this.advertisementService.getAdvertisementById(advertisementId).subscribe(
      data => {
        this.advertisement = data;

        this.advertisement.distance = this.mapService.calculateDistance(
          this.latitudeUserMarker,
          this.longitudeUserMarker,
          this.advertisement.latitude,
          this.advertisement.longitude
        );
        this.isFetchingAdvertisement = false;
      },
      error => {
        console.error(error.error);
        this.isFetchingAdvertisement = false;
      }
    );
  }

  getCurrentPosition() {
    const coordinatesCallback = value => {
      if (value.success) {
        this.geoLocationError = false;

        this.latitudeUserMarker = value.latitude;
        this.longitudeUserMarker = value.longitude;
      } else {
        this.geoLocationError = true;
      }
    };
    this.mapService.setCurrentPosition(coordinatesCallback);
  }

  onTogglePhoneNumber() {
    this.showPhoneNumber = true;
  }

  backImage() {
    this.carousel.pre();
  }

  nextImage() {
    this.carousel.next();
  }
}
