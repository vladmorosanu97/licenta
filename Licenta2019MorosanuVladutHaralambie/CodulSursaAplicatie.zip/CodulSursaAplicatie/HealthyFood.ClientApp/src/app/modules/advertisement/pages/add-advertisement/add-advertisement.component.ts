import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  NgZone,
  AfterContentInit
} from '@angular/core';
import { MapService } from 'src/app/services/map.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Observer, Observable } from 'rxjs';
import { NzMessageService, NzNotificationService } from 'ng-zorro-antd';
import { AgmMap } from '@agm/core';
import { debounceTime } from 'rxjs/operators';
import { CategoryService } from 'src/app/services/category.service';
import CategoryModel from 'src/app/shared/models/category-model';
import { CommonMethods } from 'src/app/shared/common.methods';
import ImageModel from 'src/app/shared/models/image-model';
import CreateOrUpdateAdvertisementModel from 'src/app/shared/models/create-or-update-advertisement-model';
import { AdvertisementService } from 'src/app/services/advertisement.service';
import { Router, ActivatedRoute } from '@angular/router';
import { UnitService } from 'src/app/services/unit.service';
import UnitTypeModel from 'src/app/shared/models/unit-type-model';
import ImageCompressor from 'image-compressor.js';
const compressor = new ImageCompressor();
@Component({
  selector: 'app-add-advertisement',
  templateUrl: './add-advertisement.component.html',
  styleUrls: ['./add-advertisement.component.scss']
})
export class AddAdvertisementComponent implements OnInit, AfterContentInit {
  latitude: number;
  longitude: number;
  latitudeMarker: number;
  longitudeMarker: number;
  zoom: number;
  addAdvertisementForm: FormGroup;
  formValidation = {
    title: 'normal',
    category: 'normal',
    phoneNumber: 'normal',
    locationName: 'normal',
    description: 'normal',
    price: 'normal',
    unitType: 'normal'
  };
  fileList: Array<ImageModel> = [];
  categories: Array<CategoryModel>;
  unitTypes: Array<UnitTypeModel>;
  locationName = '';
  geoLocationError = false;
  convertCoordinatesError: boolean;
  tooManyRequestsError: boolean;
  isFetchingCurrentPosition = false;
  isFetchingCategories = false;
  fetchingCategoriesError = false;

  isFetchingUnitTypes = false;
  fetchingUnitTypesError = false;

  isFetchingAdvertisement = false;
  fetchingAdvertisementError = '';
  isCompressingFile = false;

  isFetchingAdvertisementForEditing = false;
  @ViewChild(AgmMap)
  public agmMap: AgmMap;
  @ViewChild('search')
  public searchElementRef: ElementRef;

  constructor(
    private mapService: MapService,
    private msg: NzMessageService,
    private zone: NgZone,
    private categoryService: CategoryService,
    private advertisementService: AdvertisementService,
    private router: Router,
    private notification: NzNotificationService,
    private unitService: UnitService,
    private route: ActivatedRoute
  ) {}

  ngAfterContentInit(): void {
    this.initSearchLocation();
  }
  ngOnInit() {
    this.addAdvertisementForm = new FormGroup({
      advertisementId: new FormControl(null),
      title: new FormControl(''),
      category: new FormControl(null),
      phoneNumber: new FormControl(''),
      locationName: new FormControl(''),
      description: new FormControl(''),
      price: new FormControl(''),
      unitType: new FormControl(null)
    });
    this.resetCoordinates();
    this.getCurrentPositionWithoutMarker();
    this.initFormControls();

    this.isFetchingCategories = true;
    this.categoryService.getCategories().subscribe(
      data => {
        this.fetchingCategoriesError = false;
        this.categories = data;
        this.isFetchingCategories = false;
      },
      () => {
        this.fetchingCategoriesError = true;
        this.isFetchingCategories = false;
      }
    );

    this.isFetchingUnitTypes = true;
    this.unitService.getUnitTypes().subscribe(
      data => {
        this.fetchingUnitTypesError = false;
        this.unitTypes = data;
        this.isFetchingUnitTypes = false;
      },
      () => {
        this.fetchingUnitTypesError = true;
        this.isFetchingUnitTypes = false;
      }
    );

    const advertisementId = this.route.snapshot.paramMap.get('advertisementId');
    if (advertisementId !== null) {
      this.updateFormForEdit(advertisementId);
    }
  }

  updateFormForEdit(advertisementId) {
    this.isFetchingAdvertisementForEditing = true;
    this.advertisementService
      .getAdvertisementByIdForEditing(advertisementId)
      .subscribe(
        data => {
          this.addAdvertisementForm
            .get('advertisementId')
            .setValue(data.advertisementId);
          this.addAdvertisementForm.get('title').setValue(data.title);
          this.addAdvertisementForm.get('category').setValue(data.categoryId);
          this.addAdvertisementForm
            .get('phoneNumber')
            .setValue(data.phoneNumber);
          this.addAdvertisementForm
            .get('locationName')
            .setValue(data.locationName);
          this.addAdvertisementForm
            .get('description')
            .setValue(data.description);
          this.addAdvertisementForm.get('price').setValue(data.price);
          this.addAdvertisementForm.get('unitType').setValue(data.unitTypeId);
          this.latitudeMarker = data.latitude;
          this.longitudeMarker = data.longitude;
          this.latitude = data.latitude;
          this.longitude = data.longitude;
          this.locationName = data.locationName;

          data.advertisementImages.forEach(element => {
            this.fileList.push({
              imageId: element.advertisementImageId,
              name: element.guidFileName,
              base64: null,
              imagePath: element.imagePath,
              guidPathName: element.guidFileName
            });
          });
          CommonMethods.markFormGroupTouchedAndDirty(this.addAdvertisementForm);
          this.isFetchingAdvertisementForEditing = false;
        },
        error => {
          this.isFetchingAdvertisementForEditing = false;
          console.log(error);
        }
      );
  }

  resetCoordinates() {
    const mapSettings = this.mapService.initMap();
    this.zoom = mapSettings.zoom;
    this.latitude = mapSettings.latitude;
    this.longitude = mapSettings.longitude;
  }

  addMarker(lat, long) {
    this.latitudeMarker = lat;
    this.longitudeMarker = long;
    this.convertGeolocation();
  }

  beforeUpload = (event: any) => {
    new Observable((observer: Observer<boolean>) => {
      let files: Array<File>;
      if (event.target.files && event.target.files.length > 0) {
        files = event.target.files;
        Array.prototype.forEach.call(files, (file: File, index) => {
          if (index + this.fileList.length > 4) {
            this.msg.error('You can only upload maxim 5 images!');
            observer.complete();
            return;
          }

          const isJPGorPNG =
            file.type === 'image/jpeg' || file.type === 'image/png';
          if (!isJPGorPNG) {
            this.msg.error('You can only upload JPG or file!');
            observer.complete();
            return;
          }

          const isLt5M = file.size / 1024 / 1024 < 5;
          if (!isLt5M) {
            this.msg.error('Image must be smaller than 5MB!');
            observer.complete();
            return;
          }

          CommonMethods.getBase64(file, base64 => {
            this.fileList.push({
              imageId: index,
              name: file.name,
              base64,
              imagePath: null,
              guidPathName: null
            });
          });

          observer.next(isJPGorPNG && isLt5M);
          observer.complete();
        });
      }
    }).subscribe(() => {});
  };

  removeImage(file) {
    this.fileList = this.fileList.filter(
      element => element.imageId !== file.imageId
    );
  }

  initSearchLocation() {
    const locationCallBack = response => {
      if (response.success) {
        this.locationName = response.locationName;
        this.latitudeMarker = response.latitude;
        this.longitudeMarker = response.longitude;
        this.longitude = response.longitude;
        this.latitude = response.latitude;
      }
    };
    this.mapService.searchLocation(this.searchElementRef, locationCallBack);
  }

  getCurrentPosition() {
    this.isFetchingCurrentPosition = true;
    const coordinatesCallback = value => {
      if (value.success) {
        this.geoLocationError = false;
        this.latitude = value.latitude + Math.random() * 0.00000001;
        this.longitude = value.longitude + Math.random() * 0.00000001;

        this.latitudeMarker = value.latitude;
        this.longitudeMarker = value.longitude;
        this.zoom = value.zoom;
        this.convertGeolocation();
        this.isFetchingCurrentPosition = false;
      } else {
        this.geoLocationError = true;
        this.isFetchingCurrentPosition = false;
      }
    };
    this.mapService.setCurrentPosition(coordinatesCallback);
  }

  getCurrentPositionWithoutMarker() {
    const coordinatesCallback = value => {
      if (value.success) {
        this.geoLocationError = false;
        this.latitude = value.latitude + Math.random() * 0.0001;
        this.longitude = value.longitude + Math.random() * 0.0001;

        this.zoom = value.zoom;
        this.convertGeolocation();
      } else {
        console.error(value);
        this.geoLocationError = true;
      }
    };
    this.mapService.setCurrentPosition(coordinatesCallback);
  }

  convertGeolocation() {
    const locationNameCallBack = response => {
      if (response.success) {
        this.convertCoordinatesError = false;
        this.tooManyRequestsError = false;
        this.locationName = response.locationName;
        this.addAdvertisementForm.get('locationName').markAsDirty();
        this.addAdvertisementForm
          .get('locationName')
          .setValue(response.locationName);
      } else if (!response.success && response.status === 'OVER_QUERY_LIMIT') {
        this.tooManyRequestsError = true;
      } else {
        this.convertCoordinatesError = true;
        this.locationName = '';
        this.addAdvertisementForm.get('locationName').markAsDirty();
        this.addAdvertisementForm
          .get('locationName')
          .setValue(response.locationName);
      }
      this.zone.run(() => {
        console.log('enabled time travel');
      });
    };
    this.mapService.convertGeolocation(
      this.longitudeMarker,
      this.latitudeMarker,
      locationNameCallBack
    );
  }

  onClearLocation() {
    this.locationName = '';
    this.addAdvertisementForm.get('locationName').setValue('');
    this.resetCoordinates();
  }

  initFormControls() {
    const locationNameField = this.addAdvertisementForm.get('locationName');
    locationNameField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0 && this.locationName.length === 0) {
        locationNameField.setErrors({ required: true });
        this.formValidation.locationName = 'error';
      } else if (value.length > 0 && this.locationName.length > 0) {
        locationNameField.setErrors(null);
        this.formValidation.locationName = 'normal';
        this.zone.run(() => {});
      }
    });
    locationNameField.valueChanges.pipe().subscribe(() => {
      this.formValidation.locationName = 'normal';
    });

    const descriptionField = this.addAdvertisementForm.get('description');
    descriptionField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0) {
        descriptionField.setErrors({ required: true });
        this.formValidation.description = 'error';
      } else if (value.length > 0) {
        descriptionField.setErrors(null);
        this.formValidation.description = 'normal';
      }
    });
    descriptionField.valueChanges.pipe().subscribe(() => {
      this.formValidation.locationName = 'normal';
    });

    const phoneNumberField = this.addAdvertisementForm.get('phoneNumber');
    phoneNumberField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0) {
        phoneNumberField.setErrors({ required: true });
        this.formValidation.phoneNumber = 'error';
      } else if (value.length > 0) {
        phoneNumberField.setErrors(null);
        this.formValidation.phoneNumber = 'normal';
      }
    });
    phoneNumberField.valueChanges.subscribe(value => {
      const reg = /^-?([0-9][0-9]*)(\.[0-9]*)?$/;
      if (
        (!isNaN(+value) && reg.test(value)) ||
        value === '' ||
        value === '-'
      ) {
      } else {
        this.addAdvertisementForm.get('phoneNumber').setValue('');
      }
      this.formValidation.phoneNumber = 'normal';
    });

    const categoryField = this.addAdvertisementForm.get('category');
    categoryField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value === null) {
        categoryField.setErrors({ required: true });
        this.formValidation.category = 'error';
      } else if (value !== null) {
        categoryField.setErrors(null);
        this.formValidation.category = 'normal';
      }
    });
    categoryField.valueChanges.pipe().subscribe(() => {
      this.formValidation.category = 'normal';
    });

    const titleField = this.addAdvertisementForm.get('title');
    titleField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value.length === 0) {
        titleField.setErrors({ required: true });
        this.formValidation.title = 'error';
      } else if (value.length > 0) {
        titleField.setErrors(null);
        this.formValidation.title = 'normal';
      }
    });
    titleField.valueChanges.pipe().subscribe(() => {
      this.formValidation.title = 'normal';
    });

    const priceField = this.addAdvertisementForm.get('price');
    priceField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value === null) {
        priceField.setErrors({ required: true });
        this.formValidation.price = 'error';
      } else {
        priceField.setErrors(null);
        this.formValidation.price = 'normal';
      }
    });
    priceField.valueChanges.pipe().subscribe(() => {
      this.formValidation.price = 'normal';
    });

    const unitTypeField = this.addAdvertisementForm.get('unitType');
    unitTypeField.valueChanges.pipe(debounceTime(1000)).subscribe(value => {
      if (value === null) {
        unitTypeField.setErrors({ required: true });
        this.formValidation.unitType = 'error';
      } else if (value !== null) {
        unitTypeField.setErrors(null);
        this.formValidation.unitType = 'normal';
      }
    });
    unitTypeField.valueChanges.pipe().subscribe(() => {
      this.formValidation.unitType = 'normal';
    });
  }

  submitForm() {
    if (!this.validateFormOnSubmit()) {
      return false;
    }

    const advertisement = new CreateOrUpdateAdvertisementModel();
    advertisement.advertisementId = this.addAdvertisementForm.get(
      'advertisementId'
    ).value;
    advertisement.title = this.addAdvertisementForm.get('title').value;
    advertisement.categoryId = this.addAdvertisementForm.get('category').value;
    advertisement.phoneNumber = this.addAdvertisementForm.get(
      'phoneNumber'
    ).value;
    advertisement.description = this.addAdvertisementForm.get(
      'description'
    ).value;
    advertisement.locationName = this.locationName;
    advertisement.latitude = this.latitudeMarker;
    advertisement.longitude = this.longitudeMarker;
    advertisement.images = this.fileList;
    advertisement.price = this.addAdvertisementForm.get('price').value;
    advertisement.unitTypeId = this.addAdvertisementForm.get('unitType').value;

    this.isFetchingAdvertisement = true;
    this.fetchingAdvertisementError = '';

    if (advertisement.advertisementId !== null) {
      this.advertisementService.updateAdvertisement(advertisement).subscribe(
        () => {
          this.isFetchingAdvertisement = false;
          this.fetchingAdvertisementError = '';
          this.router.navigate(['/home']);
          this.clearForm();
          this.notification.blank(
            'The advertisement was successfully updated',
            'You added a new advertisement'
          );
        },
        error => {
          this.isFetchingAdvertisement = false;
          this.fetchingAdvertisementError = error.error;
        }
      );
    } else {
      this.advertisementService.createAdvertisement(advertisement).subscribe(
        () => {
          this.isFetchingAdvertisement = false;
          this.fetchingAdvertisementError = '';
          this.router.navigate(['/home']);
          this.clearForm();
          this.notification.blank(
            'New advertisement added successfully',
            'You added a new advertisement'
          );
        },
        error => {
          this.isFetchingAdvertisement = false;
          this.fetchingAdvertisementError = error.error;
        }
      );
    }
  }

  clearForm() {
    CommonMethods.resetForm(this.addAdvertisementForm);
    this.locationName = '';
    this.resetCoordinates();
  }

  validateFormOnSubmit() {
    CommonMethods.markFormGroupTouched(this.addAdvertisementForm);
    if (!this.addAdvertisementForm.get('category').valid) {
      this.formValidation.category = 'error';
      return false;
    }
    if (!this.addAdvertisementForm.get('description').valid) {
      this.formValidation.description = 'error';
      return false;
    }

    if (!this.addAdvertisementForm.get('locationName').valid) {
      this.formValidation.locationName = 'error';
      return false;
    }

    if (!this.addAdvertisementForm.get('phoneNumber').valid) {
      this.formValidation.phoneNumber = 'error';
      return false;
    }

    if (!this.addAdvertisementForm.get('title').valid) {
      this.formValidation.title = 'error';
      return false;
    }

    if (!this.addAdvertisementForm.get('price').valid) {
      this.formValidation.price = 'error';
      return false;
    }

    if (!this.addAdvertisementForm.get('unitType').valid) {
      this.formValidation.unitType = 'error';
      return false;
    }
    return true;
  }
}
