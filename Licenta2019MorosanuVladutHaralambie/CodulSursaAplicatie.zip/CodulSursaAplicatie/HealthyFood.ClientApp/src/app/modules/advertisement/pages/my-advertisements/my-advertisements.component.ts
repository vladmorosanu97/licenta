import { Component, OnInit } from '@angular/core';
import { AdvertisementService } from 'src/app/services/advertisement.service';
import { AdvertisementCardComponent } from '../../components/advertisement-card/advertisement-card.component';
import { MapService } from 'src/app/services/map.service';
import AdvertisementCardModel from 'src/app/shared/models/advertisement-card-model';
import { CategoryService } from 'src/app/services/category.service';
import CategoryModel from 'src/app/shared/models/category-model';
import { NzMessageService } from 'ng-zorro-antd';

@Component({
  selector: 'app-my-advertisements',
  templateUrl: './my-advertisements.component.html',
  styleUrls: ['./my-advertisements.component.scss']
})
export class MyAdvertisementsComponent implements OnInit {
  advertisements: Array<AdvertisementCardModel>;
  categories: Array<CategoryModel>;
  constructor(
    private advertisementService: AdvertisementService,
    private mapService: MapService,
    private categoryService: CategoryService,
    private nzMessageService: NzMessageService
  ) {}
  latitudeUserMarker: number;
  longitudeUserMarker: number;
  geoLocationError = false;
  ngOnInit() {
    this.categoryService.getCategories().subscribe(data => {
      this.categories = data;
    });
    this.getCurrentPosition();
  }

  getUserAdvertisements() {
    this.advertisementService
      .getUserAdvertisementsCards(
        this.latitudeUserMarker,
        this.longitudeUserMarker
      )
      .subscribe(data => {
        this.advertisements = data;
      });
  }

  getCurrentPosition() {
    const coordinatesCallback = value => {
      if (value.success) {
        this.geoLocationError = false;

        this.latitudeUserMarker = value.latitude;
        this.longitudeUserMarker = value.longitude;
        this.getUserAdvertisements();
      } else {
        this.geoLocationError = true;
        this.getUserAdvertisements();
      }
    };
    this.mapService.setCurrentPosition(coordinatesCallback);
  }

  mapAdvertisementByCategoryId(categoryId) {
    return (
      this.advertisements &&
      this.advertisements.filter(a => a.categoryId === categoryId)
    );
  }

  onClickDelete(advertisementId) {
    this.advertisementService.deleteAdvertisement(advertisementId).subscribe(
      () => {
        this.nzMessageService.info('Advertisement deleted successfully');
        this.getUserAdvertisements();
      },
      () => {
        this.nzMessageService.error('Something went wrong. Try again later');
      }
    );
  }
}
