import UserPresentationModel from 'src/app/shared/models/user-presentation-model';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-rating-card',
  templateUrl: './rating-card.component.html',
  styleUrls: ['./rating-card.component.scss']
})
export class RatingCardComponent implements OnInit {
  @Input() userPresentation: UserPresentationModel;
  constructor() {}

  ngOnInit() {}
}
