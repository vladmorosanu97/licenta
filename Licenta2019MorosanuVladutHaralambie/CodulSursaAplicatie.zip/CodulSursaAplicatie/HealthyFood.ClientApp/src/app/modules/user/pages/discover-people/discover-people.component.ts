import { Component, OnInit } from '@angular/core';
import UserCardModel from 'src/app/shared/models/user-card-model';
import { UserService } from 'src/app/services/user.service';
import { HeaderService } from 'src/app/services/header.service';
import SearchUsersModel from 'src/app/shared/models/search-users-model';
import { MapService } from 'src/app/services/map.service';
import RelationshipActionsConstants from 'src/app/shared/constants/relationship-actions-constants';
import { RelationshipService } from 'src/app/services/relationship.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-discover-people',
  templateUrl: './discover-people.component.html',
  styleUrls: ['./discover-people.component.scss']
})
export class DiscoverPeopleComponent implements OnInit {
  users: Array<UserCardModel>;
  latitude: number = null;
  longitude: number = null;
  geoLocationError = false;
  userId: number;
  constructor(
    private userService: UserService,
    private headerService: HeaderService,
    private mapService: MapService,
    private relationshipService: RelationshipService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.userId = this.authService.getUserId();
    this.getCurrentPosition();
    this.headerService.getSearchUsersObserver().subscribe(item => {
      console.log(item);
      this.getUsers(item);
    });
  }

  getCurrentPosition() {
    const coordinatesCallback = value => {
      if (value.success) {
        this.geoLocationError = false;

        this.latitude = value.latitude;
        this.longitude = value.longitude;
      } else {
        this.geoLocationError = true;
      }
      this.getUsers(null);
    };
    this.mapService.setCurrentPosition(coordinatesCallback);
  }

  getUsers(searchText: string) {
    const searchUser = new SearchUsersModel();
    searchUser.latitude = this.latitude;
    searchUser.longitude = this.longitude;
    searchUser.searchText = searchText;
    this.userService.getUsers(searchUser).subscribe(data => {
      this.users = data;
      console.log(data);
    });
  }

  onRelationshipChange(value, userId) {
    if (value === RelationshipActionsConstants.cancelFriendRequest) {
      this.cancelFriendRequest(userId);
    } else if (value === RelationshipActionsConstants.sendFriendRequest) {
      this.sendFriendRequest(userId);
    } else if (value === RelationshipActionsConstants.acceptFriendRequest) {
      this.acceptFriendRequest(userId);
    } else if (value === RelationshipActionsConstants.removeFriend) {
      this.removeFriend(userId);
    } else if (value === RelationshipActionsConstants.removeFriendRequest) {
      this.removeFriendRequest(userId);
    }
  }

  sendFriendRequest(receiverId) {
    this.relationshipService.sendFriendRequest(receiverId).subscribe(
      () => {
        console.log('success');
        this.getUsers(null);
      },
      error => {
        console.log(error);
      }
    );
  }

  cancelFriendRequest(receiverId) {
    this.relationshipService.cancelFriendRequest(receiverId).subscribe(
      () => {
        this.getUsers(null);
      },
      error => {
        console.log(error);
      }
    );
  }

  acceptFriendRequest(senderId) {
    this.relationshipService.acceptFriendRequest(senderId).subscribe(
      () => {
        console.log('success');
        this.getUsers(null);
      },
      error => {
        console.log(error);
      }
    );
  }

  removeFriend(receiverId) {
    this.relationshipService.removeFriend(receiverId).subscribe(
      () => {
        this.getUsers(null);
      },
      error => {
        console.log(error);
      }
    );
  }

  removeFriendRequest(senderId) {
    this.relationshipService.removeFriendRequest(senderId).subscribe(
      () => {
        this.getUsers(null);
      },
      error => {
        console.log(error);
      }
    );
  }
}
