import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PeopleRequestComponent } from './people-request.component';

describe('PeopleRequestComponent', () => {
  let component: PeopleRequestComponent;
  let fixture: ComponentFixture<PeopleRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PeopleRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PeopleRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
