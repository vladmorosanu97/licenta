import { UserRoles } from './../../../../shared/constants/user-roles-constants';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import UserPresentationModel from 'src/app/shared/models/user-presentation-model';
import ImagesPathConstants from 'src/app/shared/constants/images-path-constants';
import ReviewModel from 'src/app/shared/models/review-model';
import UserModel from 'src/app/shared/models/user-model';
import RelationshipStatusConstants from 'src/app/shared/constants/relationship-status-constants';
import RelationshipActionsConstants from 'src/app/shared/constants/relationship-actions-constants';

@Component({
  selector: 'app-client-presentation',
  templateUrl: './client-presentation.component.html',
  styleUrls: ['./client-presentation.component.scss']
})
export class ClientPresentationComponent implements OnInit {
  @Input() userPresentation: UserPresentationModel;
  @Input() reviews: Array<ReviewModel>;
  @Input() currentUser: UserModel;
  bannerUrl: string;
  UserRoles = UserRoles;
  userRoles = UserRoles;
  relationshipConstants = RelationshipStatusConstants;
  @Output() relationshipAction = new EventEmitter<string>();
  constructor() {}

  ngOnInit() {
    this.bannerUrl = ImagesPathConstants.userPresentation;
  }

  cancelFriendRequest() {
    this.relationshipAction.emit(
      RelationshipActionsConstants.cancelFriendRequest
    );
  }

  acceptFriendRequest() {
    this.relationshipAction.emit(
      RelationshipActionsConstants.acceptFriendRequest
    );
  }

  removeFriendRequest() {
    this.relationshipAction.emit(
      RelationshipActionsConstants.removeFriendRequest
    );
  }

  sendFriendRequest() {
    this.relationshipAction.emit(
      RelationshipActionsConstants.sendFriendRequest
    );
  }

  removeFriend() {
    this.relationshipAction.emit(RelationshipActionsConstants.removeFriend);
  }
}
