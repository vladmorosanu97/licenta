import { Component, OnInit, Input } from '@angular/core';
import ReviewModel from 'src/app/shared/models/review-model';

@Component({
  selector: 'app-review-card',
  templateUrl: './review-card.component.html',
  styleUrls: ['./review-card.component.scss']
})
export class ReviewCardComponent implements OnInit {
  isSmallReview = true;
  @Input() review: ReviewModel;
  constructor() {}

  ngOnInit() {}

  clickMoreDetails() {
    this.isSmallReview = false;
  }

  clickLessDetails() {
    this.isSmallReview = true;
  }
}
