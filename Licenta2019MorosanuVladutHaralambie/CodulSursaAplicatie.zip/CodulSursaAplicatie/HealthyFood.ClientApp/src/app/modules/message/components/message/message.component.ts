import { Component, OnInit, Input } from '@angular/core';
import MessageModel from 'src/app/shared/models/message-model';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.scss']
})
export class MessageComponent implements OnInit {
  @Input() message: MessageModel;
  @Input() userId: number;
  dateA = new Date();
  constructor() {}

  ngOnInit() {}
}
