import ChatModel from 'src/app/shared/models/chat-model';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-conversation-card',
  templateUrl: './conversation-card.component.html',
  styleUrls: ['./conversation-card.component.scss']
})
export class ConversationCardComponent implements OnInit {
  @Input() userId;
  @Input() chat: ChatModel;
  constructor() {}

  ngOnInit() {}
}
