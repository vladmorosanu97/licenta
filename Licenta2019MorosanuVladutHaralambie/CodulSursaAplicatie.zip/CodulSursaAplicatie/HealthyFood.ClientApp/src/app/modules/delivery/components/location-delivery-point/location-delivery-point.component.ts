import { Component, OnInit, Input } from '@angular/core';
import LocationDeliveryModel from 'src/app/shared/models/location-delivery-model';
import LocationDeliveryPointModel from 'src/app/shared/models/location-delivery-point-model';

@Component({
  selector: 'app-location-delivery-point',
  templateUrl: './location-delivery-point.component.html',
  styleUrls: ['./location-delivery-point.component.scss']
})
export class LocationDeliveryPointComponent implements OnInit {
  @Input() locationDeliveryPoint: LocationDeliveryPointModel;
  constructor() {}

  ngOnInit() {}
}
