import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyDeliveryDescriptionComponent } from './my-delivery-description.component';

describe('MyDeliveryDescriptionComponent', () => {
  let component: MyDeliveryDescriptionComponent;
  let fixture: ComponentFixture<MyDeliveryDescriptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyDeliveryDescriptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyDeliveryDescriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
