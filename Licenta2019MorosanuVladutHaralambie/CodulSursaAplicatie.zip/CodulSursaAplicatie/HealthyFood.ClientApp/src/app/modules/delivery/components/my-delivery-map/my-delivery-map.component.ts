import { Component, OnInit, Input } from '@angular/core';
import LocationDeliveryModel from 'src/app/shared/models/location-delivery-model';
import HomeDeliveryModel from 'src/app/shared/models/home-delivery-model';

@Component({
  selector: 'app-my-delivery-map',
  templateUrl: './my-delivery-map.component.html',
  styleUrls: ['./my-delivery-map.component.scss']
})
export class MyDeliveryMapComponent implements OnInit {
  @Input() locationDelivery: LocationDeliveryModel = null;
  @Input() homeDelivery: HomeDeliveryModel = null;
  constructor() {}

  ngOnInit() {}
}
