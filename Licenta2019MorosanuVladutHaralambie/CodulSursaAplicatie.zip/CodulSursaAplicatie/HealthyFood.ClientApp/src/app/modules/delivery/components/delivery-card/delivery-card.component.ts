import {
  Component,
  OnInit,
  Input,
  SimpleChanges,
  OnChanges
} from '@angular/core';
import LocationDeliveryModel from 'src/app/shared/models/location-delivery-model';

@Component({
  selector: 'app-delivery-card',
  templateUrl: './delivery-card.component.html',
  styleUrls: ['./delivery-card.component.scss']
})
export class DeliveryCardComponent implements OnInit, OnChanges {
  @Input() delivery: LocationDeliveryModel;
  @Input() currentDelivery: number = null;
  @Input() index: number = null;
  constructor() {}

  ngOnInit() {}

  ngOnChanges(changes: SimpleChanges) {
    console.log('current deliver', this.currentDelivery);
    console.log('index', this.index);
  }
}
