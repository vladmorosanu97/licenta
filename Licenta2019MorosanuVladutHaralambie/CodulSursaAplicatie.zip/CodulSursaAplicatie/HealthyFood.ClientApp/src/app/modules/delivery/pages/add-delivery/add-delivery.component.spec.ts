import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddHomeDeliveryComponent } from './add-home-delivery.component';

describe('AddHomeDeliveryComponent', () => {
  let component: AddHomeDeliveryComponent;
  let fixture: ComponentFixture<AddHomeDeliveryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddHomeDeliveryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddHomeDeliveryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
