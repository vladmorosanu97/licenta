import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyDeliveryMapComponent } from './my-delivery-map.component';

describe('MyDeliveryMapComponent', () => {
  let component: MyDeliveryMapComponent;
  let fixture: ComponentFixture<MyDeliveryMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyDeliveryMapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyDeliveryMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
