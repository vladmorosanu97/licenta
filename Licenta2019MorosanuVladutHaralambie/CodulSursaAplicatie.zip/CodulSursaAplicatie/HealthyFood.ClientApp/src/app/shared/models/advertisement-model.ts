import UserCardModel from 'src/app/shared/models/user-card-model';
import UserModel from './user-model';
import UnitTypeModel from './unit-type-model';
import CategoryModel from './category-model';
import AdvertisementImageModel from './advertisement-image-model';

export default class AdvertisementModel {
  advertisementId: number;
  createdById: number;
  title: string;
  description: string;
  price: number;
  categoryId: number;
  locationName: string;
  longitude: number;
  latitude: number;
  homeDelivery: boolean;
  unitTypeId: number;
  createdBy: UserCardModel;
  unitType: UnitTypeModel;
  category: CategoryModel;
  distance: number;
  phoneNumber: string;
  advertisementImages: Array<AdvertisementImageModel>;
}
