export default class ChangePasswordModel {
  currentPassword: string;
  newPassword: string;
}
