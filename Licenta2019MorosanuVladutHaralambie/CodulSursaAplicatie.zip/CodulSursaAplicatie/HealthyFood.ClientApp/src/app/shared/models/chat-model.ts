import ChatUserModel from './chat-user-model';

export default class ChatModel {
  chatId: number;
  name: string;
  partnerId: number;
  partnerFirstName: string;
  partnerLastName: string;
  messagesCount: number;
  isOnline: boolean;
  longitude: number;
  latitude: number;
  locationName: string;
  rating: number;
  partnerEmail: string;
  lastTimeOnline: Date;
}
