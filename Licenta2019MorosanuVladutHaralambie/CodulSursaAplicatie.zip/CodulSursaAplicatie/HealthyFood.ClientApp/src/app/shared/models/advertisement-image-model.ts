export default class AdvertisementImageModel {
  advertisementImageId: number;
  advertisementId: number;
  guidFileName: string;
  imagePath: string;
}
