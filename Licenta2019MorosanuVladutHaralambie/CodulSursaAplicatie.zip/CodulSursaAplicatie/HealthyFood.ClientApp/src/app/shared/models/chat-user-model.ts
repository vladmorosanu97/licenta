import ChatModel from './chat-model';
import UserModel from './user-model';

export default class ChatUserModel {
  chatUserId: number;
  chatId: number;
  userId: number;
  chat: ChatModel;
  user: UserModel;
}
