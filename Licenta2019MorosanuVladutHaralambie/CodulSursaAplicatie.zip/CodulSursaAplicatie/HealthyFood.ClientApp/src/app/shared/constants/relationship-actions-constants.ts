export default class RelationshipActionsConstants {
  public static cancelFriendRequest = 'CANCEL_FRIEND_REQUEST';
  public static acceptFriendRequest = 'ACCEPT_FRIEND_REQUEST';
  public static removeFriendRequest = 'REMOVE_FRIEND_REQUEST';
  public static sendFriendRequest = 'SEND_FRIEND_REQUEST';
  public static removeFriend = 'REMOVE_FRIEND';
}
