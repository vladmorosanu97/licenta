export class UserRoles {
  public static admin = 'admin';
  public static client = 'client';
  public static seller = 'seller';
}
