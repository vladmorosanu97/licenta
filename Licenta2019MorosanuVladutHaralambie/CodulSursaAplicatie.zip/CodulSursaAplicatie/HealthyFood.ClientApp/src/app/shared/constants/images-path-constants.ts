export default class ImagesPathConstants {
  public static userPresentation = 'https://i.imgur.com/QztlVTN.jpg';
}
