export default class SettingsItems {
  public static profile = 'profile';
  public static changePassword = 'change-password';
  public static notifications = 'notifications';
  public static location = 'location';
}
